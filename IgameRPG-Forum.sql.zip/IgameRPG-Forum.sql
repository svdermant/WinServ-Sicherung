-- MariaDB dump 10.17  Distrib 10.5.6-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: phpBB
-- ------------------------------------------------------
-- Server version	10.5.6-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `phpbb_acl_groups`
--

DROP TABLE IF EXISTS `phpbb_acl_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_acl_groups` (
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `auth_option_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `auth_role_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `auth_setting` tinyint(2) NOT NULL DEFAULT 0,
  KEY `group_id` (`group_id`),
  KEY `auth_opt_id` (`auth_option_id`),
  KEY `auth_role_id` (`auth_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_acl_groups`
--

LOCK TABLES `phpbb_acl_groups` WRITE;
/*!40000 ALTER TABLE `phpbb_acl_groups` DISABLE KEYS */;
INSERT INTO `phpbb_acl_groups` VALUES (1,0,91,0,1),(1,0,100,0,1),(1,0,119,0,1),(5,0,0,5,0),(5,0,0,1,0),(2,0,0,6,0),(3,0,0,6,0),(4,0,0,5,0),(4,0,0,10,0),(7,0,0,23,0),(5,0,157,0,1),(5,5,0,14,0),(5,6,0,14,0),(5,7,0,14,0),(1,5,0,17,0),(1,6,0,17,0),(1,7,0,17,0),(2,5,0,17,0),(2,6,0,17,0),(2,7,0,15,0),(5,8,0,14,0),(1,8,0,17,0),(2,8,0,21,0),(5,9,0,14,0),(1,9,0,17,0),(2,9,0,17,0),(5,10,0,14,0),(1,10,0,17,0),(2,10,0,20,0),(5,11,0,14,0),(1,11,0,17,0),(2,11,0,20,0);
/*!40000 ALTER TABLE `phpbb_acl_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_acl_options`
--

DROP TABLE IF EXISTS `phpbb_acl_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_acl_options` (
  `auth_option_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `auth_option` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `is_global` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `is_local` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `founder_only` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`auth_option_id`),
  UNIQUE KEY `auth_option` (`auth_option`)
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_acl_options`
--

LOCK TABLES `phpbb_acl_options` WRITE;
/*!40000 ALTER TABLE `phpbb_acl_options` DISABLE KEYS */;
INSERT INTO `phpbb_acl_options` VALUES (1,'f_',0,1,0),(2,'f_announce',0,1,0),(3,'f_announce_global',0,1,0),(4,'f_attach',0,1,0),(5,'f_bbcode',0,1,0),(6,'f_bump',0,1,0),(7,'f_delete',0,1,0),(8,'f_download',0,1,0),(9,'f_edit',0,1,0),(10,'f_email',0,1,0),(11,'f_flash',0,1,0),(12,'f_icons',0,1,0),(13,'f_ignoreflood',0,1,0),(14,'f_img',0,1,0),(15,'f_list',0,1,0),(16,'f_list_topics',0,1,0),(17,'f_noapprove',0,1,0),(18,'f_poll',0,1,0),(19,'f_post',0,1,0),(20,'f_postcount',0,1,0),(21,'f_print',0,1,0),(22,'f_read',0,1,0),(23,'f_reply',0,1,0),(24,'f_report',0,1,0),(25,'f_search',0,1,0),(26,'f_sigs',0,1,0),(27,'f_smilies',0,1,0),(28,'f_sticky',0,1,0),(29,'f_subscribe',0,1,0),(30,'f_user_lock',0,1,0),(31,'f_vote',0,1,0),(32,'f_votechg',0,1,0),(33,'f_softdelete',0,1,0),(34,'m_',1,1,0),(35,'m_approve',1,1,0),(36,'m_chgposter',1,1,0),(37,'m_delete',1,1,0),(38,'m_edit',1,1,0),(39,'m_info',1,1,0),(40,'m_lock',1,1,0),(41,'m_merge',1,1,0),(42,'m_move',1,1,0),(43,'m_report',1,1,0),(44,'m_split',1,1,0),(45,'m_softdelete',1,1,0),(46,'m_ban',1,0,0),(47,'m_pm_report',1,0,0),(48,'m_warn',1,0,0),(49,'a_',1,0,0),(50,'a_aauth',1,0,0),(51,'a_attach',1,0,0),(52,'a_authgroups',1,0,0),(53,'a_authusers',1,0,0),(54,'a_backup',1,0,0),(55,'a_ban',1,0,0),(56,'a_bbcode',1,0,0),(57,'a_board',1,0,0),(58,'a_bots',1,0,0),(59,'a_clearlogs',1,0,0),(60,'a_email',1,0,0),(61,'a_extensions',1,0,0),(62,'a_fauth',1,0,0),(63,'a_forum',1,0,0),(64,'a_forumadd',1,0,0),(65,'a_forumdel',1,0,0),(66,'a_group',1,0,0),(67,'a_groupadd',1,0,0),(68,'a_groupdel',1,0,0),(69,'a_icons',1,0,0),(70,'a_jabber',1,0,0),(71,'a_language',1,0,0),(72,'a_mauth',1,0,0),(73,'a_modules',1,0,0),(74,'a_names',1,0,0),(75,'a_phpinfo',1,0,0),(76,'a_profile',1,0,0),(77,'a_prune',1,0,0),(78,'a_ranks',1,0,0),(79,'a_reasons',1,0,0),(80,'a_roles',1,0,0),(81,'a_search',1,0,0),(82,'a_server',1,0,0),(83,'a_styles',1,0,0),(84,'a_switchperm',1,0,0),(85,'a_uauth',1,0,0),(86,'a_user',1,0,0),(87,'a_userdel',1,0,0),(88,'a_viewauth',1,0,0),(89,'a_viewlogs',1,0,0),(90,'a_words',1,0,0),(91,'u_',1,0,0),(92,'u_attach',1,0,0),(93,'u_chgavatar',1,0,0),(94,'u_chgcensors',1,0,0),(95,'u_chgemail',1,0,0),(96,'u_chggrp',1,0,0),(97,'u_chgname',1,0,0),(98,'u_chgpasswd',1,0,0),(99,'u_chgprofileinfo',1,0,0),(100,'u_download',1,0,0),(101,'u_emoji',1,0,0),(102,'u_hideonline',1,0,0),(103,'u_ignoreflood',1,0,0),(104,'u_masspm',1,0,0),(105,'u_masspm_group',1,0,0),(106,'u_pm_attach',1,0,0),(107,'u_pm_bbcode',1,0,0),(108,'u_pm_delete',1,0,0),(109,'u_pm_download',1,0,0),(110,'u_pm_edit',1,0,0),(111,'u_pm_emailpm',1,0,0),(112,'u_pm_flash',1,0,0),(113,'u_pm_forward',1,0,0),(114,'u_pm_img',1,0,0),(115,'u_pm_printpm',1,0,0),(116,'u_pm_smilies',1,0,0),(117,'u_readpm',1,0,0),(118,'u_savedrafts',1,0,0),(119,'u_search',1,0,0),(120,'u_sendemail',1,0,0),(121,'u_sendim',1,0,0),(122,'u_sendpm',1,0,0),(123,'u_sig',1,0,0),(124,'u_viewonline',1,0,0),(125,'u_viewprofile',1,0,0),(127,'m_userflair',1,0,0),(128,'u_flair',1,0,0),(129,'u_delete_my_account_posts',1,0,0),(130,'u_mchat_use',1,0,0),(131,'u_mchat_view',1,0,0),(132,'u_mchat_edit',1,0,0),(133,'u_mchat_delete',1,0,0),(134,'u_mchat_ip',1,0,0),(135,'u_mchat_pm',1,0,0),(136,'u_mchat_like',1,0,0),(137,'u_mchat_quote',1,0,0),(138,'u_mchat_flood_ignore',1,0,0),(139,'u_mchat_archive',1,0,0),(140,'u_mchat_bbcode',1,0,0),(141,'u_mchat_smilies',1,0,0),(142,'u_mchat_urls',1,0,0),(143,'u_mchat_avatars',1,0,0),(144,'u_mchat_capital_letter',1,0,0),(145,'u_mchat_character_count',1,0,0),(146,'u_mchat_date',1,0,0),(147,'u_mchat_index',1,0,0),(149,'u_mchat_location',1,0,0),(150,'u_mchat_message_top',1,0,0),(152,'u_mchat_posts',1,0,0),(153,'u_mchat_relative_time',1,0,0),(154,'u_mchat_sound',1,0,0),(155,'u_mchat_stats_index',1,0,0),(156,'u_mchat_whois_index',1,0,0),(157,'a_mchat',1,0,0),(158,'u_mchat_moderator_edit',1,0,0),(159,'u_mchat_moderator_delete',1,0,0),(168,'a_sm_manage_blocks',1,0,0),(169,'a_sm_manage_menus',1,0,0),(170,'a_sm_settings',1,0,0),(171,'u_sm_filemanager',1,0,0),(172,'a_sm_filemanager',1,0,0);
/*!40000 ALTER TABLE `phpbb_acl_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_acl_roles`
--

DROP TABLE IF EXISTS `phpbb_acl_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_acl_roles` (
  `role_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `role_description` text COLLATE utf8_bin NOT NULL,
  `role_type` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT '',
  `role_order` smallint(4) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`role_id`),
  KEY `role_type` (`role_type`),
  KEY `role_order` (`role_order`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_acl_roles`
--

LOCK TABLES `phpbb_acl_roles` WRITE;
/*!40000 ALTER TABLE `phpbb_acl_roles` DISABLE KEYS */;
INSERT INTO `phpbb_acl_roles` VALUES (1,'ROLE_ADMIN_STANDARD','ROLE_DESCRIPTION_ADMIN_STANDARD','a_',1),(2,'ROLE_ADMIN_FORUM','ROLE_DESCRIPTION_ADMIN_FORUM','a_',3),(3,'ROLE_ADMIN_USERGROUP','ROLE_DESCRIPTION_ADMIN_USERGROUP','a_',4),(4,'ROLE_ADMIN_FULL','ROLE_DESCRIPTION_ADMIN_FULL','a_',2),(5,'ROLE_USER_FULL','ROLE_DESCRIPTION_USER_FULL','u_',3),(6,'ROLE_USER_STANDARD','ROLE_DESCRIPTION_USER_STANDARD','u_',1),(7,'ROLE_USER_LIMITED','ROLE_DESCRIPTION_USER_LIMITED','u_',2),(8,'ROLE_USER_NOPM','ROLE_DESCRIPTION_USER_NOPM','u_',4),(9,'ROLE_USER_NOAVATAR','ROLE_DESCRIPTION_USER_NOAVATAR','u_',5),(10,'ROLE_MOD_FULL','ROLE_DESCRIPTION_MOD_FULL','m_',3),(11,'ROLE_MOD_STANDARD','ROLE_DESCRIPTION_MOD_STANDARD','m_',1),(12,'ROLE_MOD_SIMPLE','ROLE_DESCRIPTION_MOD_SIMPLE','m_',2),(13,'ROLE_MOD_QUEUE','ROLE_DESCRIPTION_MOD_QUEUE','m_',4),(14,'ROLE_FORUM_FULL','ROLE_DESCRIPTION_FORUM_FULL','f_',7),(15,'ROLE_FORUM_STANDARD','ROLE_DESCRIPTION_FORUM_STANDARD','f_',5),(16,'ROLE_FORUM_NOACCESS','ROLE_DESCRIPTION_FORUM_NOACCESS','f_',1),(17,'ROLE_FORUM_READONLY','ROLE_DESCRIPTION_FORUM_READONLY','f_',2),(18,'ROLE_FORUM_LIMITED','ROLE_DESCRIPTION_FORUM_LIMITED','f_',3),(19,'ROLE_FORUM_BOT','ROLE_DESCRIPTION_FORUM_BOT','f_',9),(20,'ROLE_FORUM_ONQUEUE','ROLE_DESCRIPTION_FORUM_ONQUEUE','f_',8),(21,'ROLE_FORUM_POLLS','ROLE_DESCRIPTION_FORUM_POLLS','f_',6),(22,'ROLE_FORUM_LIMITED_POLLS','ROLE_DESCRIPTION_FORUM_LIMITED_POLLS','f_',4),(23,'ROLE_USER_NEW_MEMBER','ROLE_DESCRIPTION_USER_NEW_MEMBER','u_',6),(24,'ROLE_FORUM_NEW_MEMBER','ROLE_DESCRIPTION_FORUM_NEW_MEMBER','f_',10);
/*!40000 ALTER TABLE `phpbb_acl_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_acl_roles_data`
--

DROP TABLE IF EXISTS `phpbb_acl_roles_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_acl_roles_data` (
  `role_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `auth_option_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `auth_setting` tinyint(2) NOT NULL DEFAULT 0,
  PRIMARY KEY (`role_id`,`auth_option_id`),
  KEY `ath_op_id` (`auth_option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_acl_roles_data`
--

LOCK TABLES `phpbb_acl_roles_data` WRITE;
/*!40000 ALTER TABLE `phpbb_acl_roles_data` DISABLE KEYS */;
INSERT INTO `phpbb_acl_roles_data` VALUES (1,49,1),(1,51,1),(1,52,1),(1,53,1),(1,55,1),(1,56,1),(1,57,1),(1,61,1),(1,62,1),(1,63,1),(1,64,1),(1,65,1),(1,66,1),(1,67,1),(1,68,1),(1,69,1),(1,72,1),(1,74,1),(1,76,1),(1,77,1),(1,78,1),(1,79,1),(1,85,1),(1,86,1),(1,87,1),(1,88,1),(1,89,1),(1,90,1),(1,168,1),(1,169,1),(1,170,1),(1,172,1),(2,49,1),(2,52,1),(2,53,1),(2,62,1),(2,63,1),(2,64,1),(2,65,1),(2,72,1),(2,77,1),(2,85,1),(2,88,1),(2,89,1),(3,49,1),(3,52,1),(3,53,1),(3,55,1),(3,66,1),(3,67,1),(3,68,1),(3,78,1),(3,85,1),(3,86,1),(3,88,1),(3,89,1),(4,49,1),(4,50,1),(4,51,1),(4,52,1),(4,53,1),(4,54,1),(4,55,1),(4,56,1),(4,57,1),(4,58,1),(4,59,1),(4,60,1),(4,61,1),(4,62,1),(4,63,1),(4,64,1),(4,65,1),(4,66,1),(4,67,1),(4,68,1),(4,69,1),(4,70,1),(4,71,1),(4,72,1),(4,73,1),(4,74,1),(4,75,1),(4,76,1),(4,77,1),(4,78,1),(4,79,1),(4,80,1),(4,81,1),(4,82,1),(4,83,1),(4,84,1),(4,85,1),(4,86,1),(4,87,1),(4,88,1),(4,89,1),(4,90,1),(4,168,1),(4,169,1),(4,172,1),(5,91,1),(5,92,1),(5,93,1),(5,94,1),(5,95,1),(5,96,1),(5,97,1),(5,98,1),(5,99,1),(5,100,1),(5,101,1),(5,102,1),(5,103,1),(5,104,1),(5,105,1),(5,106,1),(5,107,1),(5,108,1),(5,109,1),(5,110,1),(5,111,1),(5,112,1),(5,113,1),(5,114,1),(5,115,1),(5,116,1),(5,117,1),(5,118,1),(5,119,1),(5,120,1),(5,121,1),(5,122,1),(5,123,1),(5,124,1),(5,125,1),(5,128,1),(5,132,1),(5,133,1),(5,134,1),(5,138,1),(5,171,1),(6,91,1),(6,92,1),(6,93,1),(6,94,1),(6,95,1),(6,98,1),(6,99,1),(6,100,1),(6,101,1),(6,102,1),(6,104,1),(6,105,1),(6,106,1),(6,107,1),(6,108,1),(6,109,1),(6,110,1),(6,111,1),(6,114,1),(6,115,1),(6,116,1),(6,117,1),(6,118,1),(6,119,1),(6,120,1),(6,121,1),(6,122,1),(6,123,1),(6,125,1),(6,128,1),(6,130,1),(6,131,1),(6,135,1),(6,136,1),(6,137,1),(6,139,1),(6,140,1),(6,141,1),(6,142,1),(6,143,1),(6,144,1),(6,145,1),(6,147,1),(6,149,1),(6,150,1),(6,152,1),(6,153,1),(6,154,1),(6,171,1),(7,91,1),(7,93,1),(7,94,1),(7,95,1),(7,98,1),(7,99,1),(7,100,1),(7,101,1),(7,102,1),(7,107,1),(7,108,1),(7,109,1),(7,110,1),(7,113,1),(7,114,1),(7,115,1),(7,116,1),(7,117,1),(7,122,1),(7,123,1),(7,125,1),(7,128,1),(8,91,1),(8,93,1),(8,94,1),(8,95,1),(8,98,1),(8,100,1),(8,102,1),(8,104,0),(8,105,0),(8,117,0),(8,122,0),(8,123,1),(8,125,1),(8,128,1),(9,91,1),(9,93,0),(9,94,1),(9,95,1),(9,98,1),(9,99,1),(9,100,1),(9,101,1),(9,102,1),(9,107,1),(9,108,1),(9,109,1),(9,110,1),(9,113,1),(9,114,1),(9,115,1),(9,116,1),(9,117,1),(9,122,1),(9,123,1),(9,125,1),(9,128,1),(10,34,1),(10,35,1),(10,36,1),(10,37,1),(10,38,1),(10,39,1),(10,40,1),(10,41,1),(10,42,1),(10,43,1),(10,44,1),(10,45,1),(10,46,1),(10,47,1),(10,48,1),(10,127,1),(11,34,1),(11,35,1),(11,37,1),(11,38,1),(11,39,1),(11,40,1),(11,41,1),(11,42,1),(11,43,1),(11,44,1),(11,45,1),(11,47,1),(11,48,1),(12,34,1),(12,37,1),(12,38,1),(12,39,1),(12,43,1),(12,45,1),(12,47,1),(13,34,1),(13,35,1),(13,38,1),(14,1,1),(14,2,1),(14,3,1),(14,4,1),(14,5,1),(14,6,1),(14,7,1),(14,8,1),(14,9,1),(14,10,1),(14,11,1),(14,12,1),(14,13,1),(14,14,1),(14,15,1),(14,16,1),(14,17,1),(14,18,1),(14,19,1),(14,20,1),(14,21,1),(14,22,1),(14,23,1),(14,24,1),(14,25,1),(14,26,1),(14,27,1),(14,28,1),(14,29,1),(14,30,1),(14,31,1),(14,32,1),(14,33,1),(15,1,1),(15,4,1),(15,5,1),(15,6,1),(15,7,1),(15,8,1),(15,9,1),(15,10,1),(15,12,1),(15,14,1),(15,15,1),(15,16,1),(15,17,1),(15,19,1),(15,20,1),(15,21,1),(15,22,1),(15,23,1),(15,24,1),(15,25,1),(15,26,1),(15,27,1),(15,29,1),(15,31,1),(15,32,1),(15,33,1),(16,1,0),(17,1,1),(17,8,1),(17,15,1),(17,16,1),(17,21,1),(17,22,1),(17,25,1),(17,29,1),(18,1,1),(18,5,1),(18,8,1),(18,9,1),(18,10,1),(18,14,1),(18,15,1),(18,16,1),(18,17,1),(18,19,1),(18,20,1),(18,21,1),(18,22,1),(18,23,1),(18,24,1),(18,25,1),(18,26,1),(18,27,1),(18,29,1),(18,31,1),(18,33,1),(19,1,1),(19,8,1),(19,15,1),(19,16,1),(19,21,1),(19,22,1),(20,1,1),(20,4,1),(20,5,1),(20,8,1),(20,9,1),(20,10,1),(20,14,1),(20,15,1),(20,16,1),(20,17,0),(20,19,1),(20,20,1),(20,21,1),(20,22,1),(20,23,1),(20,24,1),(20,25,1),(20,26,1),(20,27,1),(20,29,1),(20,31,1),(20,33,1),(21,1,1),(21,4,1),(21,5,1),(21,6,1),(21,7,1),(21,8,1),(21,9,1),(21,10,1),(21,12,1),(21,14,1),(21,15,1),(21,16,1),(21,17,1),(21,18,1),(21,19,1),(21,20,1),(21,21,1),(21,22,1),(21,23,1),(21,24,1),(21,25,1),(21,26,1),(21,27,1),(21,29,1),(21,31,1),(21,32,1),(21,33,1),(22,1,1),(22,5,1),(22,8,1),(22,9,1),(22,10,1),(22,14,1),(22,15,1),(22,16,1),(22,17,1),(22,18,1),(22,19,1),(22,20,1),(22,21,1),(22,22,1),(22,23,1),(22,24,1),(22,25,1),(22,26,1),(22,27,1),(22,29,1),(22,31,1),(22,33,1),(23,99,0),(23,104,0),(23,105,0),(23,122,0),(24,17,0);
/*!40000 ALTER TABLE `phpbb_acl_roles_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_acl_users`
--

DROP TABLE IF EXISTS `phpbb_acl_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_acl_users` (
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `auth_option_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `auth_role_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `auth_setting` tinyint(2) NOT NULL DEFAULT 0,
  KEY `user_id` (`user_id`),
  KEY `auth_option_id` (`auth_option_id`),
  KEY `auth_role_id` (`auth_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_acl_users`
--

LOCK TABLES `phpbb_acl_users` WRITE;
/*!40000 ALTER TABLE `phpbb_acl_users` DISABLE KEYS */;
INSERT INTO `phpbb_acl_users` VALUES (2,0,0,5,0),(49,0,0,6,0);
/*!40000 ALTER TABLE `phpbb_acl_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_attachments`
--

DROP TABLE IF EXISTS `phpbb_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_attachments` (
  `attach_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_msg_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `in_message` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `poster_id` int(10) unsigned NOT NULL DEFAULT 0,
  `is_orphan` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `physical_filename` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `real_filename` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `download_count` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `attach_comment` text COLLATE utf8_bin NOT NULL,
  `extension` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `mimetype` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `filesize` int(20) unsigned NOT NULL DEFAULT 0,
  `filetime` int(11) unsigned NOT NULL DEFAULT 0,
  `thumbnail` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`attach_id`),
  KEY `filetime` (`filetime`),
  KEY `post_msg_id` (`post_msg_id`),
  KEY `topic_id` (`topic_id`),
  KEY `poster_id` (`poster_id`),
  KEY `is_orphan` (`is_orphan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_attachments`
--

LOCK TABLES `phpbb_attachments` WRITE;
/*!40000 ALTER TABLE `phpbb_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_banlist`
--

DROP TABLE IF EXISTS `phpbb_banlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_banlist` (
  `ban_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ban_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ban_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `ban_email` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `ban_start` int(11) unsigned NOT NULL DEFAULT 0,
  `ban_end` int(11) unsigned NOT NULL DEFAULT 0,
  `ban_exclude` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `ban_reason` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `ban_give_reason` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`ban_id`),
  KEY `ban_end` (`ban_end`),
  KEY `ban_user` (`ban_userid`,`ban_exclude`),
  KEY `ban_email` (`ban_email`,`ban_exclude`),
  KEY `ban_ip` (`ban_ip`,`ban_exclude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_banlist`
--

LOCK TABLES `phpbb_banlist` WRITE;
/*!40000 ALTER TABLE `phpbb_banlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_banlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_bbcodes`
--

DROP TABLE IF EXISTS `phpbb_bbcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_bbcodes` (
  `bbcode_id` smallint(4) unsigned NOT NULL DEFAULT 0,
  `bbcode_tag` varchar(16) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bbcode_helpline` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_on_posting` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `bbcode_match` text COLLATE utf8_bin NOT NULL,
  `bbcode_tpl` mediumtext COLLATE utf8_bin NOT NULL,
  `first_pass_match` mediumtext COLLATE utf8_bin NOT NULL,
  `first_pass_replace` mediumtext COLLATE utf8_bin NOT NULL,
  `second_pass_match` mediumtext COLLATE utf8_bin NOT NULL,
  `second_pass_replace` mediumtext COLLATE utf8_bin NOT NULL,
  `bbcode_order` smallint(4) unsigned NOT NULL DEFAULT 0,
  `bbcode_group` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`bbcode_id`),
  KEY `display_on_post` (`display_on_posting`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_bbcodes`
--

LOCK TABLES `phpbb_bbcodes` WRITE;
/*!40000 ALTER TABLE `phpbb_bbcodes` DISABLE KEYS */;
INSERT INTO `phpbb_bbcodes` VALUES (13,'font','ABBC3_FONT_HELPLINE',1,'[font={INTTEXT}]{TEXT}[/font]','<span style=\"font-family: {INTTEXT};\">{TEXT}</span>','/(?!)/','','/(?!)/','',1,''),(14,'highlight','ABBC3_HIGHLIGHT_HELPLINE',1,'[highlight={COLOR}]{TEXT}[/highlight]','<span style=\"background-color: {COLOR};\">{TEXT}</span>','/(?!)/','','/(?!)/','',2,''),(15,'align','ABBC3_ALIGN_HELPLINE',1,'[align={IDENTIFIER}]{TEXT}[/align]','<div style=\"text-align:{IDENTIFIER}\">{TEXT}</div>','/(?!)/','','/(?!)/','',3,''),(16,'float','ABBC3_FLOAT_HELPLINE',1,'[float={IDENTIFIER}]{TEXT}[/float]','<div style=\"float:{IDENTIFIER}; padding:0 10px;\">{TEXT}</div>','/(?!)/','','/(?!)/','',4,''),(17,'pre','ABBC3_PREFORMAT_HELPLINE',1,'[pre]{TEXT}[/pre]','<pre class=\"abbc3_pre\" style=\"display: block; font-family: monospace; white-space: pre;\">{TEXT}</pre>','/(?!)/','','/(?!)/','',5,''),(18,'s','ABBC3_STRIKE_HELPLINE',1,'[s]{TEXT}[/s]','<span class=\"abbc3_strike\" style=\"text-decoration: line-through\">{TEXT}</span>','/(?!)/','','/(?!)/','',6,''),(19,'sup','ABBC3_SUP_HELPLINE',1,'[sup]{TEXT}[/sup]','<sup style=\"vertical-align: super; font-size: smaller;\">{TEXT}</sup>','/(?!)/','','/(?!)/','',7,''),(20,'sub','ABBC3_SUB_HELPLINE',1,'[sub]{TEXT}[/sub]','<sub style=\"vertical-align: sub; font-size: smaller;\">{TEXT}</sub>','/(?!)/','','/(?!)/','',8,''),(21,'glow','ABBC3_GLOW_HELPLINE',1,'[glow={COLOR}]{TEXT}[/glow]','<span class=\"glow\" style=\"display: inline; padding: 0 6px; color: #ffffff; text-shadow: 0 0 1em {COLOR}, 0 0 1em {COLOR}, 0 0 1.2em {COLOR};\">{TEXT}</span>','/(?!)/','','/(?!)/','',9,''),(22,'shadow','ABBC3_SHADOW_HELPLINE',1,'[shadow={COLOR}]{TEXT}[/shadow]','<span class=\"shadow\" style=\"display: inline; padding: 0 6px; color: {COLOR}; text-shadow: -2px 2px 2px #999;\">{TEXT}</span>','/(?!)/','','/(?!)/','',10,''),(23,'dropshadow','ABBC3_DROPSHADOW_HELPLINE',1,'[dropshadow={COLOR}]{TEXT}[/dropshadow]','<span class=\"dropshadow\" style=\"display: inline; padding: 0 6px; color: {COLOR}; text-shadow: -1px 1px 0 #999;\">{TEXT}</span>','/(?!)/','','/(?!)/','',11,''),(24,'blur','ABBC3_BLUR_HELPLINE',1,'[blur={COLOR}]{TEXT}[/blur]','<span class=\"blur\" style=\"display: inline; padding: 0 6px; color: transparent; text-shadow: 0 0 0.2em {COLOR};\">{TEXT}</span>','/(?!)/','','/(?!)/','',12,''),(25,'fade','ABBC3_FADE_HELPLINE',1,'[fade]{TEXT}[/fade]','<span class=\"fadeEffect\">{TEXT}</span>','/(?!)/','','/(?!)/','',13,''),(26,'dir','ABBC3_DIR_HELPLINE',1,'[dir={IDENTIFIER}]{TEXT}[/dir]','<bdo dir=\"{IDENTIFIER}\">{TEXT}</bdo>','/(?!)/','','/(?!)/','',14,''),(27,'marq','ABBC3_MARQUEE_HELPLINE',1,'[marq={IDENTIFIER}]{TEXT}[/marq]','<marquee class=\"abbc3_marquee\" direction=\"{IDENTIFIER}\" scrolldelay=\"100\" onmouseover=\"this.scrollDelay=10000000;\" onmouseout=\"this.scrollDelay=100;\" style=\"margin: 10px 0; padding: 5px; display: inline-block;\">{TEXT}</marquee>','/(?!)/','','/(?!)/','',15,''),(28,'spoil','ABBC3_SPOILER_HELPLINE',1,'[spoil]{TEXT}[/spoil]','<div class=\"spoilwrapper\" style=\"margin:1em 0;font-weight:normal;padding:4px 10px;background-color:#fff;border:1px solid #dbdbdb;border-radius:4px;color:#333333;\"><div class=\"spoiltitle\" style=\"margin:0;padding:0;width:100%;\"><span class=\"spoilbtn\" style=\"margin:2px 5px;text-transform:uppercase;font-family:\'Helvetica Neue\', Helvetica, Arial, sans-serif;font-size:11px;font-weight:bold;display:block;cursor:pointer;color:#333;\" data-show=\"{L_ABBC3_SPOILER_SHOW}\" data-hide=\"{L_ABBC3_SPOILER_HIDE}\">{L_ABBC3_SPOILER_SHOW}</span></div><div class=\"spoilcontent\" style=\"color:#333333;display:none;padding:5px;border-top:1px solid #ccc;\">{TEXT}</div></div>','/(?!)/','','/(?!)/','',16,''),(29,'hidden','ABBC3_HIDDEN_HELPLINE',1,'[hidden]{TEXT}[/hidden]','<!-- ABBC3_BBCODE_HIDDEN -->{TEXT}<!-- ABBC3_BBCODE_HIDDEN -->','/(?!)/','','/(?!)/','',17,''),(30,'offtopic','ABBC3_OFFTOPIC_HELPLINE',1,'[offtopic]{TEXT}[/offtopic]','<div class=\"offtopic\" style=\"position:relative;margin:1em 0;padding:39px 19px 14px;background:#fff;border:1px solid #ddd;border-radius:4px;\"><div class=\"offtopic_title\" style=\"position:absolute;top:-1px;left:-1px;font-family:\'Helvetica Neue\', Helvetica, Arial, sans-serif;font-weight:bold;font-size:12px;color:#9da0a4;background:#f5f5f5;padding:5px 12px;border:1px solid #ddd;border-radius:4px 0 4px 0;\">{L_ABBC3_OFFTOPIC}</div><div class=\"offtopic_text\" style=\"padding:5px 10px;color:#333333;\">{TEXT}</div></div>','/(?!)/','','/(?!)/','',18,''),(31,'mod','ABBC3_MOD_HELPLINE',1,'[mod={TEXT1}]{TEXT2}[/mod]','<table class=\"ModTable\" style=\"background-color:#FFFFFF;border:1px solid #000000;border-collapse:separate;border-spacing:5px;margin:1em 0;padding:0;width:100%;color:#333333;overflow:hidden;\"><tr><td class=\"exclamation\" rowspan=\"2\" style=\"background-color:#ff6060;font-weight:bold;font-family:\'Times New Roman\',Verdana,sans-serif;font-size:4em;color:#ffffff;vertical-align:middle;text-align:center;width:1%;\">&nbsp;!&nbsp;</td><td class=\"rowuser\" style=\"border-bottom:1px solid #000000;font-weight:bold;\">{L_MESSAGE} {L_FROM}{L_COLON} {TEXT1}</td></tr><tr><td class=\"rowtext\">{TEXT2}</td></tr></table>','/(?!)/','','/(?!)/','',19,''),(32,'nfo','ABBC3_NFO_HELPLINE',1,'[nfo]{TEXT}[/nfo]','<pre class=\"nfo\" style=\"color:#000000;font-weight:normal;line-height:normal;font-size:10pt;font-family:Terminal, monospace;background-color:#ffffff;white-space:pre;margin:1em 0;padding:5px;\">{TEXT}</pre>','/(?!)/','','/(?!)/','',20,''),(33,'soundcloud','ABBC3_SOUNDCLOUD_HELPLINE',1,'[soundcloud]{URL}[/soundcloud]','<iframe width=\"100%\" height=\"166\" scrolling=\"no\" frameborder=\"no\" src=\"https://w.soundcloud.com/player/?url={URL}&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false\"></iframe>','/(?!)/','','/(?!)/','',21,''),(34,'BBvideo','ABBC3_BBVIDEO_HELPLINE',1,'[BBvideo={NUMBER1},{NUMBER2}]{URL}[/BBvideo]','<a href=\"{URL}\" class=\"bbvideo\" data-bbvideo=\"{NUMBER1},{NUMBER2}\" target=\"_blank\">{URL}</a>','/(?!)/','','/(?!)/','',22,''),(35,'pipes','ABBC3_PIPE_TABLES',1,'[pipes]{TEXT}[/pipes]','{TEXT}','/(?!)/','','/(?!)/','',23,'');
/*!40000 ALTER TABLE `phpbb_bbcodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_bookmarks`
--

DROP TABLE IF EXISTS `phpbb_bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_bookmarks` (
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`topic_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_bookmarks`
--

LOCK TABLES `phpbb_bookmarks` WRITE;
/*!40000 ALTER TABLE `phpbb_bookmarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_bookmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_bots`
--

DROP TABLE IF EXISTS `phpbb_bots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_bots` (
  `bot_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bot_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `bot_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `bot_agent` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bot_ip` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`bot_id`),
  KEY `bot_active` (`bot_active`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_bots`
--

LOCK TABLES `phpbb_bots` WRITE;
/*!40000 ALTER TABLE `phpbb_bots` DISABLE KEYS */;
INSERT INTO `phpbb_bots` VALUES (1,1,'AdsBot [Google]',3,'AdsBot-Google',''),(2,1,'Alexa [Bot]',4,'ia_archiver',''),(3,1,'Alta Vista [Bot]',5,'Scooter/',''),(4,1,'Ask Jeeves [Bot]',6,'Ask Jeeves',''),(5,1,'Baidu [Spider]',7,'Baiduspider',''),(6,1,'Bing [Bot]',8,'bingbot/',''),(7,1,'DuckDuckGo [Bot]',9,'DuckDuckBot/',''),(8,1,'Exabot [Bot]',10,'Exabot',''),(9,1,'FAST Enterprise [Crawler]',11,'FAST Enterprise Crawler',''),(10,1,'FAST WebCrawler [Crawler]',12,'FAST-WebCrawler/',''),(11,1,'Francis [Bot]',13,'http://www.neomo.de/',''),(12,1,'Gigabot [Bot]',14,'Gigabot/',''),(13,1,'Google Adsense [Bot]',15,'Mediapartners-Google',''),(14,1,'Google Desktop',16,'Google Desktop',''),(15,1,'Google Feedfetcher',17,'Feedfetcher-Google',''),(16,1,'Google [Bot]',18,'Googlebot',''),(17,1,'Heise IT-Markt [Crawler]',19,'heise-IT-Markt-Crawler',''),(18,1,'Heritrix [Crawler]',20,'heritrix/1.',''),(19,1,'IBM Research [Bot]',21,'ibm.com/cs/crawler',''),(20,1,'ICCrawler - ICjobs',22,'ICCrawler - ICjobs',''),(21,1,'ichiro [Crawler]',23,'ichiro/',''),(22,1,'Majestic-12 [Bot]',24,'MJ12bot/',''),(23,1,'Metager [Bot]',25,'MetagerBot/',''),(24,1,'MSN NewsBlogs',26,'msnbot-NewsBlogs/',''),(25,1,'MSN [Bot]',27,'msnbot/',''),(26,1,'MSNbot Media',28,'msnbot-media/',''),(27,1,'Nutch [Bot]',29,'http://lucene.apache.org/nutch/',''),(28,1,'Online link [Validator]',30,'online link validator',''),(29,1,'psbot [Picsearch]',31,'psbot/0',''),(30,1,'Sensis [Crawler]',32,'Sensis Web Crawler',''),(31,1,'SEO Crawler',33,'SEO search Crawler/',''),(32,1,'Seoma [Crawler]',34,'Seoma [SEO Crawler]',''),(33,1,'SEOSearch [Crawler]',35,'SEOsearch/',''),(34,1,'Snappy [Bot]',36,'Snappy/1.1 ( http://www.urltrends.com/ )',''),(35,1,'Steeler [Crawler]',37,'http://www.tkl.iis.u-tokyo.ac.jp/~crawler/',''),(36,1,'Telekom [Bot]',38,'crawleradmin.t-info@telekom.de',''),(37,1,'TurnitinBot [Bot]',39,'TurnitinBot/',''),(38,1,'Voyager [Bot]',40,'voyager/',''),(39,1,'W3 [Sitesearch]',41,'W3 SiteSearch Crawler',''),(40,1,'W3C [Linkcheck]',42,'W3C-checklink/',''),(41,1,'W3C [Validator]',43,'W3C_Validator',''),(42,1,'YaCy [Bot]',44,'yacybot',''),(43,1,'Yahoo MMCrawler [Bot]',45,'Yahoo-MMCrawler/',''),(44,1,'Yahoo Slurp [Bot]',46,'Yahoo! DE Slurp',''),(45,1,'Yahoo [Bot]',47,'Yahoo! Slurp',''),(46,1,'YahooSeeker [Bot]',48,'YahooSeeker/','');
/*!40000 ALTER TABLE `phpbb_bots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_config`
--

DROP TABLE IF EXISTS `phpbb_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_config` (
  `config_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `config_value` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `is_dynamic` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`config_name`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_config`
--

LOCK TABLES `phpbb_config` WRITE;
/*!40000 ALTER TABLE `phpbb_config` DISABLE KEYS */;
INSERT INTO `phpbb_config` VALUES ('abbc3_bbcode_bar','1',0),('abbc3_icons_type','png',0),('abbc3_pipes','1',0),('abbc3_qr_bbcodes','1',0),('abbc3_reparse','1606582154',0),('active_sessions','0',0),('allow_attachments','1',0),('allow_autologin','1',0),('allow_avatar','1',0),('allow_avatar_gravatar','1',0),('allow_avatar_local','1',0),('allow_avatar_remote','0',0),('allow_avatar_remote_upload','0',0),('allow_avatar_upload','1',0),('allow_bbcode','1',0),('allow_birthdays','1',0),('allow_board_notifications','1',0),('allow_bookmarks','1',0),('allow_cdn','0',0),('allow_emailreuse','0',0),('allow_forum_notify','1',0),('allow_live_searches','1',0),('allow_mass_pm','1',0),('allow_name_chars','USERNAME_LETTER_NUM',0),('allow_namechange','0',0),('allow_nocensors','0',0),('allow_password_reset','1',0),('allow_pm_attach','0',0),('allow_pm_report','1',0),('allow_post_flash','1',0),('allow_post_links','1',0),('allow_privmsg','1',0),('allow_quick_reply','1',0),('allow_sig','1',0),('allow_sig_bbcode','1',0),('allow_sig_flash','0',0),('allow_sig_img','1',0),('allow_sig_links','1',0),('allow_sig_pm','1',0),('allow_sig_smilies','1',0),('allow_smilies','1',0),('allow_topic_notify','1',0),('allow_viglink_phpbb','1',0),('allowed_schemes_links','http,https,ftp',0),('assets_version','32',0),('attachment_quota','52428800',0),('auth_bbcode_pm','1',0),('auth_flash_pm','0',0),('auth_img_pm','1',0),('auth_method','db',0),('auth_oauth_bitly_key','',0),('auth_oauth_bitly_secret','',0),('auth_oauth_facebook_key','',0),('auth_oauth_facebook_secret','',0),('auth_oauth_google_key','',0),('auth_oauth_google_secret','',0),('auth_oauth_twitter_key','',0),('auth_oauth_twitter_secret','',0),('auth_smilies_pm','1',0),('avatar_filesize','40960',0),('avatar_gallery_path','images/avatars/gallery',0),('avatar_max_height','90',0),('avatar_max_width','90',0),('avatar_min_height','20',0),('avatar_min_width','20',0),('avatar_path','images/avatars/upload',0),('avatar_salt','3e05b0c423b52629d33d5a5d204593c7',0),('board_contact','admin@igame-rpg.de',0),('board_contact_name','',0),('board_disable','0',0),('board_disable_msg','',0),('board_email','admin@igame-rpg.de',0),('board_email_form','0',0),('board_email_sig','Danke, die Board-Administration',0),('board_hide_emails','1',0),('board_index_text','',0),('board_startdate','1606579381',0),('board_timezone','UTC',0),('browser_check','1',0),('bump_interval','10',0),('bump_type','d',0),('cache_gc','7200',0),('cache_last_gc','1607736852',1),('captcha_gd','1',0),('captcha_gd_3d_noise','1',0),('captcha_gd_fonts','1',0),('captcha_gd_foreground_noise','0',0),('captcha_gd_wave','0',0),('captcha_gd_x_grid','25',0),('captcha_gd_y_grid','25',0),('captcha_plugin','core.captcha.plugins.gd',0),('check_attachment_content','1',0),('check_dnsbl','0',0),('chg_passforce','30',0),('confirm_refresh','1',0),('contact_admin_form_enable','1',0),('cookie_domain','igame-rpg.de',0),('cookie_name','phpbb3_kqqst',0),('cookie_notice','0',0),('cookie_path','/',0),('cookie_secure','1',0),('coppa_enable','0',0),('coppa_fax','',0),('coppa_mail','',0),('cron_lock','0',1),('dark1_mas','1',0),('dark1_mas_avatar','1',0),('dark1_mas_col_off','FF0000',0),('dark1_mas_col_on','00FF00',0),('dark1_mas_ml_av','1',0),('dark1_mas_ml_av_sz','50',0),('dark1_mas_ml_ol','1',0),('dark1_mas_online','1',0),('dark1_mas_rv_av','1',0),('dark1_mas_rv_av_sz','20',0),('dark1_mas_rv_ol','1',0),('dark1_mas_sh_fp_av','1',0),('dark1_mas_sh_fp_av_sz','20',0),('dark1_mas_sh_fp_ol','1',0),('dark1_mas_sh_lp_av','1',0),('dark1_mas_sh_lp_av_sz','20',0),('dark1_mas_sh_lp_ol','1',0),('dark1_mas_sh_up_av','1',0),('dark1_mas_sh_up_av_sz','20',0),('dark1_mas_sh_up_ol','1',0),('dark1_mas_vf_fp_av','1',0),('dark1_mas_vf_fp_av_sz','20',0),('dark1_mas_vf_fp_ol','1',0),('dark1_mas_vf_lp_av','1',0),('dark1_mas_vf_lp_av_sz','20',0),('dark1_mas_vf_lp_ol','1',0),('dark1_mas_vo_pg_av','1',0),('dark1_mas_vo_pg_av_sz','20',0),('dark1_mas_vo_sb_av','1',0),('dark1_mas_vo_sb_av_sz','20',0),('database_gc','604800',0),('database_last_gc','1607197259',1),('dbms_version','10.5.6-MariaDB',0),('default_dateformat','D j. M Y, H:i',0),('default_lang','de',0),('default_search_return_chars','300',0),('default_style','4',0),('delete_my_account','1',0),('delete_time','0',0),('display_last_edited','1',0),('display_last_subject','1',0),('display_order','0',0),('display_unapproved_posts','1',0),('dmzx.mchat.text_reparser.mchat_messages_cron_interval','10',0),('dmzx.mchat.text_reparser.mchat_messages_last_cron','1606598305',0),('edit_time','0',0),('email_check_mx','1',0),('email_enable','1',0),('email_force_sender','0',0),('email_max_chunk_size','50',0),('email_package_size','0',0),('enable_accurate_pm_button','1',0),('enable_confirm','1',0),('enable_mod_rewrite','0',0),('enable_pm_icons','1',0),('enable_post_confirm','1',0),('enable_queue_trigger','0',0),('enable_update_hashes','0',0),('extension_force_unstable','0',0),('feed_enable','1',0),('feed_forum','1',0),('feed_http_auth','0',0),('feed_item_statistics','1',0),('feed_limit','10',0),('feed_limit_post','15',0),('feed_limit_topic','10',0),('feed_overall','1',0),('feed_overall_forums','0',0),('feed_overall_forums_limit','15',0),('feed_overall_topics','0',0),('feed_overall_topics_limit','15',0),('feed_topic','1',0),('feed_topics_active','0',0),('feed_topics_new','1',0),('flood_interval','15',0),('force_server_vars','1',0),('form_token_lifetime','7200',0),('form_token_mintime','0',0),('form_token_sid_guests','1',0),('forward_pm','1',0),('forwarded_for_check','0',0),('full_folder_action','2',0),('fulltext_mysql_max_word_len','254',0),('fulltext_mysql_min_word_len','4',0),('fulltext_native_common_thres','5',0),('fulltext_native_load_upd','1',0),('fulltext_native_max_chars','14',0),('fulltext_native_min_chars','3',0),('fulltext_postgres_max_word_len','254',0),('fulltext_postgres_min_word_len','4',0),('fulltext_postgres_ts_name','simple',0),('fulltext_sphinx_indexer_mem_limit','512',0),('fulltext_sphinx_stopwords','0',0),('gzip_compress','0',0),('help_send_statistics','1',0),('help_send_statistics_time','1606855014',0),('hot_threshold','25',0),('icons_path','images/icons',0),('img_create_thumbnail','0',0),('img_display_inlined','1',0),('img_link_height','0',0),('img_link_width','0',0),('img_max_height','0',0),('img_max_thumb_width','400',0),('img_max_width','0',0),('img_min_thumb_filesize','12000',0),('img_quality','85',0),('img_strip_metadata','0',0),('ip_check','3',0),('ip_login_limit_max','50',0),('ip_login_limit_time','21600',0),('ip_login_limit_use_forwarded','0',0),('jab_allow_self_signed','0',0),('jab_enable','0',0),('jab_host','',0),('jab_package_size','20',0),('jab_password','',0),('jab_port','5222',0),('jab_use_ssl','0',0),('jab_username','',0),('jab_verify_peer','1',0),('jab_verify_peer_name','1',0),('last_queue_run','0',1),('ldap_base_dn','',0),('ldap_email','',0),('ldap_password','',0),('ldap_port','',0),('ldap_server','',0),('ldap_uid','',0),('ldap_user','',0),('ldap_user_filter','',0),('legend_sort_groupname','0',0),('limit_load','0',0),('limit_search_load','0',0),('load_anon_lastread','0',0),('load_birthdays','1',0),('load_cpf_memberlist','1',0),('load_cpf_pm','1',0),('load_cpf_viewprofile','1',0),('load_cpf_viewtopic','1',0),('load_db_lastread','1',0),('load_db_track','1',0),('load_font_awesome_url','https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css',0),('load_jquery_url','//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js',0),('load_jumpbox','1',0),('load_moderators','1',0),('load_notifications','1',0),('load_online','1',0),('load_online_guests','1',0),('load_online_time','5',0),('load_onlinetrack','1',0),('load_search','1',0),('load_tplcompile','0',0),('load_unreads_search','1',0),('load_user_activity','1',0),('load_user_activity_limit','5000',0),('max_attachments','3',0),('max_attachments_pm','1',0),('max_autologin_time','0',0),('max_filesize','262144',0),('max_filesize_pm','262144',0),('max_login_attempts','3',0),('max_name_chars','20',0),('max_num_search_keywords','10',0),('max_poll_options','10',0),('max_post_chars','60000',0),('max_post_font_size','200',0),('max_post_img_height','0',0),('max_post_img_width','0',0),('max_post_smilies','0',0),('max_post_urls','0',0),('max_quote_depth','3',0),('max_reg_attempts','5',0),('max_sig_chars','255',0),('max_sig_font_size','200',0),('max_sig_img_height','0',0),('max_sig_img_width','0',0),('max_sig_smilies','0',0),('max_sig_urls','5',0),('max_spoiler_depth','3',0),('mchat_archive_sort','1',0),('mchat_avatars','1',0),('mchat_bbcode_disallowed','',0),('mchat_capital_letter','1',0),('mchat_character_count','1',0),('mchat_custom_height','350',0),('mchat_custom_page','1',0),('mchat_date','D M d, Y g:i a',0),('mchat_edit_delete_limit','0',0),('mchat_flood_messages','0',0),('mchat_flood_time','0',0),('mchat_index','1',0),('mchat_index_height','250',0),('mchat_live_updates','1',0),('mchat_location','1',0),('mchat_log_enabled','1',0),('mchat_max_input_height','150',0),('mchat_max_message_lngth','500',0),('mchat_message_num_archive','25',0),('mchat_message_num_custom','10',0),('mchat_message_num_index','10',0),('mchat_message_top','1',0),('mchat_navbar_link_count','1',0),('mchat_override_min_post_chars','0',0),('mchat_override_smilie_limit','0',0),('mchat_posts','1',0),('mchat_posts_auth_check','1',0),('mchat_posts_edit','1',0),('mchat_posts_login','0',0),('mchat_posts_quote','1',0),('mchat_posts_reply','1',0),('mchat_posts_topic','1',0),('mchat_prune','1',0),('mchat_prune_gc','86400',0),('mchat_prune_last_gc','1607718256',1),('mchat_prune_mode','0',0),('mchat_prune_num','0',0),('mchat_refresh','10',0),('mchat_relative_time','1',0),('mchat_sound','1',0),('mchat_stats_index','1',0),('mchat_timeout','0',0),('mchat_version','2.1.4',0),('mchat_whois_index','1',0),('mchat_whois_refresh','60',0),('mime_triggers','body|head|html|img|plaintext|a href|pre|script|table|title',0),('min_name_chars','3',0),('min_pass_chars','6',0),('min_post_chars','1',0),('min_search_author_chars','3',0),('new_member_group_default','0',0),('new_member_post_limit','3',0),('newest_user_colour','',1),('newest_user_id','51',1),('newest_username','TestNutzer',1),('num_files','0',1),('num_posts','1',1),('num_topics','1',1),('num_users','1',1),('override_user_style','1',0),('pass_complex','PASS_TYPE_SYMBOL',0),('phpbb_viglink_api_key','e4fd14f5d7f2bb6d80b8f8da1354718c',0),('plupload_last_gc','0',1),('plupload_salt','46991ce4354ca6d56bfeded88a2f31fa',0),('pm_edit_time','0',0),('pm_max_boxes','4',0),('pm_max_msgs','50',0),('pm_max_recipients','0',0),('pmwelcome_sender','Zenturion',0),('pmwelcome_subject','Willkommen im Forum.',0),('pmwelcome_user','2',0),('posts_per_page','10',0),('print_pm','1',0),('questionnaire_unique_id','0ef8ai450xfn1c9x',0),('queue_interval','60',0),('queue_trigger_posts','3',0),('rand_seed','0',1),('rand_seed_last_update','0',1),('ranks_path','images/ranks',0),('read_notification_expire_days','30',0),('read_notification_gc','86400',0),('read_notification_last_gc','1607717215',1),('recaptcha_v3_domain','google.com',0),('recaptcha_v3_key','',0),('recaptcha_v3_method','post',0),('recaptcha_v3_secret','',0),('recaptcha_v3_threshold_default','0.5',0),('recaptcha_v3_threshold_login','0.5',0),('recaptcha_v3_threshold_post','0.5',0),('recaptcha_v3_threshold_register','0.5',0),('recaptcha_v3_threshold_report','0.5',0),('record_online_date','1606581505',1),('record_online_users','3',1),('referer_validation','0',0),('remote_upload_verify','0',0),('reparse_lock','0',1),('require_activation','1',0),('script_path','/forum',0),('search_anonymous_interval','0',0),('search_block_size','250',0),('search_gc','7200',0),('search_indexing_state','',1),('search_interval','0',0),('search_last_gc','1607737618',1),('search_store_results','1800',0),('search_type','\\phpbb\\search\\fulltext_native',0),('secure_allow_deny','1',0),('secure_allow_empty_referer','1',0),('secure_downloads','0',0),('senky_akismet_add_registering_blatant_spammers_to_group','7',0),('senky_akismet_add_registering_spammers_to_group','7',0),('senky_akismet_api_key','08a288048891',0),('senky_akismet_check_admin_form','1',0),('senky_akismet_check_registrations','1',0),('senky_akismet_skip_check_after_n_posts','3',0),('server_name','igame-rpg.de',0),('server_port','443',0),('server_protocol','https://',0),('session_gc','3600',0),('session_last_gc','1607741451',1),('session_length','3600',0),('site_desc','You\'re Welcome',0),('site_home_text','',0),('site_home_url','',0),('sitemaker.table_lock.menu_items_table','0',1),('sitemaker_blocks_cleanup_gc','604800',0),('sitemaker_blocks_cleanup_last_gc','1607717198',1),('sitemaker_column_widths','[]',0),('sitemaker_default_layout','',0),('sitemaker_last_changed','0',0),('sitemaker_startpage_controller','',0),('sitemaker_startpage_method','',0),('sitemaker_startpage_params','',0),('sitename','IgameRPG Forum',0),('sm_filemanager','0',0),('sm_forum_icon','fa fa-comments-o',0),('sm_hide_birthday','0',0),('sm_hide_login','1',0),('sm_hide_online','1',0),('sm_navbar_menu','0',0),('sm_orphaned_blocks','',0),('sm_show_forum_nav','1',0),('smilies_path','images/smilies',0),('smilies_per_page','50',0),('smtp_allow_self_signed','0',0),('smtp_auth_method','PLAIN',0),('smtp_delivery','1',0),('smtp_host','igame-rpg.de',0),('smtp_password','Maxmolda23!!',1),('smtp_port','25',0),('smtp_username','admin@igame-rpg.de',1),('smtp_verify_peer','1',0),('smtp_verify_peer_name','1',0),('stevotvr_flair_cron_last_run','1607744760',0),('stevotvr_flair_display_limit','3',0),('stevotvr_flair_notify_users','1',0),('stevotvr_flair_show_on_posts','1',0),('stevotvr_flair_show_on_profile','1',0),('teampage_forums','1',0),('teampage_memberships','1',0),('text_reparser.pm_text_cron_interval','10',0),('text_reparser.pm_text_last_cron','1606581571',0),('text_reparser.poll_option_cron_interval','10',0),('text_reparser.poll_option_last_cron','1607744566',0),('text_reparser.poll_title_cron_interval','10',0),('text_reparser.poll_title_last_cron','1606580394',0),('text_reparser.post_text_cron_interval','10',0),('text_reparser.post_text_last_cron','1606582190',0),('text_reparser.user_signature_cron_interval','10',0),('text_reparser.user_signature_last_cron','1606580420',0),('topic_preview_avatars','1',0),('topic_preview_delay','1000',0),('topic_preview_drift','15',0),('topic_preview_last_post','1',0),('topic_preview_limit','150',0),('topic_preview_strip_bbcodes','',0),('topic_preview_width','360',0),('topics_per_page','25',0),('tpl_allow_php','0',0),('update_hashes_last_cron','1606580383',0),('update_hashes_lock','0',0),('upload_dir_size','0',1),('upload_icons_path','images/upload_icons',0),('upload_path','files',0),('use_system_cron','0',0),('version','3.3.2',0),('viglink_api_siteid','d41d8cd98f00b204e9800998ecf8427e',0),('viglink_ask_admin','1606855014',0),('viglink_ask_admin_last','1606854993',0),('viglink_convert_account_url','',0),('viglink_enabled','',0),('viglink_last_gc','1607737352',1),('warnings_expire_days','90',0),('warnings_gc','14400',0),('warnings_last_gc','1607731668',1);
/*!40000 ALTER TABLE `phpbb_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_config_text`
--

DROP TABLE IF EXISTS `phpbb_config_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_config_text` (
  `config_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `config_value` mediumtext COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`config_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_config_text`
--

LOCK TABLES `phpbb_config_text` WRITE;
/*!40000 ALTER TABLE `phpbb_config_text` DISABLE KEYS */;
INSERT INTO `phpbb_config_text` VALUES ('contact_admin_info',''),('contact_admin_info_bitfield',''),('contact_admin_info_flags','7'),('contact_admin_info_uid',''),('mchat_rules','Die Chatbox ist nicht f&#252;r Hilfeanfragen gedacht!'),('mchat_static_message','Die Chatbox ist nicht f&#252;r Hilfeanfragen gedacht!'),('pmwelcome_post_text','Hallo und Willkommen {USERNAME},\n\nIch begrüße dich herzlich hier im Forum...\n\nBevor es Losgeht bitte ich dich einmal unsere Forumregeln zu lesen.\n[url=https://igame-rpg.de/forum/viewtopic.php?f=6&amp;t=3]Regeln[/url]\n\nDanach würde ich mich freuen wenn du die Kurz in der Lounge Vorstellst\nErzähle etwas über dich. Deine Erfahrungen in Sachen TextSpiele würden uns gerne interessieren.\n\nWeiterhin kannst du auch die [url=https://game.igame-rpg.de/docu/index.php?title=Hauptseite]Doku[/url] lesen.\n\nAnsonsten viel Spaß :)'),('pmwelcome_text_bitfield',''),('pmwelcome_text_flags','7'),('pmwelcome_text_uid',''),('reparser_resume','a:5:{s:24:\"text_reparser.poll_title\";a:3:{s:9:\"range-min\";i:1;s:9:\"range-max\";i:0;s:10:\"range-size\";i:100;}s:28:\"text_reparser.user_signature\";a:3:{s:9:\"range-min\";i:1;s:9:\"range-max\";i:0;s:10:\"range-size\";i:100;}s:23:\"text_reparser.post_text\";a:3:{s:9:\"range-min\";i:1;s:9:\"range-max\";i:0;s:10:\"range-size\";i:100;}s:21:\"text_reparser.pm_text\";a:3:{s:9:\"range-min\";i:1;s:9:\"range-max\";i:0;s:10:\"range-size\";i:100;}s:39:\"dmzx.mchat.text_reparser.mchat_messages\";a:3:{s:9:\"range-min\";i:1;s:9:\"range-max\";i:0;s:10:\"range-size\";i:100;}}'),('sm_layout_prefs','{\"2\":{\"layout\":\".\\/..\\/ext\\/blitze\\/sitemaker\\/styles\\/all\\/template\\/layouts\\/portal\\/\",\"view\":\"simple\"},\"1\":{\"layout\":\".\\/..\\/ext\\/blitze\\/sitemaker\\/styles\\/all\\/template\\/layouts\\/portal\\/\",\"view\":\"simple\"},\"4\":{\"layout\":\".\\/..\\/ext\\/blitze\\/sitemaker\\/styles\\/all\\/template\\/layouts\\/portal\\/\",\"view\":\"basic\"}}');
/*!40000 ALTER TABLE `phpbb_config_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_confirm`
--

DROP TABLE IF EXISTS `phpbb_confirm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_confirm` (
  `confirm_id` char(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `session_id` char(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `confirm_type` tinyint(3) NOT NULL DEFAULT 0,
  `code` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `seed` int(10) unsigned NOT NULL DEFAULT 0,
  `attempts` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`session_id`,`confirm_id`),
  KEY `confirm_type` (`confirm_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_confirm`
--

LOCK TABLES `phpbb_confirm` WRITE;
/*!40000 ALTER TABLE `phpbb_confirm` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_confirm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_disallow`
--

DROP TABLE IF EXISTS `phpbb_disallow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_disallow` (
  `disallow_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `disallow_username` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`disallow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_disallow`
--

LOCK TABLES `phpbb_disallow` WRITE;
/*!40000 ALTER TABLE `phpbb_disallow` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_disallow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_drafts`
--

DROP TABLE IF EXISTS `phpbb_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_drafts` (
  `draft_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `save_time` int(11) unsigned NOT NULL DEFAULT 0,
  `draft_subject` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `draft_message` mediumtext COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`draft_id`),
  KEY `save_time` (`save_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_drafts`
--

LOCK TABLES `phpbb_drafts` WRITE;
/*!40000 ALTER TABLE `phpbb_drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_ext`
--

DROP TABLE IF EXISTS `phpbb_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_ext` (
  `ext_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `ext_active` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `ext_state` text COLLATE utf8_bin NOT NULL,
  UNIQUE KEY `ext_name` (`ext_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_ext`
--

LOCK TABLES `phpbb_ext` WRITE;
/*!40000 ALTER TABLE `phpbb_ext` DISABLE KEYS */;
INSERT INTO `phpbb_ext` VALUES ('alex75/welcomeback',0,'b:0;'),('alfredoramos/simplespoiler',1,'b:0;'),('apwa/pmwelcome',1,'b:0;'),('blitze/sitemaker',1,'b:0;'),('brokencrust/deletemyaccount',1,'b:0;'),('dark1/memberavatarstatus',1,'b:0;'),('dmzx/mchat',1,'b:0;'),('hifikabin/clock',1,'b:0;'),('hifikabin/largefont',1,'b:0;'),('hifikabin/quotethumbnails',1,'b:0;'),('phpbb/topicprefixes',1,'b:0;'),('phpbb/viglink',1,'b:0;'),('phpbbes/age',1,'b:0;'),('phpbbes/catbgimg',1,'b:0;'),('rmcgirr83/birthdaycake',1,'b:0;'),('rmcgirr83/genders',1,'b:0;'),('rmcgirr83/topicicononindex',1,'b:0;'),('rxu/firstpostoneverypage',1,'b:0;'),('rxu/listsubforumsincolumns',1,'b:0;'),('senky/akismet',1,'b:0;'),('senky/simplewysiwyg',1,'b:0;'),('stevotvr/flair',1,'b:0;'),('sylver35/ajaxpreview',0,'b:0;'),('vse/abbc3',0,'b:0;'),('vse/pmbars',1,'b:0;'),('vse/topicpreview',1,'b:0;');
/*!40000 ALTER TABLE `phpbb_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_extension_groups`
--

DROP TABLE IF EXISTS `phpbb_extension_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_extension_groups` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `cat_id` tinyint(2) NOT NULL DEFAULT 0,
  `allow_group` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `download_mode` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `upload_icon` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `max_filesize` int(20) unsigned NOT NULL DEFAULT 0,
  `allowed_forums` text COLLATE utf8_bin NOT NULL,
  `allow_in_pm` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_extension_groups`
--

LOCK TABLES `phpbb_extension_groups` WRITE;
/*!40000 ALTER TABLE `phpbb_extension_groups` DISABLE KEYS */;
INSERT INTO `phpbb_extension_groups` VALUES (1,'IMAGES',1,1,1,'',0,'',0),(2,'ARCHIVES',0,1,1,'',0,'',0),(3,'PLAIN_TEXT',0,0,1,'',0,'',0),(4,'DOCUMENTS',0,0,1,'',0,'',0),(5,'DOWNLOADABLE_FILES',0,0,1,'',0,'',0);
/*!40000 ALTER TABLE `phpbb_extension_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_extensions`
--

DROP TABLE IF EXISTS `phpbb_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_extensions` (
  `extension_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `extension` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`extension_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_extensions`
--

LOCK TABLES `phpbb_extensions` WRITE;
/*!40000 ALTER TABLE `phpbb_extensions` DISABLE KEYS */;
INSERT INTO `phpbb_extensions` VALUES (1,1,'gif'),(2,1,'png'),(3,1,'jpeg'),(4,1,'jpg'),(5,1,'tif'),(6,1,'tiff'),(7,1,'tga'),(8,2,'gtar'),(9,2,'gz'),(10,2,'tar'),(11,2,'zip'),(12,2,'rar'),(13,2,'ace'),(14,2,'torrent'),(15,2,'tgz'),(16,2,'bz2'),(17,2,'7z'),(18,3,'txt'),(19,3,'c'),(20,3,'h'),(21,3,'cpp'),(22,3,'hpp'),(23,3,'diz'),(24,3,'csv'),(25,3,'ini'),(26,3,'log'),(27,3,'js'),(28,3,'xml'),(29,4,'xls'),(30,4,'xlsx'),(31,4,'xlsm'),(32,4,'xlsb'),(33,4,'doc'),(34,4,'docx'),(35,4,'docm'),(36,4,'dot'),(37,4,'dotx'),(38,4,'dotm'),(39,4,'pdf'),(40,4,'ai'),(41,4,'ps'),(42,4,'ppt'),(43,4,'pptx'),(44,4,'pptm'),(45,4,'odg'),(46,4,'odp'),(47,4,'ods'),(48,4,'odt'),(49,4,'rtf'),(50,5,'mp3'),(51,5,'mpeg'),(52,5,'mpg'),(53,5,'ogg'),(54,5,'ogm');
/*!40000 ALTER TABLE `phpbb_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_flair`
--

DROP TABLE IF EXISTS `phpbb_flair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_flair` (
  `flair_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `flair_category` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `flair_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `flair_desc` text COLLATE utf8_bin NOT NULL,
  `flair_desc_bbcode_uid` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `flair_desc_bbcode_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `flair_desc_bbcode_options` int(11) unsigned NOT NULL DEFAULT 7,
  `flair_order` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `flair_color` varchar(6) COLLATE utf8_bin NOT NULL DEFAULT '',
  `flair_icon` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `flair_icon_color` varchar(6) COLLATE utf8_bin NOT NULL DEFAULT '',
  `flair_font_color` varchar(6) COLLATE utf8_bin NOT NULL DEFAULT '',
  `flair_type` smallint(4) unsigned NOT NULL DEFAULT 0,
  `flair_img` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `flair_groups_auto` tinyint(1) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`flair_id`),
  KEY `c` (`flair_category`),
  KEY `o` (`flair_order`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_flair`
--

LOCK TABLES `phpbb_flair` WRITE;
/*!40000 ALTER TABLE `phpbb_flair` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_flair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_flair_cats`
--

DROP TABLE IF EXISTS `phpbb_flair_cats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_flair_cats` (
  `cat_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `cat_order` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `cat_display_profile` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `cat_display_posts` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `cat_display_limit` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`cat_id`),
  KEY `o` (`cat_order`),
  KEY `dpr` (`cat_display_profile`),
  KEY `dpo` (`cat_display_posts`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_flair_cats`
--

LOCK TABLES `phpbb_flair_cats` WRITE;
/*!40000 ALTER TABLE `phpbb_flair_cats` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_flair_cats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_flair_favs`
--

DROP TABLE IF EXISTS `phpbb_flair_favs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_flair_favs` (
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `flair_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`flair_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_flair_favs`
--

LOCK TABLES `phpbb_flair_favs` WRITE;
/*!40000 ALTER TABLE `phpbb_flair_favs` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_flair_favs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_flair_groups`
--

DROP TABLE IF EXISTS `phpbb_flair_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_flair_groups` (
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `flair_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`flair_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_flair_groups`
--

LOCK TABLES `phpbb_flair_groups` WRITE;
/*!40000 ALTER TABLE `phpbb_flair_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_flair_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_flair_notif`
--

DROP TABLE IF EXISTS `phpbb_flair_notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_flair_notif` (
  `notification_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `flair_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `flair_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `old_count` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `new_count` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `updated` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`notification_id`),
  UNIQUE KEY `u_f` (`user_id`,`flair_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_flair_notif`
--

LOCK TABLES `phpbb_flair_notif` WRITE;
/*!40000 ALTER TABLE `phpbb_flair_notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_flair_notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_flair_triggers`
--

DROP TABLE IF EXISTS `phpbb_flair_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_flair_triggers` (
  `flair_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `trig_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `trig_value` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`flair_id`,`trig_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_flair_triggers`
--

LOCK TABLES `phpbb_flair_triggers` WRITE;
/*!40000 ALTER TABLE `phpbb_flair_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_flair_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_flair_users`
--

DROP TABLE IF EXISTS `phpbb_flair_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_flair_users` (
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `flair_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `flair_count` mediumint(8) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`flair_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_flair_users`
--

LOCK TABLES `phpbb_flair_users` WRITE;
/*!40000 ALTER TABLE `phpbb_flair_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_flair_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_forums`
--

DROP TABLE IF EXISTS `phpbb_forums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_forums` (
  `forum_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `left_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `right_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `forum_parents` mediumtext COLLATE utf8_bin NOT NULL,
  `forum_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_desc` text COLLATE utf8_bin NOT NULL,
  `forum_desc_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_desc_options` int(11) unsigned NOT NULL DEFAULT 7,
  `forum_desc_uid` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_link` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_password` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_style` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `forum_image` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_rules` text COLLATE utf8_bin NOT NULL,
  `forum_rules_link` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_rules_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_rules_options` int(11) unsigned NOT NULL DEFAULT 7,
  `forum_rules_uid` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_topics_per_page` smallint(4) unsigned NOT NULL DEFAULT 0,
  `forum_type` tinyint(4) NOT NULL DEFAULT 0,
  `forum_status` tinyint(4) NOT NULL DEFAULT 0,
  `forum_last_post_id` int(10) unsigned NOT NULL DEFAULT 0,
  `forum_last_poster_id` int(10) unsigned NOT NULL DEFAULT 0,
  `forum_last_post_subject` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_last_post_time` int(11) unsigned NOT NULL DEFAULT 0,
  `forum_last_poster_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_last_poster_colour` varchar(6) COLLATE utf8_bin NOT NULL DEFAULT '',
  `forum_flags` tinyint(4) NOT NULL DEFAULT 32,
  `display_on_index` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `enable_indexing` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `enable_icons` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `enable_prune` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `prune_next` int(11) unsigned NOT NULL DEFAULT 0,
  `prune_days` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `prune_viewed` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `prune_freq` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `display_subforum_list` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `display_subforum_limit` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `forum_options` int(20) unsigned NOT NULL DEFAULT 0,
  `enable_shadow_prune` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `prune_shadow_days` mediumint(8) unsigned NOT NULL DEFAULT 7,
  `prune_shadow_freq` mediumint(8) unsigned NOT NULL DEFAULT 1,
  `prune_shadow_next` int(11) NOT NULL DEFAULT 0,
  `forum_posts_approved` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `forum_posts_unapproved` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `forum_posts_softdeleted` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `forum_topics_approved` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `forum_topics_unapproved` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `forum_topics_softdeleted` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `first_post_always_show` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `forum_subforumslist_type` tinyint(4) NOT NULL DEFAULT 0,
  `hidden_forum` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`forum_id`),
  KEY `left_right_id` (`left_id`,`right_id`),
  KEY `forum_lastpost_id` (`forum_last_post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_forums`
--

LOCK TABLES `phpbb_forums` WRITE;
/*!40000 ALTER TABLE `phpbb_forums` DISABLE KEYS */;
INSERT INTO `phpbb_forums` VALUES (5,0,1,8,'','Allgemein','<t>Hier in Allgemein findet ihr Findet ihr die Forumregeln, Die Plauderecke und die Lounge.</t>','',7,'','','',4,'','','','',7,'',0,0,0,0,0,'',0,'','',32,1,1,1,0,0,7,7,1,1,0,0,0,7,1,0,0,0,0,0,0,0,0,0,0),(6,5,2,3,'a:1:{i:5;a:2:{i:0;s:9:\"Allgemein\";i:1;i:0;}}','Forumregeln','<t>Unserer Regeln sind bitte strickt einzuhalten Danke</t>','',7,'','','',4,'','','','',7,'',0,1,0,3,2,'Unserer Regeln',1607731182,'Zenturion','AA0000',48,1,0,1,0,0,7,7,1,1,0,0,0,7,1,0,1,0,0,1,0,0,0,0,0),(7,5,4,5,'','Lounge','<t>Die Lounge ist passend für Neulinge und Unerfahrene. Hier könnt ihr euch vorstellen.</t>','',7,'','','',4,'','','','',7,'',0,1,0,0,0,'',0,'','',48,1,1,1,0,0,7,7,1,1,0,0,0,7,1,0,0,0,0,0,0,0,0,0,0),(8,5,6,7,'','Plauderecke','<t>Hier kkönnt ihr über Themen reden die nicht in den bereich Textgames passen.<br/>\nAlles ist erlaubt sofern die Forumregeln eingehalten werden.</t>','',7,'','','',4,'','','https://igame-rpg.de/forum/viewtopic.php?f=6&amp;t=3','',7,'',0,1,0,0,0,'',0,'','',48,1,1,1,0,0,7,7,1,1,0,0,0,7,1,0,0,0,0,0,0,0,0,0,0),(9,0,9,14,'','IgameRPG Intern','<t>Hier werden folgende zu finden sein:<br/>\nHilfe, Bewerbungen, Beschwerde.</t>','',7,'','','',4,'','','','',7,'',0,0,0,0,0,'',0,'','',32,1,1,1,0,0,7,7,1,1,0,0,0,7,1,0,0,0,0,0,0,0,0,0,0),(10,9,10,11,'a:1:{i:9;a:2:{i:0;s:15:\"IgameRPG Intern\";i:1;i:0;}}','Hilfe','<t>Hier könnt ihr fragen rund um das Netzwerk, Den Bots, den Chatservices stelllen.<br/>\nBitte verwendet entsprechende Prefixe dafür.</t>','',7,'','','',4,'','','','',7,'',0,1,0,0,0,'',0,'','',48,1,1,1,0,0,7,7,1,1,0,0,0,7,1,0,0,0,0,0,0,0,0,0,0),(11,9,12,13,'a:1:{i:9;a:2:{i:0;s:15:\"IgameRPG Intern\";i:1;i:0;}}','Bewerbungen','<t>Hier könnt ihr euch für das Netzwerk bewerben.</t>','',7,'','','',4,'','','','',7,'',0,1,0,5,2,'Bewewrbungsvorlage',1607742660,'Zenturion','AA0000',48,1,1,1,0,0,7,7,1,1,0,0,0,7,1,0,1,0,0,1,0,0,0,0,0);
/*!40000 ALTER TABLE `phpbb_forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_forums_access`
--

DROP TABLE IF EXISTS `phpbb_forums_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_forums_access` (
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `session_id` char(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`forum_id`,`user_id`,`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_forums_access`
--

LOCK TABLES `phpbb_forums_access` WRITE;
/*!40000 ALTER TABLE `phpbb_forums_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_forums_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_forums_track`
--

DROP TABLE IF EXISTS `phpbb_forums_track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_forums_track` (
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `mark_time` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`,`forum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_forums_track`
--

LOCK TABLES `phpbb_forums_track` WRITE;
/*!40000 ALTER TABLE `phpbb_forums_track` DISABLE KEYS */;
INSERT INTO `phpbb_forums_track` VALUES (2,6,1607731183),(2,11,1607742775);
/*!40000 ALTER TABLE `phpbb_forums_track` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_forums_watch`
--

DROP TABLE IF EXISTS `phpbb_forums_watch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_forums_watch` (
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `notify_status` tinyint(1) unsigned NOT NULL DEFAULT 0,
  KEY `forum_id` (`forum_id`),
  KEY `user_id` (`user_id`),
  KEY `notify_stat` (`notify_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_forums_watch`
--

LOCK TABLES `phpbb_forums_watch` WRITE;
/*!40000 ALTER TABLE `phpbb_forums_watch` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_forums_watch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_groups`
--

DROP TABLE IF EXISTS `phpbb_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_groups` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `group_type` tinyint(4) NOT NULL DEFAULT 1,
  `group_founder_manage` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `group_skip_auth` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `group_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `group_desc` text COLLATE utf8_bin NOT NULL,
  `group_desc_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `group_desc_options` int(11) unsigned NOT NULL DEFAULT 7,
  `group_desc_uid` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `group_display` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `group_avatar` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `group_avatar_type` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `group_avatar_width` smallint(4) unsigned NOT NULL DEFAULT 0,
  `group_avatar_height` smallint(4) unsigned NOT NULL DEFAULT 0,
  `group_rank` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `group_colour` varchar(6) COLLATE utf8_bin NOT NULL DEFAULT '',
  `group_sig_chars` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `group_receive_pm` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `group_message_limit` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `group_legend` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `group_max_recipients` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`group_id`),
  KEY `group_legend_name` (`group_legend`,`group_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_groups`
--

LOCK TABLES `phpbb_groups` WRITE;
/*!40000 ALTER TABLE `phpbb_groups` DISABLE KEYS */;
INSERT INTO `phpbb_groups` VALUES (1,3,0,0,'GUESTS','','',7,'',0,'','',0,0,0,'',0,0,0,0,5),(2,3,0,0,'REGISTERED','','',7,'',0,'','',0,0,0,'',0,0,0,0,5),(3,3,0,0,'REGISTERED_COPPA','','',7,'',0,'','',0,0,0,'',0,0,0,0,5),(4,3,0,0,'GLOBAL_MODERATORS','','',7,'',0,'','',0,0,0,'00AA00',0,0,0,2,0),(5,3,1,0,'ADMINISTRATORS','','',7,'',0,'','',0,0,0,'AA0000',0,0,0,1,0),(6,3,0,0,'BOTS','','',7,'',0,'','',0,0,0,'9E8DA7',0,0,0,0,5),(7,3,0,0,'NEWLY_REGISTERED','','',7,'',0,'','',0,0,0,'',0,0,0,0,5);
/*!40000 ALTER TABLE `phpbb_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_icons`
--

DROP TABLE IF EXISTS `phpbb_icons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_icons` (
  `icons_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `icons_url` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `icons_width` tinyint(4) NOT NULL DEFAULT 0,
  `icons_height` tinyint(4) NOT NULL DEFAULT 0,
  `icons_alt` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `icons_order` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `display_on_posting` tinyint(1) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`icons_id`),
  KEY `display_on_posting` (`display_on_posting`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_icons`
--

LOCK TABLES `phpbb_icons` WRITE;
/*!40000 ALTER TABLE `phpbb_icons` DISABLE KEYS */;
INSERT INTO `phpbb_icons` VALUES (1,'misc/fire.gif',16,16,'',1,1),(2,'smile/redface.gif',16,16,'',9,1),(3,'smile/mrgreen.gif',16,16,'',10,1),(4,'misc/heart.gif',16,16,'',4,1),(5,'misc/star.gif',16,16,'',2,1),(6,'misc/radioactive.gif',16,16,'',3,1),(7,'misc/thinking.gif',16,16,'',5,1),(8,'smile/info.gif',16,16,'',8,1),(9,'smile/question.gif',16,16,'',6,1),(10,'smile/alert.gif',16,16,'',7,1);
/*!40000 ALTER TABLE `phpbb_icons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_lang`
--

DROP TABLE IF EXISTS `phpbb_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_lang` (
  `lang_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `lang_iso` varchar(30) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lang_dir` varchar(30) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lang_english_name` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lang_local_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lang_author` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`lang_id`),
  KEY `lang_iso` (`lang_iso`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_lang`
--

LOCK TABLES `phpbb_lang` WRITE;
/*!40000 ALTER TABLE `phpbb_lang` DISABLE KEYS */;
INSERT INTO `phpbb_lang` VALUES (1,'de','de','German (Casual Honorifics)','Deutsch (Du)','phpBB.de'),(2,'de_x_sie','de_x_sie','German (Formal Honorifics)','Deutsch (Sie)','phpBB.de'),(3,'en','en','British English','British English','phpBB Limited');
/*!40000 ALTER TABLE `phpbb_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_log`
--

DROP TABLE IF EXISTS `phpbb_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_log` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` tinyint(4) NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `post_id` int(10) unsigned NOT NULL DEFAULT 0,
  `reportee_id` int(10) unsigned NOT NULL DEFAULT 0,
  `log_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `log_time` int(11) unsigned NOT NULL DEFAULT 0,
  `log_operation` text COLLATE utf8_bin NOT NULL,
  `log_data` mediumtext COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `forum_id` (`forum_id`),
  KEY `topic_id` (`topic_id`),
  KEY `reportee_id` (`reportee_id`),
  KEY `user_id` (`user_id`),
  KEY `log_time` (`log_time`)
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_log`
--

LOCK TABLES `phpbb_log` WRITE;
/*!40000 ALTER TABLE `phpbb_log` DISABLE KEYS */;
INSERT INTO `phpbb_log` VALUES (1,0,1,0,0,0,0,'178.4.43.135',1606579521,'LOG_MODULE_ADD','a:1:{i:0;s:20:\"ACP_VIGLINK_SETTINGS\";}'),(2,0,1,0,0,0,0,'',1606579523,'LOG_EXT_ENABLE','a:1:{i:0;s:13:\"phpbb/viglink\";}'),(3,0,2,0,0,0,0,'178.4.43.135',1606579526,'LOG_INSTALL_INSTALLED','a:1:{i:0;s:5:\"3.3.2\";}'),(4,0,2,0,0,0,0,'178.4.43.135',1606580206,'LOG_STYLE_ADD','a:1:{i:0;s:10:\"BlackBoard\";}'),(5,0,49,0,0,0,0,'178.4.43.135',1606581404,'LOG_ADMIN_AUTH_SUCCESS',''),(6,3,49,0,0,0,2,'178.4.43.135',1606581463,'LOG_USER_NEW_PASSWORD','a:1:{i:0;s:9:\"Zenturion\";}'),(7,0,49,0,0,0,0,'178.4.43.135',1606581464,'LOG_USER_USER_UPDATE','a:1:{i:0;s:9:\"Zenturion\";}'),(8,0,2,0,0,0,0,'178.4.43.135',1606581518,'LOG_ADMIN_AUTH_SUCCESS',''),(9,0,2,0,0,0,0,'178.4.43.135',1606581560,'LOG_CONFIG_SETTINGS',''),(10,0,2,0,0,0,0,'178.4.43.135',1606582159,'LOG_MODULE_ADD','a:1:{i:0;s:16:\"ACP_ABBC3_MODULE\";}'),(11,0,2,0,0,0,0,'178.4.43.135',1606582160,'LOG_MODULE_ADD','a:1:{i:0;s:18:\"ACP_ABBC3_SETTINGS\";}'),(12,0,2,0,0,0,0,'178.4.43.135',1606582161,'LOG_MODULE_ADD','a:1:{i:0;s:7:\"BBCodes\";}'),(13,0,2,0,0,0,0,'178.4.43.135',1606582161,'LOG_EXT_ENABLE','a:1:{i:0;s:9:\"vse/abbc3\";}'),(14,0,2,0,0,0,0,'178.4.43.135',1606583049,'LOG_ADMIN_AUTH_SUCCESS',''),(15,0,2,0,0,0,0,'178.4.43.135',1606583125,'LOG_CONFIG_LOAD',''),(16,0,2,0,0,0,0,'178.4.43.135',1606583902,'LOG_ADMIN_AUTH_SUCCESS',''),(17,0,2,0,0,0,0,'178.4.43.135',1606583918,'LOG_STYLE_ADD','a:1:{i:0;s:11:\"ultra_light\";}'),(18,0,2,0,0,0,0,'178.4.43.135',1606583955,'LOG_CONFIG_SETTINGS',''),(19,0,2,0,0,0,0,'178.4.43.135',1606586031,'LOG_EXT_ENABLE','a:1:{i:0;s:16:\"phpbbes/catbgimg\";}'),(20,0,2,0,0,0,0,'178.4.43.135',1606586172,'LOG_CONFIG_SETTINGS',''),(21,0,2,0,0,0,0,'178.4.43.135',1606586223,'LOG_CONFIG_SETTINGS',''),(22,0,49,0,0,0,0,'178.4.43.135',1606586431,'LOG_ADMIN_AUTH_FAIL',''),(23,0,49,0,0,0,0,'178.4.43.135',1606586437,'LOG_ADMIN_AUTH_SUCCESS',''),(24,0,2,0,0,0,0,'178.4.43.135',1606586609,'LOG_FORUM_ADD','a:1:{i:0;s:4:\"Test\";}'),(25,0,2,0,0,0,0,'178.4.43.135',1606586859,'LOG_FORUM_EDIT','a:1:{i:0;s:4:\"Test\";}'),(26,0,2,0,0,0,0,'178.4.43.135',1606586880,'LOG_EXT_ENABLE','a:1:{i:0;s:26:\"rmcgirr83/topicicononindex\";}'),(27,0,2,0,0,0,0,'178.4.43.135',1606586998,'LOG_FORUM_ADD','a:1:{i:0;s:8:\"2. Forum\";}'),(28,0,2,0,0,0,0,'178.4.43.135',1606586998,'LOG_FORUM_COPIED_PERMISSIONS','a:2:{i:0;s:4:\"Test\";i:1;s:8:\"2. Forum\";}'),(29,0,49,0,0,0,0,'178.4.43.135',1606587196,'LOG_ACL_ADD_FORUM_LOCAL_F_','a:2:{i:0;s:8:\"2. Forum\";i:1;s:41:\"<span class=\"sep\">Registered users</span>\";}'),(30,0,49,0,0,0,0,'178.4.43.135',1606587197,'LOG_ACL_ADD_FORUM_LOCAL_F_','a:2:{i:0;s:14:\"Test, 2. Forum\";i:1;s:115:\"<span class=\"sep\">Guests</span>, <span class=\"sep\">Registered users</span>, <span class=\"sep\">Administrators</span>\";}'),(31,0,49,0,0,0,0,'178.4.43.135',1606587398,'LOG_ACL_ADD_FORUM_LOCAL_F_','a:2:{i:0;s:14:\"Test, 2. Forum\";i:1;s:6:\"Admin1\";}'),(32,0,2,0,0,0,0,'178.4.43.135',1606587520,'LOG_EXT_ENABLE','a:1:{i:0;s:22:\"rmcgirr83/birthdaycake\";}'),(33,0,2,0,0,0,0,'178.4.43.135',1606587585,'LOG_EXT_ENABLE','a:1:{i:0;s:26:\"alfredoramos/simplespoiler\";}'),(34,0,2,0,0,0,0,'178.4.43.135',1606587689,'LOG_EXT_ENABLE','a:1:{i:0;s:10:\"vse/pmbars\";}'),(35,0,2,0,0,0,0,'178.4.43.135',1606587937,'LOG_MODULE_ADD','a:1:{i:0;s:15:\"ACP_FLAIR_TITLE\";}'),(36,0,2,0,0,0,0,'178.4.43.135',1606587937,'LOG_MODULE_ADD','a:1:{i:0;s:18:\"ACP_FLAIR_SETTINGS\";}'),(37,0,2,0,0,0,0,'178.4.43.135',1606587938,'LOG_MODULE_ADD','a:1:{i:0;s:16:\"ACP_FLAIR_MANAGE\";}'),(38,0,2,0,0,0,0,'178.4.43.135',1606587938,'LOG_MODULE_ADD','a:1:{i:0;s:22:\"ACP_FLAIR_MANAGE_USERS\";}'),(39,0,2,0,0,0,0,'178.4.43.135',1606587940,'LOG_MODULE_ADD','a:1:{i:0;s:16:\"ACP_FLAIR_IMAGES\";}'),(40,0,2,0,0,0,0,'178.4.43.135',1606587947,'LOG_MODULE_ADD','a:1:{i:0;s:9:\"MCP_FLAIR\";}'),(41,0,2,0,0,0,0,'178.4.43.135',1606587948,'LOG_MODULE_ADD','a:1:{i:0;s:15:\"MCP_FLAIR_FRONT\";}'),(42,0,2,0,0,0,0,'178.4.43.135',1606587949,'LOG_MODULE_ADD','a:1:{i:0;s:14:\"MCP_FLAIR_USER\";}'),(43,0,2,0,0,0,0,'178.4.43.135',1606587949,'LOG_MODULE_ADD','a:1:{i:0;s:9:\"UCP_FLAIR\";}'),(44,0,2,0,0,0,0,'178.4.43.135',1606587950,'LOG_MODULE_ADD','a:1:{i:0;s:15:\"MCP_FLAIR_FRONT\";}'),(45,0,2,0,0,0,0,'178.4.43.135',1606587950,'LOG_MODULE_ADD','a:1:{i:0;s:14:\"MCP_FLAIR_USER\";}'),(46,0,2,0,0,0,0,'178.4.43.135',1606587950,'LOG_EXT_ENABLE','a:1:{i:0;s:14:\"stevotvr/flair\";}'),(47,0,2,0,0,0,0,'178.4.43.135',1606591078,'LOG_EXT_ENABLE','a:1:{i:0;s:24:\"rxu/firstpostoneverypage\";}'),(48,0,2,0,0,0,0,'178.4.43.135',1606591162,'LOG_EXT_ENABLE','a:1:{i:0;s:26:\"rxu/listsubforumsincolumns\";}'),(49,0,2,0,0,0,0,'178.4.43.135',1606591504,'LOG_EXT_ENABLE','a:1:{i:0;s:15:\"hifikabin/clock\";}'),(50,0,2,0,0,0,0,'178.4.43.135',1606591616,'LOG_MODULE_ADD','a:1:{i:0;s:13:\"ACP_MAS_TITLE\";}'),(51,0,2,0,0,0,0,'178.4.43.135',1606591617,'LOG_MODULE_ADD','a:1:{i:0;s:17:\"ACP_MAS_MODE_MAIN\";}'),(52,0,2,0,0,0,0,'178.4.43.135',1606591618,'LOG_MODULE_ADD','a:1:{i:0;s:23:\"ACP_MAS_MODE_MEMBERLIST\";}'),(53,0,2,0,0,0,0,'178.4.43.135',1606591620,'LOG_MODULE_ADD','a:1:{i:0;s:23:\"ACP_MAS_MODE_VIEWONLINE\";}'),(54,0,2,0,0,0,0,'178.4.43.135',1606591623,'LOG_MODULE_ADD','a:1:{i:0;s:22:\"ACP_MAS_MODE_VIEWFORUM\";}'),(55,0,2,0,0,0,0,'178.4.43.135',1606591626,'LOG_MODULE_ADD','a:1:{i:0;s:19:\"ACP_MAS_MODE_SEARCH\";}'),(56,0,2,0,0,0,0,'178.4.43.135',1606591627,'LOG_MODULE_ADD','a:1:{i:0;s:19:\"ACP_MAS_MODE_REVIEW\";}'),(57,0,2,0,0,0,0,'178.4.43.135',1606591630,'LOG_MODULE_ADD','a:1:{i:0;s:20:\"ACP_MAS_MODE_GENERAL\";}'),(58,0,2,0,0,0,0,'178.4.43.135',1606591630,'LOG_MODULE_ADD','a:1:{i:0;s:23:\"ACP_MAS_MODE_MEMBERLIST\";}'),(59,0,2,0,0,0,0,'178.4.43.135',1606591631,'LOG_MODULE_ADD','a:1:{i:0;s:23:\"ACP_MAS_MODE_VIEWONLINE\";}'),(60,0,2,0,0,0,0,'178.4.43.135',1606591632,'LOG_MODULE_ADD','a:1:{i:0;s:22:\"ACP_MAS_MODE_VIEWFORUM\";}'),(61,0,2,0,0,0,0,'178.4.43.135',1606591633,'LOG_MODULE_ADD','a:1:{i:0;s:19:\"ACP_MAS_MODE_SEARCH\";}'),(62,0,2,0,0,0,0,'178.4.43.135',1606591633,'LOG_MODULE_ADD','a:1:{i:0;s:19:\"ACP_MAS_MODE_REVIEW\";}'),(63,0,2,0,0,0,0,'178.4.43.135',1606591634,'LOG_EXT_ENABLE','a:1:{i:0;s:24:\"dark1/memberavatarstatus\";}'),(64,0,2,0,0,0,0,'178.4.43.135',1606591715,'LOG_EXT_ENABLE','a:1:{i:0;s:25:\"hifikabin/quotethumbnails\";}'),(65,0,2,0,0,0,0,'178.4.43.135',1606591902,'LOG_MODULE_ADD','a:1:{i:0;s:13:\"TOPIC_PREVIEW\";}'),(66,0,2,0,0,0,0,'178.4.43.135',1606591902,'LOG_MODULE_ADD','a:1:{i:0;s:22:\"TOPIC_PREVIEW_SETTINGS\";}'),(67,0,2,0,0,0,0,'178.4.43.135',1606591906,'LOG_MODULE_ADD','a:1:{i:0;s:22:\"TOPIC_PREVIEW_SETTINGS\";}'),(68,0,2,0,0,0,0,'178.4.43.135',1606591908,'LOG_EXT_ENABLE','a:1:{i:0;s:16:\"vse/topicpreview\";}'),(69,0,2,0,0,0,0,'178.4.43.135',1606592175,'LOG_EXT_ENABLE','a:1:{i:0;s:17:\"rmcgirr83/genders\";}'),(70,0,2,0,0,0,0,'178.4.43.135',1606592927,'LOG_MODULE_ADD','a:1:{i:0;s:17:\"ACP_AKISMET_TITLE\";}'),(71,0,2,0,0,0,0,'178.4.43.135',1606592928,'LOG_MODULE_ADD','a:1:{i:0;s:20:\"ACP_AKISMET_SETTINGS\";}'),(72,0,2,0,0,0,0,'178.4.43.135',1606592930,'LOG_EXT_ENABLE','a:1:{i:0;s:13:\"senky/akismet\";}'),(73,0,2,0,0,0,0,'178.4.43.135',1606592943,'LOG_EXT_ENABLE','a:1:{i:0;s:20:\"sylver35/ajaxpreview\";}'),(74,0,2,0,0,0,0,'178.4.43.135',1606592957,'LOG_MODULE_ADD','a:1:{i:0;s:17:\"DELETE_MY_ACCOUNT\";}'),(75,0,2,0,0,0,0,'178.4.43.135',1606592958,'LOG_MODULE_ADD','a:1:{i:0;s:19:\"DELETE_YOUR_ACCOUNT\";}'),(76,0,2,0,0,0,0,'178.4.43.135',1606592958,'LOG_EXT_ENABLE','a:1:{i:0;s:27:\"brokencrust/deletemyaccount\";}'),(77,0,2,0,0,0,0,'178.4.43.135',1606592975,'LOG_EXT_ENABLE','a:1:{i:0;s:19:\"hifikabin/largefont\";}'),(78,0,2,0,0,0,0,'178.4.43.135',1606593031,'LOG_MODULE_ADD','a:1:{i:0;s:13:\"ACP_CAT_MCHAT\";}'),(79,0,2,0,0,0,0,'178.4.43.135',1606593032,'LOG_MODULE_ADD','a:1:{i:0;s:24:\"ACP_MCHAT_GLOBALSETTINGS\";}'),(80,0,2,0,0,0,0,'178.4.43.135',1606593032,'LOG_MODULE_ADD','a:1:{i:0;s:28:\"ACP_MCHAT_GLOBALUSERSETTINGS\";}'),(81,0,2,0,0,0,0,'178.4.43.135',1606593033,'LOG_MODULE_ADD','a:1:{i:0;s:16:\"UCP_MCHAT_CONFIG\";}'),(82,0,2,0,0,0,0,'178.4.43.135',1606593033,'LOG_MODULE_ADD','a:1:{i:0;s:16:\"UCP_MCHAT_CONFIG\";}'),(83,0,2,0,0,0,0,'178.4.43.135',1606593092,'LOG_EXT_ENABLE','a:1:{i:0;s:10:\"dmzx/mchat\";}'),(84,0,2,0,0,0,0,'178.4.43.135',1606593111,'LOG_EXT_ENABLE','a:1:{i:0;s:11:\"phpbbes/age\";}'),(85,0,2,0,0,0,0,'178.4.43.135',1606593127,'LOG_MODULE_ADD','a:1:{i:0;s:13:\"ACP_PMWELCOME\";}'),(86,0,2,0,0,0,0,'178.4.43.135',1606593130,'LOG_EXT_ENABLE','a:1:{i:0;s:14:\"apwa/pmwelcome\";}'),(87,0,2,0,0,0,0,'178.4.43.135',1606593143,'LOG_EXT_ENABLE','a:1:{i:0;s:18:\"alex75/welcomeback\";}'),(88,0,2,0,0,0,0,'178.4.43.135',1606593470,'ACP_MAS_LOG_SET_SAV','a:1:{i:0;s:20:\"MAS General Settings\";}'),(89,0,2,0,0,0,0,'178.4.43.135',1606593483,'ACP_MAS_LOG_SET_SAV','a:1:{i:0;s:23:\"MAS Memberlist Settings\";}'),(90,0,2,0,0,0,0,'178.4.43.135',1606593497,'ACP_MAS_LOG_SET_SAV','a:1:{i:0;s:23:\"MAS Viewonline Settings\";}'),(91,0,2,0,0,0,0,'178.4.43.135',1606593511,'ACP_MAS_LOG_SET_SAV','a:1:{i:0;s:22:\"MAS Viewforum Settings\";}'),(92,0,2,0,0,0,0,'178.4.43.135',1606593527,'ACP_MAS_LOG_SET_SAV','a:1:{i:0;s:19:\"MAS Search Settings\";}'),(93,0,2,0,0,0,0,'178.4.43.135',1606593535,'ACP_MAS_LOG_SET_SAV','a:1:{i:0;s:19:\"MAS Review Settings\";}'),(94,0,2,0,0,0,0,'178.4.43.135',1606593854,'AKISMET_LOG_SETTING_CHANGED',''),(95,0,2,0,0,0,0,'178.4.43.135',1606593969,'LOG_MCHAT_CONFIG_UPDATE','a:1:{i:0;s:9:\"Zenturion\";}'),(96,0,2,0,0,0,0,'178.4.43.135',1606593989,'LOG_MCHAT_CONFIG_UPDATE','a:1:{i:0;s:9:\"Zenturion\";}'),(97,0,2,0,0,0,0,'178.4.43.135',1606595053,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(98,0,2,0,0,0,0,'178.4.43.135',1606595131,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(99,0,2,0,0,0,0,'178.4.43.135',1606595140,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(100,0,2,0,0,0,0,'178.4.43.135',1606595152,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(101,0,2,0,0,0,0,'178.4.43.135',1606595187,'LOG_MCHAT_CONFIG_UPDATE','a:1:{i:0;s:9:\"Zenturion\";}'),(102,0,2,0,0,0,0,'178.4.43.135',1606597189,'LOG_CONFIG_AVATAR',''),(103,0,2,0,0,0,0,'178.4.43.135',1606599731,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(104,0,2,0,0,0,0,'178.4.43.135',1606599735,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(105,0,2,0,0,0,0,'178.4.43.135',1606599891,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(106,0,2,0,0,0,0,'178.4.43.135',1606599938,'LOG_ADMIN_AUTH_SUCCESS',''),(107,0,2,0,0,0,0,'178.4.43.135',1606600130,'LOG_MODULE_ADD','a:1:{i:0;s:21:\"UCP_SITEMAKER_CONTENT\";}'),(108,0,2,0,0,0,0,'178.4.43.135',1606600131,'LOG_MODULE_ADD','a:1:{i:0;s:21:\"MCP_SITEMAKER_CONTENT\";}'),(109,0,2,0,0,0,0,'178.4.43.135',1606600133,'LOG_MODULE_ADD','a:1:{i:0;s:13:\"ACP_SITEMAKER\";}'),(110,0,2,0,0,0,0,'178.4.43.135',1606600134,'LOG_MODULE_ADD','a:1:{i:0;s:8:\"ACP_MENU\";}'),(111,0,2,0,0,0,0,'178.4.43.135',1606600146,'LOG_MODULE_ADD','a:1:{i:0;s:15:\"ACP_SM_SETTINGS\";}'),(112,0,2,0,0,0,0,'178.4.43.135',1606600149,'LOG_EXT_ENABLE','a:1:{i:0;s:16:\"blitze/sitemaker\";}'),(113,0,2,0,0,0,0,'178.4.43.135',1606601112,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(114,0,2,0,0,0,0,'178.4.43.135',1606601402,'LOG_ADMIN_AUTH_SUCCESS',''),(115,0,2,0,0,0,0,'178.4.43.135',1606601508,'LOG_CONFIG_SETTINGS',''),(116,0,2,0,0,0,0,'178.4.43.135',1606601531,'LOG_STYLE_DELETE','a:1:{i:0;s:11:\"ultra_light\";}'),(117,0,2,0,0,0,0,'178.4.43.135',1606601576,'LOG_STYLE_ADD','a:1:{i:0;s:11:\"ultra_light\";}'),(118,0,2,0,0,0,0,'178.4.43.135',1606601605,'LOG_CONFIG_SETTINGS',''),(119,0,2,0,0,0,0,'178.4.43.135',1606601897,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(120,0,2,0,0,0,0,'178.4.43.135',1606602198,'LOG_EXT_DISABLE','a:1:{i:0;s:16:\"blitze/sitemaker\";}'),(121,0,2,0,0,0,0,'178.4.43.135',1606602256,'LOG_EXT_PURGE','a:1:{i:0;s:16:\"blitze/sitemaker\";}'),(122,0,2,0,0,0,0,'178.4.43.135',1606602264,'LOG_EXT_PURGE','a:1:{i:0;s:16:\"blitze/sitemaker\";}'),(123,0,2,0,0,0,0,'178.4.43.135',1606602294,'LOG_MODULE_ADD','a:1:{i:0;s:21:\"UCP_SITEMAKER_CONTENT\";}'),(124,0,2,0,0,0,0,'178.4.43.135',1606602294,'LOG_MODULE_ADD','a:1:{i:0;s:21:\"MCP_SITEMAKER_CONTENT\";}'),(125,0,2,0,0,0,0,'178.4.43.135',1606602297,'LOG_MODULE_ADD','a:1:{i:0;s:13:\"ACP_SITEMAKER\";}'),(126,0,2,0,0,0,0,'178.4.43.135',1606602297,'LOG_MODULE_ADD','a:1:{i:0;s:8:\"ACP_MENU\";}'),(127,0,2,0,0,0,0,'178.4.43.135',1606602313,'LOG_MODULE_ADD','a:1:{i:0;s:15:\"ACP_SM_SETTINGS\";}'),(128,0,2,0,0,0,0,'178.4.43.135',1606602317,'LOG_EXT_ENABLE','a:1:{i:0;s:16:\"blitze/sitemaker\";}'),(129,0,2,0,0,0,0,'178.4.43.135',1606602325,'LOG_EXT_ENABLE','a:1:{i:0;s:16:\"blitze/sitemaker\";}'),(130,0,2,0,0,0,0,'178.4.43.135',1606602994,'LOG_EXT_DISABLE','a:1:{i:0;s:18:\"alex75/welcomeback\";}'),(131,0,2,0,0,0,0,'178.4.43.135',1606607455,'LOG_USER_USER_UPDATE','a:1:{i:0;s:6:\"Admin1\";}'),(132,0,2,0,0,0,0,'178.4.43.135',1606607529,'LOG_ACL_ADD_USER_GLOBAL_U_','a:1:{i:0;s:6:\"Admin1\";}'),(133,0,2,0,0,0,0,'178.4.43.135',1606608957,'LOG_MCHAT_TABLE_PURGED','a:1:{i:0;s:9:\"Zenturion\";}'),(134,0,2,0,0,0,0,'178.4.43.135',1606609020,'LOG_USER_INACTIVE','a:1:{i:0;s:6:\"Admin1\";}'),(135,3,2,0,0,0,49,'178.4.43.135',1606609020,'LOG_USER_INACTIVE_USER',''),(136,0,2,0,0,0,0,'178.4.43.135',1606609271,'LOG_EDITED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(137,0,2,0,0,0,0,'178.4.43.135',1606609335,'LOG_FORUM_EDIT','a:1:{i:0;s:4:\"Test\";}'),(138,0,2,0,0,0,0,'178.4.43.135',1606609359,'LOG_FORUM_EDIT','a:1:{i:0;s:8:\"2. Forum\";}'),(139,0,2,0,0,0,0,'178.4.43.135',1606609385,'LOG_FORUM_EDIT','a:1:{i:0;s:17:\"Dein erstes Forum\";}'),(141,0,2,0,0,0,0,'178.4.43.135',1606609965,'LOG_ADMIN_AUTH_SUCCESS',''),(142,0,2,0,0,0,0,'178.4.43.135',1606609997,'LOG_USER_DELETED','a:1:{i:0;s:10:\"TestNutzer\";}'),(143,0,2,0,0,0,0,'178.4.43.135',1606610022,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(144,0,2,0,0,0,0,'178.4.43.135',1606610053,'LOG_MCHAT_CONFIG_UPDATE','a:1:{i:0;s:9:\"Zenturion\";}'),(145,0,2,0,0,0,0,'178.4.43.135',1606610070,'LOG_PURGE_CACHE',''),(146,0,2,0,0,0,0,'178.4.43.135',1606610189,'LOG_CONFIG_REGISTRATION',''),(147,0,2,0,0,0,0,'178.4.43.135',1606610685,'LOG_PMWELCOME_CONFIG_UPDATE',''),(149,0,2,0,0,0,0,'178.4.43.135',1606610938,'LOG_ADMIN_AUTH_SUCCESS',''),(151,0,2,0,0,0,0,'178.4.43.135',1606611067,'LOG_MASS_EMAIL','a:1:{i:0;s:10:\"TestNutzer\";}'),(152,0,2,0,0,0,0,'178.4.43.135',1606611114,'LOG_CLEAR_CRITICAL',''),(153,0,2,0,0,0,0,'178.4.43.135',1606611266,'LOG_CONFIG_EMAIL',''),(155,0,2,0,0,0,0,'178.4.43.135',1606611323,'LOG_MASS_EMAIL','a:1:{i:0;s:15:\"Alle Mitglieder\";}'),(156,0,2,0,0,0,0,'178.4.43.135',1606611462,'LOG_CONFIG_EMAIL',''),(158,0,2,0,0,0,0,'178.4.43.135',1606611485,'LOG_MASS_EMAIL','a:1:{i:0;s:10:\"TestNutzer\";}'),(159,0,2,0,0,0,0,'178.4.43.135',1606611569,'LOG_CONFIG_EMAIL',''),(161,0,2,0,0,0,0,'178.4.43.135',1606611630,'LOG_CLEAR_CRITICAL',''),(163,0,2,0,0,0,0,'178.4.43.135',1606611653,'LOG_MASS_EMAIL','a:1:{i:0;s:10:\"Testnutzer\";}'),(164,0,2,0,0,0,0,'178.4.43.135',1606611836,'LOG_CONFIG_EMAIL',''),(165,0,2,0,0,0,0,'178.4.43.135',1606611855,'LOG_CLEAR_CRITICAL',''),(167,0,2,0,0,0,0,'178.4.43.135',1606611902,'LOG_MASS_EMAIL','a:1:{i:0;s:10:\"Testnutzer\";}'),(168,0,2,0,0,0,0,'178.4.43.135',1606611966,'LOG_CONFIG_EMAIL',''),(170,0,2,0,0,0,0,'178.4.43.135',1606612018,'LOG_MASS_EMAIL','a:1:{i:0;s:10:\"Testnutzer\";}'),(171,0,2,0,0,0,0,'178.4.43.135',1606612042,'LOG_CLEAR_CRITICAL',''),(172,0,2,0,0,0,0,'178.4.43.135',1606612103,'LOG_CONFIG_EMAIL',''),(173,2,2,0,0,0,0,'178.4.43.135',1606612144,'LOG_ERROR_EMAIL','a:1:{i:0;s:194:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Der Antwort-Code des Servers konnte nicht empfangen werden.<h1>Backtrace</h1><p>Connecting to igame-rpg.de:465</p><br />\";}'),(174,2,2,0,0,0,0,'178.4.43.135',1606612274,'LOG_ERROR_EMAIL','a:1:{i:0;s:194:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Der Antwort-Code des Servers konnte nicht empfangen werden.<h1>Backtrace</h1><p>Connecting to igame-rpg.de:465</p><br />\";}'),(175,0,2,0,0,0,0,'178.4.43.135',1606612342,'LOG_CONFIG_EMAIL',''),(176,0,2,0,0,0,0,'178.4.43.135',1606612368,'LOG_CONFIG_EMAIL',''),(177,2,2,0,0,0,0,'178.4.43.135',1606612464,'LOG_ERROR_EMAIL','a:1:{i:0;s:411:\"<strong>EMAIL/PHP/mail()</strong><br /><em>/forum/adm/index.php</em><br /><br />Errno 2: mail(): SMTP server response: 503 This mail server requires authentication when attempting to send to a non-local e-mail address. Please check your mail client settings or contact your administrator to verify that the domain or address is defined for this server. at [ROOT]/includes/functions_messenger.php line 1929<br />\";}'),(178,0,2,0,0,0,0,'178.4.43.135',1606612465,'LOG_MASS_EMAIL','a:1:{i:0;s:10:\"TestNutzer\";}'),(179,0,2,0,0,0,0,'178.4.43.135',1606612539,'LOG_CONFIG_EMAIL',''),(180,2,2,0,0,0,0,'178.4.43.135',1606612547,'LOG_ERROR_EMAIL','a:1:{i:0;s:403:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Verbindung zum SMTP-Server kann nicht hergestellt werden: 10049 : Die angeforderte Adresse ist in diesem Kontext ungÃ¼ltig.\r\n.<br /><br />Errno 2: stream_socket_client(): unable to connect to igame-rpg.de:0 (Die angeforderte Adresse ist in diesem Kontext ungültig.\r\n) at [ROOT]/includes/functions_messenger.php line 1187<br />\";}'),(181,0,2,0,0,0,0,'178.4.43.135',1606612597,'LOG_CONFIG_EMAIL',''),(182,2,2,0,0,0,0,'178.4.43.135',1606612606,'LOG_ERROR_EMAIL','a:1:{i:0;s:403:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Verbindung zum SMTP-Server kann nicht hergestellt werden: 10049 : Die angeforderte Adresse ist in diesem Kontext ungÃ¼ltig.\r\n.<br /><br />Errno 2: stream_socket_client(): unable to connect to igame-rpg.de:0 (Die angeforderte Adresse ist in diesem Kontext ungültig.\r\n) at [ROOT]/includes/functions_messenger.php line 1187<br />\";}'),(183,0,2,0,0,0,0,'178.4.43.135',1606612643,'LOG_CONFIG_EMAIL',''),(184,2,2,0,0,0,0,'178.4.43.135',1606612650,'LOG_ERROR_EMAIL','a:1:{i:0;s:403:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Verbindung zum SMTP-Server kann nicht hergestellt werden: 10049 : Die angeforderte Adresse ist in diesem Kontext ungÃ¼ltig.\r\n.<br /><br />Errno 2: stream_socket_client(): unable to connect to igame-rpg.de:0 (Die angeforderte Adresse ist in diesem Kontext ungültig.\r\n) at [ROOT]/includes/functions_messenger.php line 1187<br />\";}'),(185,0,2,0,0,0,0,'178.4.43.135',1606612677,'LOG_CONFIG_EMAIL',''),(186,2,2,0,0,0,0,'178.4.43.135',1606612683,'LOG_ERROR_EMAIL','a:1:{i:0;s:403:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Verbindung zum SMTP-Server kann nicht hergestellt werden: 10049 : Die angeforderte Adresse ist in diesem Kontext ungÃ¼ltig.\r\n.<br /><br />Errno 2: stream_socket_client(): unable to connect to igame-rpg.de:0 (Die angeforderte Adresse ist in diesem Kontext ungültig.\r\n) at [ROOT]/includes/functions_messenger.php line 1187<br />\";}'),(187,2,2,0,0,0,0,'178.4.43.135',1606612691,'LOG_ERROR_EMAIL','a:1:{i:0;s:403:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Verbindung zum SMTP-Server kann nicht hergestellt werden: 10049 : Die angeforderte Adresse ist in diesem Kontext ungÃ¼ltig.\r\n.<br /><br />Errno 2: stream_socket_client(): unable to connect to igame-rpg.de:0 (Die angeforderte Adresse ist in diesem Kontext ungültig.\r\n) at [ROOT]/includes/functions_messenger.php line 1187<br />\";}'),(188,0,2,0,0,0,0,'178.4.43.135',1606612727,'LOG_CONFIG_EMAIL',''),(189,2,2,0,0,0,0,'178.4.43.135',1606612734,'LOG_ERROR_EMAIL','a:1:{i:0;s:403:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Verbindung zum SMTP-Server kann nicht hergestellt werden: 10049 : Die angeforderte Adresse ist in diesem Kontext ungÃ¼ltig.\r\n.<br /><br />Errno 2: stream_socket_client(): unable to connect to igame-rpg.de:0 (Die angeforderte Adresse ist in diesem Kontext ungültig.\r\n) at [ROOT]/includes/functions_messenger.php line 1187<br />\";}'),(190,0,2,0,0,0,0,'178.4.43.135',1606612766,'LOG_CONFIG_EMAIL',''),(191,2,2,0,0,0,0,'178.4.43.135',1606612776,'LOG_ERROR_EMAIL','a:1:{i:0;s:403:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Verbindung zum SMTP-Server kann nicht hergestellt werden: 10049 : Die angeforderte Adresse ist in diesem Kontext ungÃ¼ltig.\r\n.<br /><br />Errno 2: stream_socket_client(): unable to connect to igame-rpg.de:0 (Die angeforderte Adresse ist in diesem Kontext ungültig.\r\n) at [ROOT]/includes/functions_messenger.php line 1187<br />\";}'),(192,0,2,0,0,0,0,'178.4.43.135',1606613028,'LOG_CONFIG_EMAIL',''),(193,2,2,0,0,0,0,'178.4.43.135',1606613065,'LOG_ERROR_EMAIL','a:1:{i:0;s:194:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Der Antwort-Code des Servers konnte nicht empfangen werden.<h1>Backtrace</h1><p>Connecting to igame-rpg.de:465</p><br />\";}'),(194,0,2,0,0,0,0,'178.4.43.135',1606613109,'LOG_CONFIG_EMAIL',''),(195,2,2,0,0,0,0,'178.4.43.135',1606613147,'LOG_ERROR_EMAIL','a:1:{i:0;s:194:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Der Antwort-Code des Servers konnte nicht empfangen werden.<h1>Backtrace</h1><p>Connecting to igame-rpg.de:465</p><br />\";}'),(196,0,2,0,0,0,0,'178.4.43.135',1606613603,'LOG_CONFIG_EMAIL',''),(197,2,2,0,0,0,0,'178.4.43.135',1606613612,'LOG_ERROR_EMAIL','a:1:{i:0;s:711:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Der Antwort-Code des Servers konnte nicht empfangen werden.<h1>Backtrace</h1><p>Connecting to localhost:25<br />LINE: 1204 &lt;- 220 VE1577.home ESMTP MailEnable Service, Version: 10.27-- ready at 11/29/20 02:33:32\r\n<br /># EHLO ve1577.venus.fastwebserver.de<br />LINE: 1551 &lt;- 250-home [::1], this server offers 5 extensions\r\n<br />LINE: 1551 &lt;- 250-AUTH LOGIN\r\n<br />LINE: 1551 &lt;- 250-SIZE 40960000\r\n<br />LINE: 1551 &lt;- 250-HELP\r\n<br />LINE: 1551 &lt;- 250-AUTH=LOGIN\r\n<br />LINE: 1551 &lt;- 250 STARTTLS\r\n<br /># STARTTLS<br />LINE: 1604 &lt;- 220 Ready to start TLS\r\n<br /># MAIL FROM:&lt;admin@igame-rpg.de&gt;</p><br />\";}'),(198,0,2,0,0,0,0,'178.4.43.135',1606613643,'LOG_CONFIG_EMAIL',''),(199,2,2,0,0,0,0,'178.4.43.135',1606613651,'LOG_ERROR_EMAIL','a:1:{i:0;s:711:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Der Antwort-Code des Servers konnte nicht empfangen werden.<h1>Backtrace</h1><p>Connecting to localhost:25<br />LINE: 1204 &lt;- 220 VE1577.home ESMTP MailEnable Service, Version: 10.27-- ready at 11/29/20 02:34:11\r\n<br /># EHLO ve1577.venus.fastwebserver.de<br />LINE: 1551 &lt;- 250-home [::1], this server offers 5 extensions\r\n<br />LINE: 1551 &lt;- 250-AUTH LOGIN\r\n<br />LINE: 1551 &lt;- 250-SIZE 40960000\r\n<br />LINE: 1551 &lt;- 250-HELP\r\n<br />LINE: 1551 &lt;- 250-AUTH=LOGIN\r\n<br />LINE: 1551 &lt;- 250 STARTTLS\r\n<br /># STARTTLS<br />LINE: 1604 &lt;- 220 Ready to start TLS\r\n<br /># MAIL FROM:&lt;admin@igame-rpg.de&gt;</p><br />\";}'),(200,0,2,0,0,0,0,'178.4.43.135',1606613701,'LOG_CONFIG_EMAIL',''),(201,2,2,0,0,0,0,'178.4.43.135',1606613710,'LOG_ERROR_EMAIL','a:1:{i:0;s:685:\"<strong>EMAIL/SMTP</strong><br /><em>/forum/adm/index.php</em><br /><br />Der Antwort-Code des Servers konnte nicht empfangen werden.<h1>Backtrace</h1><p>Connecting to localhost:25<br />LINE: 1204 &lt;- 220 VE1577.home ESMTP MailEnable Service, Version: 10.27-- ready at 11/29/20 02:35:10\r\n<br /># EHLO ve1577.venus.fastwebserver.de<br />LINE: 1551 &lt;- 250-home [::1], this server offers 5 extensions\r\n<br />LINE: 1551 &lt;- 250-AUTH LOGIN\r\n<br />LINE: 1551 &lt;- 250-SIZE 40960000\r\n<br />LINE: 1551 &lt;- 250-HELP\r\n<br />LINE: 1551 &lt;- 250-AUTH=LOGIN\r\n<br />LINE: 1551 &lt;- 250 STARTTLS\r\n<br /># STARTTLS<br />LINE: 1604 &lt;- 220 Ready to start TLS\r\n<br /># AUTH LOGIN</p><br />\";}'),(202,0,2,0,0,0,0,'178.4.43.135',1606613758,'LOG_CONFIG_EMAIL',''),(203,0,2,0,0,0,0,'178.4.43.135',1606613836,'LOG_MASS_EMAIL','a:1:{i:0;s:10:\"TestNutzer\";}'),(204,0,2,0,0,0,0,'178.4.43.135',1606614040,'LOG_ADMIN_AUTH_SUCCESS',''),(205,0,2,0,0,0,0,'178.4.43.135',1606614068,'LOG_INACTIVE_REMIND','a:1:{i:0;s:10:\"TestNutzer\";}'),(206,3,2,0,0,0,51,'178.4.43.135',1606614109,'LOG_USER_ACTIVE_USER',''),(207,0,2,0,0,0,0,'178.4.43.135',1606614109,'LOG_USER_ACTIVE','a:1:{i:0;s:10:\"TestNutzer\";}'),(208,0,1,0,0,0,0,'95.216.96.244',1606699745,'LOG_MCHAT_TABLE_PRUNED','a:2:{i:0;s:9:\"Anonymous\";i:1;i:2;}'),(209,0,2,0,0,0,0,'84.62.110.68',1606854990,'LOG_ADMIN_AUTH_SUCCESS',''),(210,0,2,0,0,0,0,'84.62.110.68',1606855326,'LOG_ADMIN_AUTH_SUCCESS',''),(211,0,2,0,0,0,0,'188.97.219.60',1607729047,'LOG_ADMIN_AUTH_SUCCESS',''),(212,0,2,0,0,0,0,'188.97.219.60',1607729101,'LOG_FORUM_DEL_FORUMS','a:1:{i:0;s:4:\"Test\";}'),(213,0,2,0,0,0,0,'188.97.219.60',1607729110,'LOG_FORUM_DEL_FORUMS','a:1:{i:0;s:21:\"Deine erste Kategorie\";}'),(214,0,2,0,0,0,0,'188.97.219.60',1607729397,'LOG_FORUM_ADD','a:1:{i:0;s:9:\"Allgemein\";}'),(215,0,2,0,0,0,0,'188.97.219.60',1607729590,'LOG_FORUM_ADD','a:1:{i:0;s:11:\"Forumregeln\";}'),(216,0,2,0,0,0,0,'188.97.219.60',1607729689,'LOG_ACL_ADD_FORUM_LOCAL_F_','a:2:{i:0;s:9:\"Allgemein\";i:1;s:40:\"<span class=\"sep\">Administratoren</span>\";}'),(217,0,2,0,0,0,0,'188.97.219.60',1607729747,'LOG_ACL_ADD_FORUM_LOCAL_F_','a:2:{i:0;s:9:\"Allgemein\";i:1;s:31:\"<span class=\"sep\">Gäste</span>\";}'),(218,0,2,0,0,0,0,'188.97.219.60',1607729766,'LOG_ACL_ADD_FORUM_LOCAL_F_','a:2:{i:0;s:9:\"Allgemein\";i:1;s:46:\"<span class=\"sep\">Registrierte Benutzer</span>\";}'),(219,0,2,0,0,0,0,'188.97.219.60',1607729793,'LOG_FORUM_COPIED_PERMISSIONS','a:2:{i:0;s:9:\"Allgemein\";i:1;s:11:\"Forumregeln\";}'),(220,0,2,0,0,0,0,'188.97.219.60',1607731218,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(221,0,2,0,0,0,0,'188.97.219.60',1607732116,'LOG_PMWELCOME_CONFIG_UPDATE',''),(222,0,2,0,0,0,0,'188.97.219.60',1607732283,'LOG_FORUM_ADD','a:1:{i:0;s:6:\"Lounge\";}'),(223,0,2,0,0,0,0,'188.97.219.60',1607732283,'LOG_FORUM_COPIED_PERMISSIONS','a:2:{i:0;s:9:\"Allgemein\";i:1;s:6:\"Lounge\";}'),(224,0,2,0,0,0,0,'188.97.219.60',1607732335,'LOG_ACL_ADD_GROUP_LOCAL_F_','a:2:{i:0;s:30:\"Allgemein, Forumregeln, Lounge\";i:1;s:40:\"<span class=\"sep\">Administratoren</span>\";}'),(225,0,2,0,0,0,0,'188.97.219.60',1607732351,'LOG_ACL_ADD_GROUP_LOCAL_F_','a:2:{i:0;s:30:\"Allgemein, Forumregeln, Lounge\";i:1;s:31:\"<span class=\"sep\">Gäste</span>\";}'),(226,0,2,0,0,0,0,'188.97.219.60',1607732429,'LOG_ACL_ADD_GROUP_LOCAL_F_','a:2:{i:0;s:30:\"Allgemein, Forumregeln, Lounge\";i:1;s:46:\"<span class=\"sep\">Registrierte Benutzer</span>\";}'),(227,0,2,0,0,0,0,'188.97.219.60',1607732609,'LOG_FORUM_ADD','a:1:{i:0;s:11:\"Plauderecke\";}'),(228,0,2,0,0,0,0,'188.97.219.60',1607732609,'LOG_FORUM_COPIED_PERMISSIONS','a:2:{i:0;s:9:\"Allgemein\";i:1;s:11:\"Plauderecke\";}'),(229,0,2,0,0,0,0,'188.97.219.60',1607732677,'LOG_ACL_ADD_FORUM_LOCAL_F_','a:2:{i:0;s:11:\"Plauderecke\";i:1;s:121:\"<span class=\"sep\">Gäste</span>, <span class=\"sep\">Registrierte Benutzer</span>, <span class=\"sep\">Administratoren</span>\";}'),(230,0,2,0,0,0,0,'188.97.219.60',1607736836,'LOG_FORUM_ADD','a:1:{i:0;s:15:\"IgameRPG Intern\";}'),(231,0,2,0,0,0,0,'188.97.219.60',1607736898,'LOG_ACL_ADD_FORUM_LOCAL_F_','a:2:{i:0;s:15:\"IgameRPG Intern\";i:1;s:121:\"<span class=\"sep\">Gäste</span>, <span class=\"sep\">Registrierte Benutzer</span>, <span class=\"sep\">Administratoren</span>\";}'),(232,0,2,0,0,0,0,'188.97.219.60',1607737162,'LOG_MODULE_ADD','a:1:{i:0;s:18:\"ACP_TOPIC_PREFIXES\";}'),(233,0,2,0,0,0,0,'188.97.219.60',1607737163,'LOG_MODULE_ADD','a:1:{i:0;s:19:\"ACP_MANAGE_PREFIXES\";}'),(234,0,2,0,0,0,0,'188.97.219.60',1607737163,'LOG_EXT_ENABLE','a:1:{i:0;s:19:\"phpbb/topicprefixes\";}'),(235,0,2,0,0,0,0,'188.97.219.60',1607737281,'LOG_FORUM_ADD','a:1:{i:0;s:5:\"Hilfe\";}'),(236,0,2,0,0,0,0,'188.97.219.60',1607737281,'LOG_FORUM_COPIED_PERMISSIONS','a:2:{i:0;s:15:\"IgameRPG Intern\";i:1;s:5:\"Hilfe\";}'),(237,0,2,0,0,0,0,'188.97.219.60',1607737345,'LOG_ACL_ADD_FORUM_LOCAL_F_','a:2:{i:0;s:5:\"Hilfe\";i:1;s:121:\"<span class=\"sep\">Gäste</span>, <span class=\"sep\">Registrierte Benutzer</span>, <span class=\"sep\">Administratoren</span>\";}'),(238,0,2,0,0,0,0,'188.97.219.60',1607737398,'ACP_LOG_PREFIX_ADDED','a:2:{i:0;s:18:\"[Allgemeine Frage]\";i:1;s:5:\"Hilfe\";}'),(239,0,2,0,0,0,0,'188.97.219.60',1607737431,'ACP_LOG_PREFIX_ADDED','a:2:{i:0;s:11:\"[Bot Frage]\";i:1;s:5:\"Hilfe\";}'),(240,0,2,0,0,0,0,'188.97.219.60',1607737449,'ACP_LOG_PREFIX_ADDED','a:2:{i:0;s:16:\"[ChanServ Frage]\";i:1;s:5:\"Hilfe\";}'),(241,0,2,0,0,0,0,'188.97.219.60',1607737465,'ACP_LOG_PREFIX_ADDED','a:2:{i:0;s:16:\"[NickServ Frage]\";i:1;s:5:\"Hilfe\";}'),(242,0,2,0,0,0,0,'188.97.219.60',1607737483,'ACP_LOG_PREFIX_ADDED','a:2:{i:0;s:16:\"[MemoServ Frage]\";i:1;s:5:\"Hilfe\";}'),(243,0,2,0,0,0,0,'188.97.219.60',1607737510,'ACP_LOG_PREFIX_ADDED','a:2:{i:0;s:15:\"[BotServ Frage]\";i:1;s:5:\"Hilfe\";}'),(244,0,2,0,0,0,0,'188.97.219.60',1607737534,'ACP_LOG_PREFIX_ADDED','a:2:{i:0;s:15:\"[WebChat Frage]\";i:1;s:5:\"Hilfe\";}'),(245,0,2,0,0,0,0,'188.97.219.60',1607737550,'ACP_LOG_PREFIX_ADDED','a:2:{i:0;s:14:\"[Client Frage]\";i:1;s:5:\"Hilfe\";}'),(246,0,2,0,0,0,0,'188.97.219.60',1607737677,'LOG_FORUM_EDIT','a:1:{i:0;s:15:\"IgameRPG Intern\";}'),(247,1,2,10,0,0,0,'188.97.219.60',1607737819,'LOG_TOPIC_DISAPPROVED','a:3:{i:0;s:27:\"[Allgemeine Frage] Hmm test\";i:1;s:51:\"Die gemeldete Nachricht betrifft ein anderes Thema.\";i:2;s:9:\"Zenturion\";}'),(248,0,2,0,0,0,0,'188.97.219.60',1607738982,'LOG_FORUM_ADD','a:1:{i:0;s:11:\"Bewerbungen\";}'),(249,0,2,0,0,0,0,'188.97.219.60',1607738982,'LOG_FORUM_COPIED_PERMISSIONS','a:2:{i:0;s:5:\"Hilfe\";i:1;s:11:\"Bewerbungen\";}'),(250,0,2,0,0,0,0,'188.97.219.60',1607740443,'LOG_EXT_ENABLE','a:1:{i:0;s:19:\"senky/simplewysiwyg\";}'),(251,0,2,0,0,0,0,'188.97.219.60',1607740493,'LOG_EXT_DISABLE','a:1:{i:0;s:9:\"vse/abbc3\";}'),(252,0,2,0,0,0,0,'188.97.219.60',1607740620,'LOG_EXT_ENABLE','a:1:{i:0;s:9:\"vse/abbc3\";}'),(253,0,2,0,0,0,0,'188.97.219.60',1607740717,'LOG_EXT_DISABLE','a:1:{i:0;s:9:\"vse/abbc3\";}'),(254,0,2,0,0,0,0,'188.97.219.60',1607740890,'LOG_EXT_ENABLE','a:1:{i:0;s:9:\"vse/abbc3\";}'),(255,0,2,0,0,0,0,'188.97.219.60',1607740914,'LOG_EXT_DISABLE','a:1:{i:0;s:19:\"senky/simplewysiwyg\";}'),(256,0,2,0,0,0,0,'188.97.219.60',1607741068,'LOG_EXT_DISABLE','a:1:{i:0;s:20:\"sylver35/ajaxpreview\";}'),(257,0,2,0,0,0,0,'188.97.219.60',1607741085,'LOG_EXT_ENABLE','a:1:{i:0;s:19:\"senky/simplewysiwyg\";}'),(258,0,2,0,0,0,0,'188.97.219.60',1607741473,'LOG_EXT_DISABLE','a:1:{i:0;s:9:\"vse/abbc3\";}'),(259,1,2,11,5,5,0,'188.97.219.60',1607742691,'LOG_POST_APPROVED','a:1:{i:0;s:18:\"Bewewrbungsvorlage\";}'),(260,0,2,0,0,0,0,'188.97.219.60',1607742716,'LOG_DELETED_MCHAT','a:1:{i:0;s:9:\"Zenturion\";}'),(261,0,2,0,0,0,0,'188.97.219.60',1607742831,'ACP_LOG_PREFIX_ADDED','a:2:{i:0;s:15:\"[Bewerbung von]\";i:1;s:11:\"Bewerbungen\";}');
/*!40000 ALTER TABLE `phpbb_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_login_attempts`
--

DROP TABLE IF EXISTS `phpbb_login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_login_attempts` (
  `attempt_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `attempt_browser` varchar(150) COLLATE utf8_bin NOT NULL DEFAULT '',
  `attempt_forwarded_for` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `attempt_time` int(11) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `username` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `username_clean` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '0',
  KEY `att_ip` (`attempt_ip`,`attempt_time`),
  KEY `att_for` (`attempt_forwarded_for`,`attempt_time`),
  KEY `att_time` (`attempt_time`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_login_attempts`
--

LOCK TABLES `phpbb_login_attempts` WRITE;
/*!40000 ALTER TABLE `phpbb_login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_mchat`
--

DROP TABLE IF EXISTS `phpbb_mchat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_mchat` (
  `message_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `message` mediumtext COLLATE utf8_bin NOT NULL,
  `bbcode_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bbcode_uid` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bbcode_options` tinyint(1) unsigned NOT NULL DEFAULT 7,
  `message_time` int(11) NOT NULL DEFAULT 0,
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `post_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_mchat`
--

LOCK TABLES `phpbb_mchat` WRITE;
/*!40000 ALTER TABLE `phpbb_mchat` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_mchat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_mchat_log`
--

DROP TABLE IF EXISTS `phpbb_mchat_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_mchat_log` (
  `log_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` tinyint(4) NOT NULL DEFAULT 0,
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `message_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `log_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `log_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_mchat_log`
--

LOCK TABLES `phpbb_mchat_log` WRITE;
/*!40000 ALTER TABLE `phpbb_mchat_log` DISABLE KEYS */;
INSERT INTO `phpbb_mchat_log` VALUES (11,2,2,15,'178.4.43.135',1606610022),(12,2,2,17,'188.97.219.60',1607731218),(13,2,2,19,'188.97.219.60',1607742716);
/*!40000 ALTER TABLE `phpbb_mchat_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_mchat_sessions`
--

DROP TABLE IF EXISTS `phpbb_mchat_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_mchat_sessions` (
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_lastupdate` int(11) unsigned NOT NULL DEFAULT 0,
  `user_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_mchat_sessions`
--

LOCK TABLES `phpbb_mchat_sessions` WRITE;
/*!40000 ALTER TABLE `phpbb_mchat_sessions` DISABLE KEYS */;
INSERT INTO `phpbb_mchat_sessions` VALUES (2,1607742716,'188.97.219.60');
/*!40000 ALTER TABLE `phpbb_mchat_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_migrations`
--

DROP TABLE IF EXISTS `phpbb_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_migrations` (
  `migration_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `migration_depends_on` text COLLATE utf8_bin NOT NULL,
  `migration_schema_done` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `migration_data_done` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `migration_data_state` text COLLATE utf8_bin NOT NULL,
  `migration_start_time` int(11) unsigned NOT NULL DEFAULT 0,
  `migration_end_time` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`migration_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_migrations`
--

LOCK TABLES `phpbb_migrations` WRITE;
/*!40000 ALTER TABLE `phpbb_migrations` DISABLE KEYS */;
INSERT INTO `phpbb_migrations` VALUES ('\\alfredoramos\\simplespoiler\\migrations\\v10x\\m1_spoiler_data','a:0:{}',1,1,'',1606587584,1606587584),('\\alfredoramos\\simplespoiler\\migrations\\v13x\\m1_spoiler_data','a:1:{i:0;s:59:\"\\alfredoramos\\simplespoiler\\migrations\\v10x\\m1_spoiler_data\";}',1,1,'',1606587584,1606587585),('\\alfredoramos\\simplespoiler\\migrations\\v20x\\m1_spoiler_data','a:1:{i:0;s:59:\"\\alfredoramos\\simplespoiler\\migrations\\v13x\\m1_spoiler_data\";}',1,1,'',1606587585,1606587585),('\\apwa\\pmwelcome\\migrations\\v_1_0_0','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v313\";}',1,1,'',1606593125,1606593127),('\\apwa\\pmwelcome\\migrations\\v_1_0_1','a:1:{i:0;s:34:\"\\apwa\\pmwelcome\\migrations\\v_1_0_0\";}',1,1,'',1606593127,1606593128),('\\apwa\\pmwelcome\\migrations\\v_1_2_0','a:1:{i:0;s:41:\"\\apwa\\pmwelcome\\migrations\\v_1_2_0_schema\";}',1,1,'',1606593129,1606593130),('\\apwa\\pmwelcome\\migrations\\v_1_2_0_schema','a:1:{i:0;s:34:\"\\apwa\\pmwelcome\\migrations\\v_1_0_1\";}',1,1,'',1606593128,1606593128),('\\blitze\\sitemaker\\migrations\\converter\\c1_remove_modules','a:0:{}',1,1,'',1606602280,1606602280),('\\blitze\\sitemaker\\migrations\\converter\\c2_update_data','a:0:{}',1,1,'',1606602280,1606602283),('\\blitze\\sitemaker\\migrations\\converter\\c3_update_tables','a:0:{}',1,1,'',0,0),('\\blitze\\sitemaker\\migrations\\converter\\c4_convert_primetime_data','a:2:{i:0;s:51:\"\\blitze\\sitemaker\\migrations\\v20x\\m1_initial_schema\";i:1;s:49:\"\\blitze\\sitemaker\\migrations\\v20x\\m2_initial_data\";}',1,1,'',0,0),('\\blitze\\sitemaker\\migrations\\v20x\\m10_remove_dashboard','a:1:{i:0;s:51:\"\\blitze\\sitemaker\\migrations\\v20x\\m4_initial_module\";}',1,1,'',1606602295,1606602297),('\\blitze\\sitemaker\\migrations\\v20x\\m11_remove_item_status_column','a:1:{i:0;s:61:\"\\blitze\\sitemaker\\migrations\\v20x\\m9_update_menu_items_fields\";}',1,1,'',1606602299,1606602299),('\\blitze\\sitemaker\\migrations\\v20x\\m12_add_hidden_forum_column','a:1:{i:0;s:51:\"\\blitze\\sitemaker\\migrations\\v20x\\m1_initial_schema\";}',1,1,'',1606602300,1606602300),('\\blitze\\sitemaker\\migrations\\v20x\\m13_add_menu_permission','a:1:{i:0;s:54:\"\\blitze\\sitemaker\\migrations\\v20x\\m10_remove_dashboard\";}',1,1,'',1606602300,1606602302),('\\blitze\\sitemaker\\migrations\\v20x\\m14_update_settings_data','a:1:{i:0;s:57:\"\\blitze\\sitemaker\\migrations\\v20x\\m7_update_settings_data\";}',1,1,'',1606602303,1606602304),('\\blitze\\sitemaker\\migrations\\v20x\\m1_initial_schema','a:3:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v312\";i:1;s:55:\"\\blitze\\sitemaker\\migrations\\converter\\c3_update_tables\";i:2;s:55:\"\\blitze\\sitemaker\\migrations\\v20x\\m3_initial_permission\";}',1,1,'',1606602285,1606602290),('\\blitze\\sitemaker\\migrations\\v20x\\m2_initial_data','a:2:{i:0;s:53:\"\\blitze\\sitemaker\\migrations\\converter\\c2_update_data\";i:1;s:51:\"\\blitze\\sitemaker\\migrations\\v20x\\m1_initial_schema\";}',1,1,'',1606602290,1606602293),('\\blitze\\sitemaker\\migrations\\v20x\\m3_initial_permission','a:0:{}',1,1,'',1606602283,1606602285),('\\blitze\\sitemaker\\migrations\\v20x\\m4_initial_module','a:2:{i:0;s:56:\"\\blitze\\sitemaker\\migrations\\converter\\c1_remove_modules\";i:1;s:55:\"\\blitze\\sitemaker\\migrations\\v20x\\m3_initial_permission\";}',1,1,'',1606602293,1606602294),('\\blitze\\sitemaker\\migrations\\v20x\\m5_add_cblocks_schema','a:1:{i:0;s:51:\"\\blitze\\sitemaker\\migrations\\v20x\\m1_initial_schema\";}',1,1,'',1606602304,1606602307),('\\blitze\\sitemaker\\migrations\\v20x\\m6_add_block_settings_field','a:1:{i:0;s:64:\"\\blitze\\sitemaker\\migrations\\converter\\c4_convert_primetime_data\";}',1,1,'',1606602302,1606602303),('\\blitze\\sitemaker\\migrations\\v20x\\m7_update_settings_data','a:2:{i:0;s:51:\"\\blitze\\sitemaker\\migrations\\v20x\\m1_initial_schema\";i:1;s:61:\"\\blitze\\sitemaker\\migrations\\v20x\\m6_add_block_settings_field\";}',1,1,'',1606602303,1606602303),('\\blitze\\sitemaker\\migrations\\v20x\\m8_remove_config_table','a:2:{i:0;s:51:\"\\blitze\\sitemaker\\migrations\\v20x\\m1_initial_schema\";i:1;s:57:\"\\blitze\\sitemaker\\migrations\\v20x\\m7_update_settings_data\";}',1,1,'',1606602307,1606602308),('\\blitze\\sitemaker\\migrations\\v20x\\m9_update_menu_items_fields','a:1:{i:0;s:64:\"\\blitze\\sitemaker\\migrations\\converter\\c4_convert_primetime_data\";}',1,1,'',1606602298,1606602299),('\\blitze\\sitemaker\\migrations\\v30x\\m15_reparse_cblocks_data','a:1:{i:0;s:55:\"\\blitze\\sitemaker\\migrations\\v20x\\m5_add_cblocks_schema\";}',1,1,'',1606602308,1606602309),('\\blitze\\sitemaker\\migrations\\v30x\\m16_add_block_view_field','a:1:{i:0;s:51:\"\\blitze\\sitemaker\\migrations\\v20x\\m1_initial_schema\";}',1,1,'',1606602309,1606602310),('\\blitze\\sitemaker\\migrations\\v30x\\m17_add_settings_module','a:2:{i:0;s:54:\"\\blitze\\sitemaker\\migrations\\v20x\\m10_remove_dashboard\";i:1;s:58:\"\\blitze\\sitemaker\\migrations\\v30x\\m16_add_block_view_field\";}',1,1,'',1606602310,1606602313),('\\blitze\\sitemaker\\migrations\\v31x\\m310_filemanager','a:2:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v321\";i:1;s:57:\"\\blitze\\sitemaker\\migrations\\v30x\\m17_add_settings_module\";}',1,1,'',1606602313,1606602316),('\\brokencrust\\deletemyaccount\\migrations\\install_extention','a:0:{}',1,1,'',1606592956,1606592958),('\\dark1\\memberavatarstatus\\migrations\\mas_0000_main','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v320\\v320\";}',1,1,'',1606591615,1606591617),('\\dark1\\memberavatarstatus\\migrations\\mas_0001_memberlist','a:1:{i:0;s:50:\"\\dark1\\memberavatarstatus\\migrations\\mas_0000_main\";}',1,1,'',1606591618,1606591618),('\\dark1\\memberavatarstatus\\migrations\\mas_0002_viewonline','a:1:{i:0;s:56:\"\\dark1\\memberavatarstatus\\migrations\\mas_0001_memberlist\";}',1,1,'',1606591619,1606591620),('\\dark1\\memberavatarstatus\\migrations\\mas_0003_viewforum','a:1:{i:0;s:56:\"\\dark1\\memberavatarstatus\\migrations\\mas_0002_viewonline\";}',1,1,'',1606591620,1606591623),('\\dark1\\memberavatarstatus\\migrations\\mas_0004_search','a:1:{i:0;s:55:\"\\dark1\\memberavatarstatus\\migrations\\mas_0003_viewforum\";}',1,1,'',1606591623,1606591626),('\\dark1\\memberavatarstatus\\migrations\\mas_0005_review','a:1:{i:0;s:52:\"\\dark1\\memberavatarstatus\\migrations\\mas_0004_search\";}',1,1,'',1606591626,1606591627),('\\dark1\\memberavatarstatus\\migrations\\mas_0006_general','a:1:{i:0;s:52:\"\\dark1\\memberavatarstatus\\migrations\\mas_0005_review\";}',1,1,'',1606591627,1606591633),('\\dmzx\\mchat\\migrations\\mchat_2_0_0','a:1:{i:0;s:38:\"\\dmzx\\mchat\\migrations\\mchat_2_0_0_rc7\";}',1,1,'',1606593042,1606593042),('\\dmzx\\mchat\\migrations\\mchat_2_0_0_rc3','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v317pl1\";}',1,1,'',1606592988,1606593033),('\\dmzx\\mchat\\migrations\\mchat_2_0_0_rc4','a:1:{i:0;s:38:\"\\dmzx\\mchat\\migrations\\mchat_2_0_0_rc3\";}',1,1,'',1606593034,1606593034),('\\dmzx\\mchat\\migrations\\mchat_2_0_0_rc5','a:1:{i:0;s:38:\"\\dmzx\\mchat\\migrations\\mchat_2_0_0_rc4\";}',1,1,'',1606593034,1606593035),('\\dmzx\\mchat\\migrations\\mchat_2_0_0_rc6','a:1:{i:0;s:38:\"\\dmzx\\mchat\\migrations\\mchat_2_0_0_rc5\";}',1,1,'',1606593035,1606593041),('\\dmzx\\mchat\\migrations\\mchat_2_0_0_rc7','a:1:{i:0;s:38:\"\\dmzx\\mchat\\migrations\\mchat_2_0_0_rc6\";}',1,1,'',1606593041,1606593042),('\\dmzx\\mchat\\migrations\\mchat_2_0_1','a:1:{i:0;s:34:\"\\dmzx\\mchat\\migrations\\mchat_2_0_0\";}',1,1,'',1606593043,1606593043),('\\dmzx\\mchat\\migrations\\mchat_2_0_2','a:1:{i:0;s:34:\"\\dmzx\\mchat\\migrations\\mchat_2_0_1\";}',1,1,'',1606593043,1606593045),('\\dmzx\\mchat\\migrations\\mchat_2_0_3','a:1:{i:0;s:34:\"\\dmzx\\mchat\\migrations\\mchat_2_0_2\";}',1,1,'',1606593046,1606593047),('\\dmzx\\mchat\\migrations\\mchat_2_1_0','a:1:{i:0;s:38:\"\\dmzx\\mchat\\migrations\\mchat_2_1_0_rc1\";}',1,1,'',1606593085,1606593086),('\\dmzx\\mchat\\migrations\\mchat_2_1_0_rc1','a:1:{i:0;s:34:\"\\dmzx\\mchat\\migrations\\mchat_2_0_3\";}',1,1,'',1606593047,1606593085),('\\dmzx\\mchat\\migrations\\mchat_2_1_1','a:1:{i:0;s:34:\"\\dmzx\\mchat\\migrations\\mchat_2_1_0\";}',1,1,'',1606593086,1606593088),('\\dmzx\\mchat\\migrations\\mchat_2_1_2','a:1:{i:0;s:34:\"\\dmzx\\mchat\\migrations\\mchat_2_1_1\";}',1,1,'',1606593088,1606593089),('\\dmzx\\mchat\\migrations\\mchat_2_1_3','a:1:{i:0;s:34:\"\\dmzx\\mchat\\migrations\\mchat_2_1_2\";}',1,1,'',1606593089,1606593090),('\\dmzx\\mchat\\migrations\\mchat_2_1_4','a:1:{i:0;s:38:\"\\dmzx\\mchat\\migrations\\mchat_2_1_4_rc2\";}',1,1,'',1606593092,1606593092),('\\dmzx\\mchat\\migrations\\mchat_2_1_4_rc1','a:1:{i:0;s:34:\"\\dmzx\\mchat\\migrations\\mchat_2_1_3\";}',1,1,'',1606593090,1606593090),('\\dmzx\\mchat\\migrations\\mchat_2_1_4_rc2','a:1:{i:0;s:38:\"\\dmzx\\mchat\\migrations\\mchat_2_1_4_rc1\";}',1,1,'',1606593090,1606593092),('\\hifikabin\\largefont\\migrations\\v1x\\release_1_0_0_data','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606592970,1606592971),('\\hifikabin\\largefont\\migrations\\v1x\\release_1_0_0_schema','a:0:{}',1,1,'',1606592971,1606592972),('\\hifikabin\\largefont\\migrations\\v1x\\release_1_0_1_data','a:1:{i:0;s:54:\"\\hifikabin\\largefont\\migrations\\v1x\\release_1_0_0_data\";}',1,1,'',1606592972,1606592972),('\\hifikabin\\largefont\\migrations\\v1x\\release_1_0_1_schema','a:1:{i:0;s:56:\"\\hifikabin\\largefont\\migrations\\v1x\\release_1_0_0_schema\";}',1,1,'',1606592972,1606592973),('\\hifikabin\\largefont\\migrations\\v1x\\release_1_0_2_schema','a:1:{i:0;s:56:\"\\hifikabin\\largefont\\migrations\\v1x\\release_1_0_1_schema\";}',1,1,'',1606592973,1606592973),('\\hifikabin\\largefont\\migrations\\v1x\\release_1_0_3_schema','a:1:{i:0;s:56:\"\\hifikabin\\largefont\\migrations\\v1x\\release_1_0_2_schema\";}',1,1,'',1606592974,1606592974),('\\phpbb\\db\\migration\\data\\v30x\\local_url_bbcode','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc1\";}',1,1,'',1606579481,1606579481),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_0','a:0:{}',1,1,'',1606579482,1606579482),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1_rc1\";}',1,1,'',1606579482,1606579482),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc3\";}',1,1,'',1606579482,1606579482),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc1','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9\";}',1,1,'',1606579482,1606579482),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc2','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc1\";}',1,1,'',1606579482,1606579482),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc3','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10_rc2\";}',1,1,'',1606579483,1606579483),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11_rc2\";}',1,1,'',1606579483,1606579483),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11_rc1','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_10\";}',1,1,'',1606579484,1606579484),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11_rc2','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11_rc1\";}',1,1,'',1606579484,1606579484),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc3\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc1','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc2','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc1\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc3','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12_rc2\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_13','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_13_rc1\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_13_pl1','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_13\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_13_rc1','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_14','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_14_rc1\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_14_rc1','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_13\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1_rc1','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_0\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc2\";}',1,1,'',1606579485,1606579485),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc1','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1\";}',1,1,'',1606579486,1606579486),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc2','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc1\";}',1,1,'',1606579486,1606579486),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3_rc1\";}',1,1,'',1606579486,1606579486),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3_rc1','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2\";}',1,1,'',1606579486,1606579486),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4_rc1\";}',1,1,'',1606579486,1606579486),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4_rc1','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3\";}',1,1,'',1606579486,1606579486),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5','a:1:{i:0;s:52:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1part2\";}',1,1,'',1606579486,1606579486),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4\";}',1,1,'',1606579486,1606579486),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1part2','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1\";}',1,1,'',1606579486,1606579486),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc4\";}',1,1,'',1606579486,1606579486),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc1','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5\";}',1,1,'',1606579487,1606579487),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc2','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc1\";}',1,1,'',1606579487,1606579487),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc3','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc2\";}',1,1,'',1606579487,1606579487),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc4','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6_rc3\";}',1,1,'',1606579487,1606579487),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_rc2\";}',1,1,'',1606579487,1606579487),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_pl1','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_rc1','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_6\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_rc2','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_rc1\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_8','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_8_rc1\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_8_rc1','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_7_pl1\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc4\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc1','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_8\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc2','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc1\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc3','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc2\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc4','a:1:{i:0;s:47:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_9_rc3\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v310\\acp_prune_users_module','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta1\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v310\\acp_style_components_module','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579488,1606579488),('\\phpbb\\db\\migration\\data\\v310\\allow_cdn','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v310\\jquery_update\";}',1,1,'',1606579489,1606579489),('\\phpbb\\db\\migration\\data\\v310\\alpha1','a:18:{i:0;s:46:\"\\phpbb\\db\\migration\\data\\v30x\\local_url_bbcode\";i:1;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_12\";i:2;s:57:\"\\phpbb\\db\\migration\\data\\v310\\acp_style_components_module\";i:3;s:39:\"\\phpbb\\db\\migration\\data\\v310\\allow_cdn\";i:4;s:49:\"\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth\";i:5;s:37:\"\\phpbb\\db\\migration\\data\\v310\\avatars\";i:6;s:40:\"\\phpbb\\db\\migration\\data\\v310\\boardindex\";i:7;s:44:\"\\phpbb\\db\\migration\\data\\v310\\config_db_text\";i:8;s:45:\"\\phpbb\\db\\migration\\data\\v310\\forgot_password\";i:9;s:41:\"\\phpbb\\db\\migration\\data\\v310\\mod_rewrite\";i:10;s:49:\"\\phpbb\\db\\migration\\data\\v310\\mysql_fulltext_drop\";i:11;s:40:\"\\phpbb\\db\\migration\\data\\v310\\namespaces\";i:12;s:48:\"\\phpbb\\db\\migration\\data\\v310\\notifications_cron\";i:13;s:60:\"\\phpbb\\db\\migration\\data\\v310\\notification_options_reconvert\";i:14;s:38:\"\\phpbb\\db\\migration\\data\\v310\\plupload\";i:15;s:51:\"\\phpbb\\db\\migration\\data\\v310\\signature_module_auth\";i:16;s:52:\"\\phpbb\\db\\migration\\data\\v310\\softdelete_mcp_modules\";i:17;s:38:\"\\phpbb\\db\\migration\\data\\v310\\teampage\";}',1,1,'',1606579489,1606579489),('\\phpbb\\db\\migration\\data\\v310\\alpha2','a:2:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v310\\alpha1\";i:1;s:51:\"\\phpbb\\db\\migration\\data\\v310\\notifications_cron_p2\";}',1,1,'',1606579489,1606579489),('\\phpbb\\db\\migration\\data\\v310\\alpha3','a:4:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v310\\alpha2\";i:1;s:42:\"\\phpbb\\db\\migration\\data\\v310\\avatar_types\";i:2;s:39:\"\\phpbb\\db\\migration\\data\\v310\\passwords\";i:3;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}',1,1,'',1606579489,1606579489),('\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_0\";}',1,1,'',1606579489,1606579489),('\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth2','a:1:{i:0;s:49:\"\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth\";}',1,1,'',1606579489,1606579489),('\\phpbb\\db\\migration\\data\\v310\\avatar_types','a:2:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";i:1;s:37:\"\\phpbb\\db\\migration\\data\\v310\\avatars\";}',1,1,'',1606579489,1606579489),('\\phpbb\\db\\migration\\data\\v310\\avatars','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}',1,1,'',1606579489,1606579489),('\\phpbb\\db\\migration\\data\\v310\\beta1','a:7:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v310\\alpha3\";i:1;s:42:\"\\phpbb\\db\\migration\\data\\v310\\passwords_p2\";i:2;s:52:\"\\phpbb\\db\\migration\\data\\v310\\postgres_fulltext_drop\";i:3;s:63:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_change_load_settings\";i:4;s:51:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_location\";i:5;s:54:\"\\phpbb\\db\\migration\\data\\v310\\soft_delete_mod_convert2\";i:6;s:48:\"\\phpbb\\db\\migration\\data\\v310\\ucp_popuppm_module\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\beta2','a:3:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta1\";i:1;s:52:\"\\phpbb\\db\\migration\\data\\v310\\acp_prune_users_module\";i:2;s:59:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_location_cleanup\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\beta3','a:6:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta2\";i:1;s:50:\"\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth2\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\board_contact_name\";i:3;s:44:\"\\phpbb\\db\\migration\\data\\v310\\jquery_update2\";i:4;s:50:\"\\phpbb\\db\\migration\\data\\v310\\live_searches_config\";i:5;s:49:\"\\phpbb\\db\\migration\\data\\v310\\prune_shadow_topics\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\beta4','a:3:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta3\";i:1;s:69:\"\\phpbb\\db\\migration\\data\\v310\\extensions_version_check_force_unstable\";i:2;s:58:\"\\phpbb\\db\\migration\\data\\v310\\reset_missing_captcha_plugin\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\board_contact_name','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta2\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\boardindex','a:0:{}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\bot_update','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc6\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\captcha_plugins','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc2\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\config_db_text','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\contact_admin_acp_module','a:0:{}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\contact_admin_form','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v310\\config_db_text\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\dev','a:5:{i:0;s:40:\"\\phpbb\\db\\migration\\data\\v310\\extensions\";i:1;s:45:\"\\phpbb\\db\\migration\\data\\v310\\style_update_p2\";i:2;s:41:\"\\phpbb\\db\\migration\\data\\v310\\timezone_p2\";i:3;s:52:\"\\phpbb\\db\\migration\\data\\v310\\reported_posts_display\";i:4;s:46:\"\\phpbb\\db\\migration\\data\\v310\\migrations_table\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\extensions','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}',1,1,'',1606579490,1606579490),('\\phpbb\\db\\migration\\data\\v310\\extensions_version_check_force_unstable','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579491,1606579491),('\\phpbb\\db\\migration\\data\\v310\\forgot_password','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}',1,1,'',1606579491,1606579491),('\\phpbb\\db\\migration\\data\\v310\\gold','a:2:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc6\";i:1;s:40:\"\\phpbb\\db\\migration\\data\\v310\\bot_update\";}',1,1,'',1606579491,1606579491),('\\phpbb\\db\\migration\\data\\v310\\jquery_update','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579491,1606579491),('\\phpbb\\db\\migration\\data\\v310\\jquery_update2','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v310\\jquery_update\";}',1,1,'',1606579491,1606579491),('\\phpbb\\db\\migration\\data\\v310\\live_searches_config','a:0:{}',1,1,'',1606579491,1606579491),('\\phpbb\\db\\migration\\data\\v310\\migrations_table','a:0:{}',1,1,'',1606579491,1606579491),('\\phpbb\\db\\migration\\data\\v310\\mod_rewrite','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579491,1606579491),('\\phpbb\\db\\migration\\data\\v310\\mysql_fulltext_drop','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579491,1606579491),('\\phpbb\\db\\migration\\data\\v310\\namespaces','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579491,1606579491),('\\phpbb\\db\\migration\\data\\v310\\notification_options_reconvert','a:1:{i:0;s:54:\"\\phpbb\\db\\migration\\data\\v310\\notifications_schema_fix\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\notifications','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\notifications_cron','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v310\\notifications\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\notifications_cron_p2','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\notifications_cron\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\notifications_schema_fix','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v310\\notifications\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\notifications_use_full_name','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc3\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\passwords','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\passwords_convert_p1','a:1:{i:0;s:42:\"\\phpbb\\db\\migration\\data\\v310\\passwords_p2\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\passwords_convert_p2','a:1:{i:0;s:50:\"\\phpbb\\db\\migration\\data\\v310\\passwords_convert_p1\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\passwords_p2','a:1:{i:0;s:39:\"\\phpbb\\db\\migration\\data\\v310\\passwords\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\plupload','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579492,1606579492),('\\phpbb\\db\\migration\\data\\v310\\postgres_fulltext_drop','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_aol','a:1:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_yahoo_cleanup\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_aol_cleanup','a:1:{i:0;s:46:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_aol\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_change_load_settings','a:1:{i:0;s:54:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_aol_cleanup\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_cleanup','a:2:{i:0;s:52:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_interests\";i:1;s:53:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_occupation\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field','a:1:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_on_memberlist\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_facebook','a:3:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_field_validation_length','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc3\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_googleplus','a:3:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_icq','a:1:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_icq_cleanup','a:1:{i:0;s:46:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_icq\";}',1,1,'',1606579493,1606579493),('\\phpbb\\db\\migration\\data\\v310\\profilefield_interests','a:2:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";}',1,1,'',1606579494,1606579494),('\\phpbb\\db\\migration\\data\\v310\\profilefield_location','a:2:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";i:1;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_on_memberlist\";}',1,1,'',1606579494,1606579494),('\\phpbb\\db\\migration\\data\\v310\\profilefield_location_cleanup','a:1:{i:0;s:51:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_location\";}',1,1,'',1606579494,1606579494),('\\phpbb\\db\\migration\\data\\v310\\profilefield_occupation','a:1:{i:0;s:52:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_interests\";}',1,1,'',1606579494,1606579494),('\\phpbb\\db\\migration\\data\\v310\\profilefield_on_memberlist','a:1:{i:0;s:50:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_cleanup\";}',1,1,'',1606579494,1606579494),('\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}',1,1,'',1606579495,1606579495),('\\phpbb\\db\\migration\\data\\v310\\profilefield_skype','a:3:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}',1,1,'',1606579495,1606579495),('\\phpbb\\db\\migration\\data\\v310\\profilefield_twitter','a:3:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}',1,1,'',1606579495,1606579495),('\\phpbb\\db\\migration\\data\\v310\\profilefield_types','a:1:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v310\\alpha2\";}',1,1,'',1606579495,1606579495),('\\phpbb\\db\\migration\\data\\v310\\profilefield_website','a:2:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_on_memberlist\";i:1;s:54:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_icq_cleanup\";}',1,1,'',1606579495,1606579495),('\\phpbb\\db\\migration\\data\\v310\\profilefield_website_cleanup','a:1:{i:0;s:50:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_website\";}',1,1,'',1606579496,1606579496),('\\phpbb\\db\\migration\\data\\v310\\profilefield_wlm','a:1:{i:0;s:58:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_website_cleanup\";}',1,1,'',1606579496,1606579496),('\\phpbb\\db\\migration\\data\\v310\\profilefield_wlm_cleanup','a:1:{i:0;s:46:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_wlm\";}',1,1,'',1606579496,1606579496),('\\phpbb\\db\\migration\\data\\v310\\profilefield_yahoo','a:1:{i:0;s:54:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_wlm_cleanup\";}',1,1,'',1606579496,1606579496),('\\phpbb\\db\\migration\\data\\v310\\profilefield_yahoo_cleanup','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_yahoo\";}',1,1,'',1606579496,1606579496),('\\phpbb\\db\\migration\\data\\v310\\profilefield_youtube','a:3:{i:0;s:56:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_contact_field\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_show_novalue\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_types\";}',1,1,'',1606579497,1606579497),('\\phpbb\\db\\migration\\data\\v310\\prune_shadow_topics','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579497,1606579497),('\\phpbb\\db\\migration\\data\\v310\\rc1','a:9:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta4\";i:1;s:54:\"\\phpbb\\db\\migration\\data\\v310\\contact_admin_acp_module\";i:2;s:48:\"\\phpbb\\db\\migration\\data\\v310\\contact_admin_form\";i:3;s:50:\"\\phpbb\\db\\migration\\data\\v310\\passwords_convert_p2\";i:4;s:51:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_facebook\";i:5;s:53:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_googleplus\";i:6;s:48:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_skype\";i:7;s:50:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_twitter\";i:8;s:50:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_youtube\";}',1,1,'',1606579497,1606579497),('\\phpbb\\db\\migration\\data\\v310\\rc2','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc1\";}',1,1,'',1606579497,1606579497),('\\phpbb\\db\\migration\\data\\v310\\rc3','a:5:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc2\";i:1;s:45:\"\\phpbb\\db\\migration\\data\\v310\\captcha_plugins\";i:2;s:53:\"\\phpbb\\db\\migration\\data\\v310\\rename_too_long_indexes\";i:3;s:41:\"\\phpbb\\db\\migration\\data\\v310\\search_type\";i:4;s:49:\"\\phpbb\\db\\migration\\data\\v310\\topic_sort_username\";}',1,1,'',1606579497,1606579497),('\\phpbb\\db\\migration\\data\\v310\\rc4','a:2:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc3\";i:1;s:57:\"\\phpbb\\db\\migration\\data\\v310\\notifications_use_full_name\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\rc5','a:3:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc4\";i:1;s:66:\"\\phpbb\\db\\migration\\data\\v310\\profilefield_field_validation_length\";i:2;s:53:\"\\phpbb\\db\\migration\\data\\v310\\remove_acp_styles_cache\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\rc6','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc5\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\remove_acp_styles_cache','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\rc4\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\rename_too_long_indexes','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_0\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\reported_posts_display','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\reset_missing_captcha_plugin','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\search_type','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\signature_module_auth','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\soft_delete_mod_convert','a:1:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v310\\alpha3\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\soft_delete_mod_convert2','a:1:{i:0;s:53:\"\\phpbb\\db\\migration\\data\\v310\\soft_delete_mod_convert\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\softdelete_mcp_modules','a:2:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";i:1;s:43:\"\\phpbb\\db\\migration\\data\\v310\\softdelete_p2\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\softdelete_p1','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\softdelete_p2','a:2:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";i:1;s:43:\"\\phpbb\\db\\migration\\data\\v310\\softdelete_p1\";}',1,1,'',1606579498,1606579498),('\\phpbb\\db\\migration\\data\\v310\\style_update_p1','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v310\\style_update_p2','a:1:{i:0;s:45:\"\\phpbb\\db\\migration\\data\\v310\\style_update_p1\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v310\\teampage','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v310\\timezone','a:1:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_11\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v310\\timezone_p2','a:1:{i:0;s:38:\"\\phpbb\\db\\migration\\data\\v310\\timezone\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v310\\topic_sort_username','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v310\\ucp_popuppm_module','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v31x\\add_jabber_ssl_context_config_options','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v31x\\v3110\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v31x\\add_latest_topics_index','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v31x\\v3110\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v31x\\add_log_time_index','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v319\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v31x\\add_smtp_ssl_context_config_options','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v31x\\v3110\";}',1,1,'',1606579499,1606579499),('\\phpbb\\db\\migration\\data\\v31x\\increase_size_of_dateformat','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v317\";}',1,1,'',1606579500,1606579500),('\\phpbb\\db\\migration\\data\\v31x\\increase_size_of_emotion','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v31x\\v3110\";}',1,1,'',1606579500,1606579500),('\\phpbb\\db\\migration\\data\\v31x\\m_pm_report','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v316rc1\";}',1,1,'',1606579500,1606579500),('\\phpbb\\db\\migration\\data\\v31x\\m_softdelete_global','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v311\";}',1,1,'',1606579500,1606579500),('\\phpbb\\db\\migration\\data\\v31x\\plupload_last_gc_dynamic','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v312\";}',1,1,'',1606579500,1606579500),('\\phpbb\\db\\migration\\data\\v31x\\profilefield_remove_underscore_from_alpha','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v311\";}',1,1,'',1606579500,1606579500),('\\phpbb\\db\\migration\\data\\v31x\\profilefield_yahoo_update_url','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v312\";}',1,1,'',1606579500,1606579500),('\\phpbb\\db\\migration\\data\\v31x\\remove_duplicate_migrations','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v31x\\v3110\";}',1,1,'',1606579500,1606579500),('\\phpbb\\db\\migration\\data\\v31x\\style_update','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v310\\gold\";}',1,1,'',1606579500,1606579500),('\\phpbb\\db\\migration\\data\\v31x\\update_custom_bbcodes_with_idn','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v312\";}',1,1,'',1606579500,1606579500),('\\phpbb\\db\\migration\\data\\v31x\\update_hashes','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v31x\\v3110\";}',1,1,'',1606579501,1606579501),('\\phpbb\\db\\migration\\data\\v31x\\v311','a:2:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v310\\gold\";i:1;s:42:\"\\phpbb\\db\\migration\\data\\v31x\\style_update\";}',1,1,'',1606579501,1606579501),('\\phpbb\\db\\migration\\data\\v31x\\v3110','a:1:{i:0;s:38:\"\\phpbb\\db\\migration\\data\\v31x\\v3110rc1\";}',1,1,'',1606579501,1606579501),('\\phpbb\\db\\migration\\data\\v31x\\v3110rc1','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v319\";}',1,1,'',1606579501,1606579501),('\\phpbb\\db\\migration\\data\\v31x\\v3111','a:1:{i:0;s:38:\"\\phpbb\\db\\migration\\data\\v31x\\v3111rc1\";}',1,1,'',1606579501,1606579501),('\\phpbb\\db\\migration\\data\\v31x\\v3111rc1','a:8:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v31x\\v3110\";i:1;s:48:\"\\phpbb\\db\\migration\\data\\v31x\\add_log_time_index\";i:2;s:54:\"\\phpbb\\db\\migration\\data\\v31x\\increase_size_of_emotion\";i:3;s:67:\"\\phpbb\\db\\migration\\data\\v31x\\add_jabber_ssl_context_config_options\";i:4;s:65:\"\\phpbb\\db\\migration\\data\\v31x\\add_smtp_ssl_context_config_options\";i:5;s:43:\"\\phpbb\\db\\migration\\data\\v31x\\update_hashes\";i:6;s:57:\"\\phpbb\\db\\migration\\data\\v31x\\remove_duplicate_migrations\";i:7;s:53:\"\\phpbb\\db\\migration\\data\\v31x\\add_latest_topics_index\";}',1,1,'',1606579501,1606579501),('\\phpbb\\db\\migration\\data\\v31x\\v3112','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v31x\\v3111\";}',1,1,'',1606579502,1606579502),('\\phpbb\\db\\migration\\data\\v31x\\v312','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v312rc1\";}',1,1,'',1606579502,1606579502),('\\phpbb\\db\\migration\\data\\v31x\\v312rc1','a:2:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v311\";i:1;s:49:\"\\phpbb\\db\\migration\\data\\v31x\\m_softdelete_global\";}',1,1,'',1606579502,1606579502),('\\phpbb\\db\\migration\\data\\v31x\\v313','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v313rc2\";}',1,1,'',1606579502,1606579502),('\\phpbb\\db\\migration\\data\\v31x\\v313rc1','a:5:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_13_rc1\";i:1;s:54:\"\\phpbb\\db\\migration\\data\\v31x\\plupload_last_gc_dynamic\";i:2;s:71:\"\\phpbb\\db\\migration\\data\\v31x\\profilefield_remove_underscore_from_alpha\";i:3;s:59:\"\\phpbb\\db\\migration\\data\\v31x\\profilefield_yahoo_update_url\";i:4;s:60:\"\\phpbb\\db\\migration\\data\\v31x\\update_custom_bbcodes_with_idn\";}',1,1,'',1606579502,1606579502),('\\phpbb\\db\\migration\\data\\v31x\\v313rc2','a:2:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_13_pl1\";i:1;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v313rc1\";}',1,1,'',1606579503,1606579503),('\\phpbb\\db\\migration\\data\\v31x\\v314','a:2:{i:0;s:44:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_14\";i:1;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v314rc2\";}',1,1,'',1606579503,1606579503),('\\phpbb\\db\\migration\\data\\v31x\\v314rc1','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v313\";}',1,1,'',1606579503,1606579503),('\\phpbb\\db\\migration\\data\\v31x\\v314rc2','a:2:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_14_rc1\";i:1;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v314rc1\";}',1,1,'',1606579503,1606579503),('\\phpbb\\db\\migration\\data\\v31x\\v315','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v315rc1\";}',1,1,'',1606579503,1606579503),('\\phpbb\\db\\migration\\data\\v31x\\v315rc1','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v314\";}',1,1,'',1606579503,1606579503),('\\phpbb\\db\\migration\\data\\v31x\\v316','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v316rc1\";}',1,1,'',1606579503,1606579503),('\\phpbb\\db\\migration\\data\\v31x\\v316rc1','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v315\";}',1,1,'',1606579504,1606579504),('\\phpbb\\db\\migration\\data\\v31x\\v317','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v317rc1\";}',1,1,'',1606579504,1606579504),('\\phpbb\\db\\migration\\data\\v31x\\v317pl1','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v317\";}',1,1,'',1606579504,1606579504),('\\phpbb\\db\\migration\\data\\v31x\\v317rc1','a:2:{i:0;s:41:\"\\phpbb\\db\\migration\\data\\v31x\\m_pm_report\";i:1;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v316\";}',1,1,'',1606579504,1606579504),('\\phpbb\\db\\migration\\data\\v31x\\v318','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v318rc1\";}',1,1,'',1606579504,1606579504),('\\phpbb\\db\\migration\\data\\v31x\\v318rc1','a:2:{i:0;s:57:\"\\phpbb\\db\\migration\\data\\v31x\\increase_size_of_dateformat\";i:1;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v317pl1\";}',1,1,'',1606579504,1606579504),('\\phpbb\\db\\migration\\data\\v31x\\v319','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v319rc1\";}',1,1,'',1606579505,1606579505),('\\phpbb\\db\\migration\\data\\v31x\\v319rc1','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v318\";}',1,1,'',1606579505,1606579505),('\\phpbb\\db\\migration\\data\\v320\\add_help_phpbb','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v320\\v320rc1\";}',1,1,'',1606579505,1606579505),('\\phpbb\\db\\migration\\data\\v320\\allowed_schemes_links','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v320\\dev\";}',1,1,'',1606579505,1606579505),('\\phpbb\\db\\migration\\data\\v320\\announce_global_permission','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v320\\dev\";}',1,1,'',1606579505,1606579505),('\\phpbb\\db\\migration\\data\\v320\\cookie_notice','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v320\\v320rc2\";}',1,1,'',1606579506,1606579506),('\\phpbb\\db\\migration\\data\\v320\\default_data_type_ids','a:2:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v320\\v320a2\";i:1;s:42:\"\\phpbb\\db\\migration\\data\\v320\\oauth_states\";}',1,1,'',1606579506,1606579506),('\\phpbb\\db\\migration\\data\\v320\\dev','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v316\";}',1,1,'',1606579506,1606579506),('\\phpbb\\db\\migration\\data\\v320\\font_awesome_update','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v320\\dev\";}',1,1,'',1606579506,1606579506),('\\phpbb\\db\\migration\\data\\v320\\icons_alt','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v320\\dev\";}',1,1,'',1606579507,1606579507),('\\phpbb\\db\\migration\\data\\v320\\log_post_id','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v320\\dev\";}',1,1,'',1606579507,1606579507),('\\phpbb\\db\\migration\\data\\v320\\notifications_board','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v320\\dev\";}',1,1,'',1606579507,1606579507),('\\phpbb\\db\\migration\\data\\v320\\oauth_states','a:1:{i:0;s:49:\"\\phpbb\\db\\migration\\data\\v310\\auth_provider_oauth\";}',1,1,'',1606579507,1606579507),('\\phpbb\\db\\migration\\data\\v320\\remote_upload_validation','a:1:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v320\\v320a2\";}',1,1,'',1606579507,1606579507),('\\phpbb\\db\\migration\\data\\v320\\remove_outdated_media','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v320\\dev\";}',1,1,'',1606579507,1606579507),('\\phpbb\\db\\migration\\data\\v320\\remove_profilefield_wlm','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v320\\dev\";}',1,1,'',1606579507,1606579507),('\\phpbb\\db\\migration\\data\\v320\\report_id_auto_increment','a:1:{i:0;s:51:\"\\phpbb\\db\\migration\\data\\v320\\default_data_type_ids\";}',1,1,'',1606579507,1606579507),('\\phpbb\\db\\migration\\data\\v320\\text_reparser','a:2:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v310\\contact_admin_form\";i:1;s:51:\"\\phpbb\\db\\migration\\data\\v320\\allowed_schemes_links\";}',1,1,'',1606579508,1606579508),('\\phpbb\\db\\migration\\data\\v320\\v320','a:2:{i:0;s:54:\"\\phpbb\\db\\migration\\data\\v31x\\increase_size_of_emotion\";i:1;s:43:\"\\phpbb\\db\\migration\\data\\v320\\cookie_notice\";}',1,1,'',1606579508,1606579508),('\\phpbb\\db\\migration\\data\\v320\\v320a1','a:9:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v320\\dev\";i:1;s:51:\"\\phpbb\\db\\migration\\data\\v320\\allowed_schemes_links\";i:2;s:56:\"\\phpbb\\db\\migration\\data\\v320\\announce_global_permission\";i:3;s:53:\"\\phpbb\\db\\migration\\data\\v320\\remove_profilefield_wlm\";i:4;s:49:\"\\phpbb\\db\\migration\\data\\v320\\font_awesome_update\";i:5;s:39:\"\\phpbb\\db\\migration\\data\\v320\\icons_alt\";i:6;s:41:\"\\phpbb\\db\\migration\\data\\v320\\log_post_id\";i:7;s:51:\"\\phpbb\\db\\migration\\data\\v320\\remove_outdated_media\";i:8;s:49:\"\\phpbb\\db\\migration\\data\\v320\\notifications_board\";}',1,1,'',1606579508,1606579508),('\\phpbb\\db\\migration\\data\\v320\\v320a2','a:3:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v317rc1\";i:1;s:43:\"\\phpbb\\db\\migration\\data\\v320\\text_reparser\";i:2;s:36:\"\\phpbb\\db\\migration\\data\\v320\\v320a1\";}',1,1,'',1606579508,1606579508),('\\phpbb\\db\\migration\\data\\v320\\v320b1','a:4:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v317pl1\";i:1;s:36:\"\\phpbb\\db\\migration\\data\\v320\\v320a2\";i:2;s:57:\"\\phpbb\\db\\migration\\data\\v31x\\increase_size_of_dateformat\";i:3;s:51:\"\\phpbb\\db\\migration\\data\\v320\\default_data_type_ids\";}',1,1,'',1606579508,1606579508),('\\phpbb\\db\\migration\\data\\v320\\v320b2','a:3:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v318\";i:1;s:36:\"\\phpbb\\db\\migration\\data\\v320\\v320b1\";i:2;s:54:\"\\phpbb\\db\\migration\\data\\v320\\remote_upload_validation\";}',1,1,'',1606579508,1606579508),('\\phpbb\\db\\migration\\data\\v320\\v320rc1','a:3:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v319\";i:1;s:54:\"\\phpbb\\db\\migration\\data\\v320\\report_id_auto_increment\";i:2;s:36:\"\\phpbb\\db\\migration\\data\\v320\\v320b2\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v320\\v320rc2','a:3:{i:0;s:57:\"\\phpbb\\db\\migration\\data\\v31x\\remove_duplicate_migrations\";i:1;s:48:\"\\phpbb\\db\\migration\\data\\v31x\\add_log_time_index\";i:2;s:44:\"\\phpbb\\db\\migration\\data\\v320\\add_help_phpbb\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\add_missing_config','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v329\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\add_plupload_config','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v329\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\cookie_notice_p2','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v320\\v320\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\disable_remote_avatar','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v325\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\email_force_sender','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v321\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\enable_accurate_pm_button','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v322\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\f_list_topics_permission_add','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v321\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\fix_user_styles','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v320\\v320\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\font_awesome_update_cdn','a:1:{i:0;s:48:\"\\phpbb\\db\\migration\\data\\v32x\\add_missing_config\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\font_awesome_update_cdn_fix_depends_on','a:2:{i:0;s:53:\"\\phpbb\\db\\migration\\data\\v32x\\font_awesome_update_cdn\";i:1;s:48:\"\\phpbb\\db\\migration\\data\\v32x\\add_missing_config\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\forum_topics_per_page_type','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v323\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\jquery_update','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v325rc1\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\load_user_activity_limit','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v320\\v320\";}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\merge_duplicate_bbcodes','a:0:{}',1,1,'',1606579509,1606579509),('\\phpbb\\db\\migration\\data\\v32x\\remove_imagick','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v324rc1\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\smtp_dynamic_data','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v326rc1\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\timezone_p3','a:1:{i:0;s:38:\"\\phpbb\\db\\migration\\data\\v310\\timezone\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\update_prosilver_bitfield','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v321\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\user_emoji_permission','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v329rc1\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_index_p1','a:1:{i:0;s:46:\"\\phpbb\\db\\migration\\data\\v32x\\cookie_notice_p2\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_index_p2','a:1:{i:0;s:63:\"\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_index_p1\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_index_p3','a:1:{i:0;s:63:\"\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_index_p2\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_reduce_column_sizes','a:1:{i:0;s:63:\"\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_index_p3\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_remove_duplicates','a:1:{i:0;s:65:\"\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_temp_index\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_temp_index','a:1:{i:0;s:74:\"\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_reduce_column_sizes\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_unique_index','a:1:{i:0;s:72:\"\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_remove_duplicates\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\v321','a:2:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v31x\\v3111\";i:1;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v321rc1\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\v3210','a:1:{i:0;s:38:\"\\phpbb\\db\\migration\\data\\v32x\\v3210rc2\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\v3210rc1','a:3:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v329\";i:1;s:49:\"\\phpbb\\db\\migration\\data\\v32x\\add_plupload_config\";i:2;s:53:\"\\phpbb\\db\\migration\\data\\v32x\\font_awesome_update_cdn\";}',1,1,'',1606579510,1606579510),('\\phpbb\\db\\migration\\data\\v32x\\v3210rc2','a:2:{i:0;s:68:\"\\phpbb\\db\\migration\\data\\v32x\\font_awesome_update_cdn_fix_depends_on\";i:1;s:38:\"\\phpbb\\db\\migration\\data\\v32x\\v3210rc1\";}',1,1,'',1606579511,1606579511),('\\phpbb\\db\\migration\\data\\v32x\\v3211','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v32x\\v3210\";}',1,1,'',1606579511,1606579511),('\\phpbb\\db\\migration\\data\\v32x\\v321rc1','a:4:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v320\\v320\";i:1;s:38:\"\\phpbb\\db\\migration\\data\\v31x\\v3111rc1\";i:2;s:54:\"\\phpbb\\db\\migration\\data\\v32x\\load_user_activity_limit\";i:3;s:67:\"\\phpbb\\db\\migration\\data\\v32x\\user_notifications_table_unique_index\";}',1,1,'',1606579511,1606579511),('\\phpbb\\db\\migration\\data\\v32x\\v322','a:2:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v31x\\v3112\";i:1;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v322rc1\";}',1,1,'',1606579511,1606579511),('\\phpbb\\db\\migration\\data\\v32x\\v322rc1','a:6:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v321\";i:1;s:45:\"\\phpbb\\db\\migration\\data\\v32x\\fix_user_styles\";i:2;s:55:\"\\phpbb\\db\\migration\\data\\v32x\\update_prosilver_bitfield\";i:3;s:48:\"\\phpbb\\db\\migration\\data\\v32x\\email_force_sender\";i:4;s:58:\"\\phpbb\\db\\migration\\data\\v32x\\f_list_topics_permission_add\";i:5;s:53:\"\\phpbb\\db\\migration\\data\\v32x\\merge_duplicate_bbcodes\";}',1,1,'',1606579511,1606579511),('\\phpbb\\db\\migration\\data\\v32x\\v323','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v323rc2\";}',1,1,'',1606579511,1606579511),('\\phpbb\\db\\migration\\data\\v32x\\v323rc1','a:2:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v322\";i:1;s:55:\"\\phpbb\\db\\migration\\data\\v32x\\enable_accurate_pm_button\";}',1,1,'',1606579511,1606579511),('\\phpbb\\db\\migration\\data\\v32x\\v323rc2','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v323rc1\";}',1,1,'',1606579511,1606579511),('\\phpbb\\db\\migration\\data\\v32x\\v324','a:2:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v324rc1\";i:1;s:44:\"\\phpbb\\db\\migration\\data\\v32x\\remove_imagick\";}',1,1,'',1606579512,1606579512),('\\phpbb\\db\\migration\\data\\v32x\\v324rc1','a:2:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v323\";i:1;s:56:\"\\phpbb\\db\\migration\\data\\v32x\\forum_topics_per_page_type\";}',1,1,'',1606579512,1606579512),('\\phpbb\\db\\migration\\data\\v32x\\v325','a:2:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v325rc1\";i:1;s:43:\"\\phpbb\\db\\migration\\data\\v32x\\jquery_update\";}',1,1,'',1606579512,1606579512),('\\phpbb\\db\\migration\\data\\v32x\\v325rc1','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v324\";}',1,1,'',1606579512,1606579512),('\\phpbb\\db\\migration\\data\\v32x\\v326','a:3:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v326rc1\";i:1;s:51:\"\\phpbb\\db\\migration\\data\\v32x\\disable_remote_avatar\";i:2;s:47:\"\\phpbb\\db\\migration\\data\\v32x\\smtp_dynamic_data\";}',1,1,'',1606579512,1606579512),('\\phpbb\\db\\migration\\data\\v32x\\v326rc1','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v325\";}',1,1,'',1606579512,1606579512),('\\phpbb\\db\\migration\\data\\v32x\\v327','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v327rc1\";}',1,1,'',1606579512,1606579512),('\\phpbb\\db\\migration\\data\\v32x\\v327rc1','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v326\";}',1,1,'',1606579512,1606579512),('\\phpbb\\db\\migration\\data\\v32x\\v328','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v328rc1\";}',1,1,'',1606579512,1606579512),('\\phpbb\\db\\migration\\data\\v32x\\v328rc1','a:2:{i:0;s:41:\"\\phpbb\\db\\migration\\data\\v32x\\timezone_p3\";i:1;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v327\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v32x\\v329','a:2:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v32x\\v329rc1\";i:1;s:51:\"\\phpbb\\db\\migration\\data\\v32x\\user_emoji_permission\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v32x\\v329rc1','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v328\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\add_display_unapproved_posts_config','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v330\\dev\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\dev','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v327\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\forums_legend_limit','a:1:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v330\\v330b1\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\jquery_update','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v330\\dev\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\remove_attachment_flash','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v330\\dev\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\remove_email_hash','a:1:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_0\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\remove_max_pass_chars','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v330\\dev\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\reset_password','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v330\\dev\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\v330','a:2:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v329\";i:1;s:37:\"\\phpbb\\db\\migration\\data\\v330\\v330rc1\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\v330b1','a:6:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v330\\jquery_update\";i:1;s:44:\"\\phpbb\\db\\migration\\data\\v330\\reset_password\";i:2;s:53:\"\\phpbb\\db\\migration\\data\\v330\\remove_attachment_flash\";i:3;s:51:\"\\phpbb\\db\\migration\\data\\v330\\remove_max_pass_chars\";i:4;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v328\";i:5;s:33:\"\\phpbb\\db\\migration\\data\\v330\\dev\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\v330b2','a:4:{i:0;s:65:\"\\phpbb\\db\\migration\\data\\v330\\add_display_unapproved_posts_config\";i:1;s:49:\"\\phpbb\\db\\migration\\data\\v330\\forums_legend_limit\";i:2;s:47:\"\\phpbb\\db\\migration\\data\\v330\\remove_email_hash\";i:3;s:36:\"\\phpbb\\db\\migration\\data\\v330\\v330b1\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v330\\v330rc1','a:1:{i:0;s:36:\"\\phpbb\\db\\migration\\data\\v330\\v330b2\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v33x\\add_notification_emails_table','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v330\\v330\";}',1,1,'',1606579513,1606579513),('\\phpbb\\db\\migration\\data\\v33x\\bot_update','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v330\\v330\";}',1,1,'',1606579514,1606579514),('\\phpbb\\db\\migration\\data\\v33x\\default_search_return_chars','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v330\\v330\";}',1,1,'',1606579514,1606579514),('\\phpbb\\db\\migration\\data\\v33x\\fix_display_unapproved_posts_config','a:1:{i:0;s:65:\"\\phpbb\\db\\migration\\data\\v330\\add_display_unapproved_posts_config\";}',1,1,'',1606579514,1606579514),('\\phpbb\\db\\migration\\data\\v33x\\font_awesome_5_rollback','a:1:{i:0;s:51:\"\\phpbb\\db\\migration\\data\\v33x\\font_awesome_5_update\";}',1,1,'',1606579514,1606579514),('\\phpbb\\db\\migration\\data\\v33x\\font_awesome_5_update','a:2:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v330\\v330\";i:1;s:53:\"\\phpbb\\db\\migration\\data\\v32x\\font_awesome_update_cdn\";}',1,1,'',1606579514,1606579514),('\\phpbb\\db\\migration\\data\\v33x\\google_recaptcha_v3','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v330\\v330\";}',1,1,'',1606579514,1606579514),('\\phpbb\\db\\migration\\data\\v33x\\jquery_update','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v33x\\v331rc1\";}',1,1,'',1606579514,1606579514),('\\phpbb\\db\\migration\\data\\v33x\\profilefield_cleanup','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v330\\v330\";}',1,1,'',1606579514,1606579514),('\\phpbb\\db\\migration\\data\\v33x\\remove_profilefield_aol','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v33x\\v331\";}',1,1,'',1606579514,1606579514),('\\phpbb\\db\\migration\\data\\v33x\\v331','a:4:{i:0;s:53:\"\\phpbb\\db\\migration\\data\\v33x\\font_awesome_5_rollback\";i:1;s:43:\"\\phpbb\\db\\migration\\data\\v33x\\jquery_update\";i:2;s:35:\"\\phpbb\\db\\migration\\data\\v32x\\v3210\";i:3;s:37:\"\\phpbb\\db\\migration\\data\\v33x\\v331rc1\";}',1,1,'',1606579515,1606579515),('\\phpbb\\db\\migration\\data\\v33x\\v331rc1','a:8:{i:0;s:59:\"\\phpbb\\db\\migration\\data\\v33x\\add_notification_emails_table\";i:1;s:65:\"\\phpbb\\db\\migration\\data\\v33x\\fix_display_unapproved_posts_config\";i:2;s:40:\"\\phpbb\\db\\migration\\data\\v33x\\bot_update\";i:3;s:51:\"\\phpbb\\db\\migration\\data\\v33x\\font_awesome_5_update\";i:4;s:50:\"\\phpbb\\db\\migration\\data\\v33x\\profilefield_cleanup\";i:5;s:49:\"\\phpbb\\db\\migration\\data\\v33x\\google_recaptcha_v3\";i:6;s:57:\"\\phpbb\\db\\migration\\data\\v33x\\default_search_return_chars\";i:7;s:38:\"\\phpbb\\db\\migration\\data\\v32x\\v3210rc2\";}',1,1,'',1606579515,1606579515),('\\phpbb\\db\\migration\\data\\v33x\\v332','a:2:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v33x\\v332rc1\";i:1;s:35:\"\\phpbb\\db\\migration\\data\\v32x\\v3211\";}',1,1,'',1606579515,1606579515),('\\phpbb\\db\\migration\\data\\v33x\\v332rc1','a:1:{i:0;s:53:\"\\phpbb\\db\\migration\\data\\v33x\\remove_profilefield_aol\";}',1,1,'',1606579515,1606579515),('\\phpbb\\topicprefixes\\migrations\\install_module','a:1:{i:0;s:46:\"\\phpbb\\topicprefixes\\migrations\\install_schema\";}',1,1,'',1607737162,1607737163),('\\phpbb\\topicprefixes\\migrations\\install_schema','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v314\";}',1,1,'',1607737160,1607737161),('\\phpbb\\viglink\\migrations\\viglink_ask_admin','a:1:{i:0;s:41:\"\\phpbb\\viglink\\migrations\\viglink_data_v2\";}',1,1,'',1606579522,1606579522),('\\phpbb\\viglink\\migrations\\viglink_ask_admin_wait','a:1:{i:0;s:43:\"\\phpbb\\viglink\\migrations\\viglink_ask_admin\";}',1,1,'',1606579523,1606579523),('\\phpbb\\viglink\\migrations\\viglink_cron','a:1:{i:0;s:38:\"\\phpbb\\viglink\\migrations\\viglink_data\";}',1,1,'',0,0),('\\phpbb\\viglink\\migrations\\viglink_data','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v312\";}',1,1,'',1606579519,1606579521),('\\phpbb\\viglink\\migrations\\viglink_data_v2','a:1:{i:0;s:38:\"\\phpbb\\viglink\\migrations\\viglink_data\";}',1,1,'',1606579521,1606579522),('\\rmcgirr83\\genders\\migrations\\m1_initial_schema','a:1:{i:0;s:37:\"\\phpbb\\db\\migration\\data\\v31x\\v314rc1\";}',1,1,'',1606592173,1606592173),('\\rmcgirr83\\genders\\migrations\\m2_initial_data','a:1:{i:0;s:47:\"\\rmcgirr83\\genders\\migrations\\m1_initial_schema\";}',1,1,'',1606592173,1606592174),('\\rmcgirr83\\genders\\migrations\\m3_initial_data','a:1:{i:0;s:45:\"\\rmcgirr83\\genders\\migrations\\m2_initial_data\";}',1,1,'',1606592174,1606592174),('\\rxu\\firstpostoneverypage\\migrations\\v_3_0_0','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v320\\v320\";}',1,1,'',1606591077,1606591078),('\\rxu\\listsubforumsincolumns\\migrations\\v_2_0_0','a:1:{i:0;s:33:\"\\phpbb\\db\\migration\\data\\v310\\dev\";}',1,1,'',1606591162,1606591162),('\\senky\\akismet\\migrations\\v10x\\m1_acp_module','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v32x\\v321\";}',1,1,'',1606592927,1606592928),('\\senky\\akismet\\migrations\\v10x\\m2_configs','a:1:{i:0;s:44:\"\\senky\\akismet\\migrations\\v10x\\m1_acp_module\";}',1,1,'',1606592928,1606592929),('\\senky\\akismet\\migrations\\v10x\\m3_admin_form','a:1:{i:0;s:41:\"\\senky\\akismet\\migrations\\v10x\\m2_configs\";}',1,1,'',1606592929,1606592930),('\\stevotvr\\flair\\migrations\\version_1_0_0','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v314\";}',1,1,'',1606587930,1606587939),('\\stevotvr\\flair\\migrations\\version_1_1_0','a:1:{i:0;s:40:\"\\stevotvr\\flair\\migrations\\version_1_0_0\";}',1,1,'',1606587939,1606587940),('\\stevotvr\\flair\\migrations\\version_1_1_1','a:1:{i:0;s:40:\"\\stevotvr\\flair\\migrations\\version_1_0_0\";}',1,1,'',1606587940,1606587942),('\\stevotvr\\flair\\migrations\\version_1_2_0','a:1:{i:0;s:40:\"\\stevotvr\\flair\\migrations\\version_1_1_1\";}',1,1,'',1606587943,1606587949),('\\stevotvr\\flair\\migrations\\version_1_2_1','a:1:{i:0;s:40:\"\\stevotvr\\flair\\migrations\\version_1_2_0\";}',1,1,'',1606587949,1606587950),('\\vse\\abbc3\\migrations\\disable_bbcodes','a:0:{}',1,1,'',0,0),('\\vse\\abbc3\\migrations\\v310_m1_remove_data','a:1:{i:0;s:35:\"\\phpbb\\db\\migration\\data\\v310\\beta4\";}',1,1,'',0,0),('\\vse\\abbc3\\migrations\\v310_m2_remove_schema','a:1:{i:0;s:41:\"\\vse\\abbc3\\migrations\\v310_m1_remove_data\";}',1,1,'',0,0),('\\vse\\abbc3\\migrations\\v310_m3_install_schema','a:1:{i:0;s:43:\"\\vse\\abbc3\\migrations\\v310_m2_remove_schema\";}',1,1,'',1606582147,1606582148),('\\vse\\abbc3\\migrations\\v310_m4_install_data','a:1:{i:0;s:44:\"\\vse\\abbc3\\migrations\\v310_m3_install_schema\";}',1,1,'',1606582148,1606582151),('\\vse\\abbc3\\migrations\\v310_m5_update_bbcodes','a:1:{i:0;s:42:\"\\vse\\abbc3\\migrations\\v310_m4_install_data\";}',1,1,'',1606582151,1606582152),('\\vse\\abbc3\\migrations\\v310_m6_update_bbcodes','a:1:{i:0;s:44:\"\\vse\\abbc3\\migrations\\v310_m5_update_bbcodes\";}',1,1,'',1606582152,1606582152),('\\vse\\abbc3\\migrations\\v310_m7_update_bbcodes','a:1:{i:0;s:44:\"\\vse\\abbc3\\migrations\\v310_m5_update_bbcodes\";}',1,1,'',1606582152,1606582153),('\\vse\\abbc3\\migrations\\v322_m10_merge_duplicate_bbcodes','a:6:{i:0;s:42:\"\\vse\\abbc3\\migrations\\v310_m4_install_data\";i:1;s:44:\"\\vse\\abbc3\\migrations\\v310_m5_update_bbcodes\";i:2;s:44:\"\\vse\\abbc3\\migrations\\v310_m6_update_bbcodes\";i:3;s:44:\"\\vse\\abbc3\\migrations\\v310_m7_update_bbcodes\";i:4;s:44:\"\\vse\\abbc3\\migrations\\v322_m8_update_bbcodes\";i:5;s:44:\"\\vse\\abbc3\\migrations\\v322_m9_delete_bbcodes\";}',1,1,'',1606582154,1606582154),('\\vse\\abbc3\\migrations\\v322_m11_reparse','a:8:{i:0;s:43:\"\\phpbb\\db\\migration\\data\\v320\\text_reparser\";i:1;s:42:\"\\vse\\abbc3\\migrations\\v310_m4_install_data\";i:2;s:44:\"\\vse\\abbc3\\migrations\\v310_m5_update_bbcodes\";i:3;s:44:\"\\vse\\abbc3\\migrations\\v310_m6_update_bbcodes\";i:4;s:44:\"\\vse\\abbc3\\migrations\\v310_m7_update_bbcodes\";i:5;s:44:\"\\vse\\abbc3\\migrations\\v322_m8_update_bbcodes\";i:6;s:44:\"\\vse\\abbc3\\migrations\\v322_m9_delete_bbcodes\";i:7;s:54:\"\\vse\\abbc3\\migrations\\v322_m10_merge_duplicate_bbcodes\";}',1,1,'',1606582154,1606582156),('\\vse\\abbc3\\migrations\\v322_m8_update_bbcodes','a:1:{i:0;s:42:\"\\vse\\abbc3\\migrations\\v310_m4_install_data\";}',1,1,'',1606582153,1606582153),('\\vse\\abbc3\\migrations\\v322_m9_delete_bbcodes','a:1:{i:0;s:42:\"\\vse\\abbc3\\migrations\\v310_m4_install_data\";}',1,1,'',1606582153,1606582154),('\\vse\\abbc3\\migrations\\v323_m12_table_bbcode','a:2:{i:0;s:42:\"\\vse\\abbc3\\migrations\\v310_m4_install_data\";i:1;s:38:\"\\vse\\abbc3\\migrations\\v322_m11_reparse\";}',1,1,'',1606582156,1606582156),('\\vse\\abbc3\\migrations\\v330_m13_acp','a:6:{i:0;s:41:\"\\vse\\abbc3\\migrations\\v310_m1_remove_data\";i:1;s:43:\"\\vse\\abbc3\\migrations\\v310_m2_remove_schema\";i:2;s:44:\"\\vse\\abbc3\\migrations\\v310_m3_install_schema\";i:3;s:42:\"\\vse\\abbc3\\migrations\\v310_m4_install_data\";i:4;s:38:\"\\vse\\abbc3\\migrations\\v322_m11_reparse\";i:5;s:43:\"\\vse\\abbc3\\migrations\\v323_m12_table_bbcode\";}',1,1,'',1606582157,1606582161),('\\vse\\topicpreview\\migrations\\v1xx\\release_1_0_6_data','a:1:{i:0;s:54:\"\\vse\\topicpreview\\migrations\\v1xx\\release_1_0_6_schema\";}',1,1,'',1606591901,1606591902),('\\vse\\topicpreview\\migrations\\v1xx\\release_1_0_6_schema','a:1:{i:0;s:34:\"\\phpbb\\db\\migration\\data\\v31x\\v312\";}',1,1,'',1606591900,1606591901),('\\vse\\topicpreview\\migrations\\v2xx\\release_2_0_0','a:1:{i:0;s:52:\"\\vse\\topicpreview\\migrations\\v1xx\\release_1_0_6_data\";}',1,1,'',1606591902,1606591904),('\\vse\\topicpreview\\migrations\\v2xx\\release_2_1_0_data','a:1:{i:0;s:54:\"\\vse\\topicpreview\\migrations\\v2xx\\release_2_1_0_schema\";}',1,1,'',1606591904,1606591907),('\\vse\\topicpreview\\migrations\\v2xx\\release_2_1_0_schema','a:1:{i:0;s:47:\"\\vse\\topicpreview\\migrations\\v2xx\\release_2_0_0\";}',1,1,'',1606591904,1606591904),('\\vse\\topicpreview\\migrations\\v2xx\\release_2_1_1_data','a:1:{i:0;s:52:\"\\vse\\topicpreview\\migrations\\v2xx\\release_2_1_0_data\";}',1,1,'',1606591907,1606591908);
/*!40000 ALTER TABLE `phpbb_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_moderator_cache`
--

DROP TABLE IF EXISTS `phpbb_moderator_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_moderator_cache` (
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `username` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `group_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_on_index` tinyint(1) unsigned NOT NULL DEFAULT 1,
  KEY `disp_idx` (`display_on_index`),
  KEY `forum_id` (`forum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_moderator_cache`
--

LOCK TABLES `phpbb_moderator_cache` WRITE;
/*!40000 ALTER TABLE `phpbb_moderator_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_moderator_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_modules`
--

DROP TABLE IF EXISTS `phpbb_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_modules` (
  `module_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module_enabled` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `module_display` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `module_basename` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `module_class` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT '',
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `left_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `right_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `module_langname` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `module_mode` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `module_auth` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`module_id`),
  KEY `left_right_id` (`left_id`,`right_id`),
  KEY `module_enabled` (`module_enabled`),
  KEY `class_left_id` (`module_class`,`left_id`)
) ENGINE=InnoDB AUTO_INCREMENT=260 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_modules`
--

LOCK TABLES `phpbb_modules` WRITE;
/*!40000 ALTER TABLE `phpbb_modules` DISABLE KEYS */;
INSERT INTO `phpbb_modules` VALUES (1,1,1,'','acp',0,1,70,'ACP_CAT_GENERAL','',''),(2,1,1,'','acp',1,4,17,'ACP_QUICK_ACCESS','',''),(3,1,1,'','acp',1,18,47,'ACP_BOARD_CONFIGURATION','',''),(4,1,1,'','acp',1,48,55,'ACP_CLIENT_COMMUNICATION','',''),(5,1,1,'','acp',1,56,69,'ACP_SERVER_CONFIGURATION','',''),(6,1,1,'','acp',0,71,90,'ACP_CAT_FORUMS','',''),(7,1,1,'','acp',6,72,77,'ACP_MANAGE_FORUMS','',''),(8,1,1,'','acp',6,78,89,'ACP_FORUM_BASED_PERMISSIONS','',''),(9,1,1,'','acp',0,91,118,'ACP_CAT_POSTING','',''),(10,1,1,'','acp',9,92,105,'ACP_MESSAGES','',''),(11,1,1,'','acp',9,106,117,'ACP_ATTACHMENTS','',''),(12,1,1,'','acp',0,119,176,'ACP_CAT_USERGROUP','',''),(13,1,1,'','acp',12,120,155,'ACP_CAT_USERS','',''),(14,1,1,'','acp',12,156,165,'ACP_GROUPS','',''),(15,1,1,'','acp',12,166,175,'ACP_USER_SECURITY','',''),(16,1,1,'','acp',0,177,226,'ACP_CAT_PERMISSIONS','',''),(17,1,1,'','acp',16,180,189,'ACP_GLOBAL_PERMISSIONS','',''),(18,1,1,'','acp',16,190,201,'ACP_FORUM_BASED_PERMISSIONS','',''),(19,1,1,'','acp',16,202,211,'ACP_PERMISSION_ROLES','',''),(20,1,1,'','acp',16,212,225,'ACP_PERMISSION_MASKS','',''),(21,1,1,'','acp',0,227,242,'ACP_CAT_CUSTOMISE','',''),(22,1,1,'','acp',21,232,237,'ACP_STYLE_MANAGEMENT','',''),(23,1,1,'','acp',21,228,231,'ACP_EXTENSION_MANAGEMENT','',''),(24,1,1,'','acp',21,238,241,'ACP_LANGUAGE','',''),(25,1,1,'','acp',0,243,262,'ACP_CAT_MAINTENANCE','',''),(26,1,1,'','acp',25,244,253,'ACP_FORUM_LOGS','',''),(27,1,1,'','acp',25,254,261,'ACP_CAT_DATABASE','',''),(28,1,1,'','acp',0,263,286,'ACP_CAT_SYSTEM','',''),(29,1,1,'','acp',28,264,267,'ACP_AUTOMATION','',''),(30,1,1,'','acp',28,268,277,'ACP_GENERAL_TASKS','',''),(31,1,1,'','acp',28,278,285,'ACP_MODULE_MANAGEMENT','',''),(32,1,1,'','acp',0,287,342,'ACP_CAT_DOT_MODS','',''),(33,1,1,'acp_attachments','acp',3,19,20,'ACP_ATTACHMENT_SETTINGS','attach','acl_a_attach'),(34,1,1,'acp_attachments','acp',11,107,108,'ACP_ATTACHMENT_SETTINGS','attach','acl_a_attach'),(35,1,1,'acp_attachments','acp',11,109,110,'ACP_MANAGE_EXTENSIONS','extensions','acl_a_attach'),(36,1,1,'acp_attachments','acp',11,111,112,'ACP_EXTENSION_GROUPS','ext_groups','acl_a_attach'),(37,1,1,'acp_attachments','acp',11,113,114,'ACP_ORPHAN_ATTACHMENTS','orphan','acl_a_attach'),(38,1,1,'acp_attachments','acp',11,115,116,'ACP_MANAGE_ATTACHMENTS','manage','acl_a_attach'),(39,1,1,'acp_ban','acp',15,167,168,'ACP_BAN_EMAILS','email','acl_a_ban'),(40,1,1,'acp_ban','acp',15,169,170,'ACP_BAN_IPS','ip','acl_a_ban'),(41,1,1,'acp_ban','acp',15,171,172,'ACP_BAN_USERNAMES','user','acl_a_ban'),(42,1,1,'acp_bbcodes','acp',10,93,94,'ACP_BBCODES','bbcodes','acl_a_bbcode'),(43,1,1,'acp_board','acp',3,21,22,'ACP_BOARD_SETTINGS','settings','acl_a_board'),(44,1,1,'acp_board','acp',3,23,24,'ACP_BOARD_FEATURES','features','acl_a_board'),(45,1,1,'acp_board','acp',3,25,26,'ACP_AVATAR_SETTINGS','avatar','acl_a_board'),(46,1,1,'acp_board','acp',3,27,28,'ACP_MESSAGE_SETTINGS','message','acl_a_board'),(47,1,1,'acp_board','acp',10,95,96,'ACP_MESSAGE_SETTINGS','message','acl_a_board'),(48,1,1,'acp_board','acp',3,29,30,'ACP_POST_SETTINGS','post','acl_a_board'),(49,1,1,'acp_board','acp',10,97,98,'ACP_POST_SETTINGS','post','acl_a_board'),(50,1,1,'acp_board','acp',3,31,32,'ACP_SIGNATURE_SETTINGS','signature','acl_a_board'),(51,1,1,'acp_board','acp',3,33,34,'ACP_FEED_SETTINGS','feed','acl_a_board'),(52,1,1,'acp_board','acp',3,35,36,'ACP_REGISTER_SETTINGS','registration','acl_a_board'),(53,1,1,'acp_board','acp',4,49,50,'ACP_AUTH_SETTINGS','auth','acl_a_server'),(54,1,1,'acp_board','acp',4,51,52,'ACP_EMAIL_SETTINGS','email','acl_a_server'),(55,1,1,'acp_board','acp',5,57,58,'ACP_COOKIE_SETTINGS','cookie','acl_a_server'),(56,1,1,'acp_board','acp',5,59,60,'ACP_SERVER_SETTINGS','server','acl_a_server'),(57,1,1,'acp_board','acp',5,61,62,'ACP_SECURITY_SETTINGS','security','acl_a_server'),(58,1,1,'acp_board','acp',5,63,64,'ACP_LOAD_SETTINGS','load','acl_a_server'),(59,1,1,'acp_bots','acp',30,269,270,'ACP_BOTS','bots','acl_a_bots'),(60,1,1,'acp_captcha','acp',3,37,38,'ACP_VC_SETTINGS','visual','acl_a_board'),(61,1,0,'acp_captcha','acp',3,39,40,'ACP_VC_CAPTCHA_DISPLAY','img','acl_a_board'),(62,1,1,'acp_contact','acp',3,41,42,'ACP_CONTACT_SETTINGS','contact','acl_a_board'),(63,1,1,'acp_database','acp',27,255,256,'ACP_BACKUP','backup','acl_a_backup'),(64,1,1,'acp_database','acp',27,257,258,'ACP_RESTORE','restore','acl_a_backup'),(65,1,1,'acp_disallow','acp',15,173,174,'ACP_DISALLOW_USERNAMES','usernames','acl_a_names'),(66,1,1,'acp_email','acp',30,271,272,'ACP_MASS_EMAIL','email','acl_a_email && cfg_email_enable'),(67,1,1,'acp_extensions','acp',23,229,230,'ACP_EXTENSIONS','main','acl_a_extensions'),(68,1,1,'acp_forums','acp',7,73,74,'ACP_MANAGE_FORUMS','manage','acl_a_forum'),(69,1,1,'acp_groups','acp',14,157,158,'ACP_GROUPS_MANAGE','manage','acl_a_group'),(70,1,1,'acp_groups','acp',14,159,160,'ACP_GROUPS_POSITION','position','acl_a_group'),(71,1,1,'acp_help_phpbb','acp',5,65,66,'ACP_HELP_PHPBB','help_phpbb','acl_a_server'),(72,1,1,'acp_icons','acp',10,99,100,'ACP_ICONS','icons','acl_a_icons'),(73,1,1,'acp_icons','acp',10,101,102,'ACP_SMILIES','smilies','acl_a_icons'),(74,1,1,'acp_inactive','acp',13,121,122,'ACP_INACTIVE_USERS','list','acl_a_user'),(75,1,1,'acp_jabber','acp',4,53,54,'ACP_JABBER_SETTINGS','settings','acl_a_jabber'),(76,1,1,'acp_language','acp',24,239,240,'ACP_LANGUAGE_PACKS','lang_packs','acl_a_language'),(77,1,1,'acp_logs','acp',26,245,246,'ACP_ADMIN_LOGS','admin','acl_a_viewlogs'),(78,1,1,'acp_logs','acp',26,247,248,'ACP_MOD_LOGS','mod','acl_a_viewlogs'),(79,1,1,'acp_logs','acp',26,249,250,'ACP_USERS_LOGS','users','acl_a_viewlogs'),(80,1,1,'acp_logs','acp',26,251,252,'ACP_CRITICAL_LOGS','critical','acl_a_viewlogs'),(81,1,1,'acp_main','acp',1,2,3,'ACP_INDEX','main',''),(82,1,1,'acp_modules','acp',31,279,280,'ACP','acp','acl_a_modules'),(83,1,1,'acp_modules','acp',31,281,282,'UCP','ucp','acl_a_modules'),(84,1,1,'acp_modules','acp',31,283,284,'MCP','mcp','acl_a_modules'),(85,1,1,'acp_permission_roles','acp',19,203,204,'ACP_ADMIN_ROLES','admin_roles','acl_a_roles && acl_a_aauth'),(86,1,1,'acp_permission_roles','acp',19,205,206,'ACP_USER_ROLES','user_roles','acl_a_roles && acl_a_uauth'),(87,1,1,'acp_permission_roles','acp',19,207,208,'ACP_MOD_ROLES','mod_roles','acl_a_roles && acl_a_mauth'),(88,1,1,'acp_permission_roles','acp',19,209,210,'ACP_FORUM_ROLES','forum_roles','acl_a_roles && acl_a_fauth'),(89,1,1,'acp_permissions','acp',16,178,179,'ACP_PERMISSIONS','intro','acl_a_authusers || acl_a_authgroups || acl_a_viewauth'),(90,1,0,'acp_permissions','acp',20,213,214,'ACP_PERMISSION_TRACE','trace','acl_a_viewauth'),(91,1,1,'acp_permissions','acp',18,191,192,'ACP_FORUM_PERMISSIONS','setting_forum_local','acl_a_fauth && (acl_a_authusers || acl_a_authgroups)'),(92,1,1,'acp_permissions','acp',18,193,194,'ACP_FORUM_PERMISSIONS_COPY','setting_forum_copy','acl_a_fauth && acl_a_authusers && acl_a_authgroups && acl_a_mauth'),(93,1,1,'acp_permissions','acp',18,195,196,'ACP_FORUM_MODERATORS','setting_mod_local','acl_a_mauth && (acl_a_authusers || acl_a_authgroups)'),(94,1,1,'acp_permissions','acp',17,181,182,'ACP_USERS_PERMISSIONS','setting_user_global','acl_a_authusers && (acl_a_aauth || acl_a_mauth || acl_a_uauth)'),(95,1,1,'acp_permissions','acp',13,125,126,'ACP_USERS_PERMISSIONS','setting_user_global','acl_a_authusers && (acl_a_aauth || acl_a_mauth || acl_a_uauth)'),(96,1,1,'acp_permissions','acp',18,197,198,'ACP_USERS_FORUM_PERMISSIONS','setting_user_local','acl_a_authusers && (acl_a_mauth || acl_a_fauth)'),(97,1,1,'acp_permissions','acp',13,127,128,'ACP_USERS_FORUM_PERMISSIONS','setting_user_local','acl_a_authusers && (acl_a_mauth || acl_a_fauth)'),(98,1,1,'acp_permissions','acp',17,183,184,'ACP_GROUPS_PERMISSIONS','setting_group_global','acl_a_authgroups && (acl_a_aauth || acl_a_mauth || acl_a_uauth)'),(99,1,1,'acp_permissions','acp',14,161,162,'ACP_GROUPS_PERMISSIONS','setting_group_global','acl_a_authgroups && (acl_a_aauth || acl_a_mauth || acl_a_uauth)'),(100,1,1,'acp_permissions','acp',18,199,200,'ACP_GROUPS_FORUM_PERMISSIONS','setting_group_local','acl_a_authgroups && (acl_a_mauth || acl_a_fauth)'),(101,1,1,'acp_permissions','acp',14,163,164,'ACP_GROUPS_FORUM_PERMISSIONS','setting_group_local','acl_a_authgroups && (acl_a_mauth || acl_a_fauth)'),(102,1,1,'acp_permissions','acp',17,185,186,'ACP_ADMINISTRATORS','setting_admin_global','acl_a_aauth && (acl_a_authusers || acl_a_authgroups)'),(103,1,1,'acp_permissions','acp',17,187,188,'ACP_GLOBAL_MODERATORS','setting_mod_global','acl_a_mauth && (acl_a_authusers || acl_a_authgroups)'),(104,1,1,'acp_permissions','acp',20,215,216,'ACP_VIEW_ADMIN_PERMISSIONS','view_admin_global','acl_a_viewauth'),(105,1,1,'acp_permissions','acp',20,217,218,'ACP_VIEW_USER_PERMISSIONS','view_user_global','acl_a_viewauth'),(106,1,1,'acp_permissions','acp',20,219,220,'ACP_VIEW_GLOBAL_MOD_PERMISSIONS','view_mod_global','acl_a_viewauth'),(107,1,1,'acp_permissions','acp',20,221,222,'ACP_VIEW_FORUM_MOD_PERMISSIONS','view_mod_local','acl_a_viewauth'),(108,1,1,'acp_permissions','acp',20,223,224,'ACP_VIEW_FORUM_PERMISSIONS','view_forum_local','acl_a_viewauth'),(109,1,1,'acp_php_info','acp',30,273,274,'ACP_PHP_INFO','info','acl_a_phpinfo'),(110,1,1,'acp_profile','acp',13,129,130,'ACP_CUSTOM_PROFILE_FIELDS','profile','acl_a_profile'),(111,1,1,'acp_prune','acp',7,75,76,'ACP_PRUNE_FORUMS','forums','acl_a_prune'),(112,1,1,'acp_prune','acp',13,131,132,'ACP_PRUNE_USERS','users','acl_a_userdel'),(113,1,1,'acp_ranks','acp',13,133,134,'ACP_MANAGE_RANKS','ranks','acl_a_ranks'),(114,1,1,'acp_reasons','acp',30,275,276,'ACP_MANAGE_REASONS','main','acl_a_reasons'),(115,1,1,'acp_search','acp',5,67,68,'ACP_SEARCH_SETTINGS','settings','acl_a_search'),(116,1,1,'acp_search','acp',27,259,260,'ACP_SEARCH_INDEX','index','acl_a_search'),(117,1,1,'acp_styles','acp',22,233,234,'ACP_STYLES','style','acl_a_styles'),(118,1,1,'acp_styles','acp',22,235,236,'ACP_STYLES_INSTALL','install','acl_a_styles'),(119,1,1,'acp_update','acp',29,265,266,'ACP_VERSION_CHECK','version_check','acl_a_board'),(120,1,1,'acp_users','acp',13,123,124,'ACP_MANAGE_USERS','overview','acl_a_user'),(121,1,0,'acp_users','acp',13,135,136,'ACP_USER_FEEDBACK','feedback','acl_a_user'),(122,1,0,'acp_users','acp',13,137,138,'ACP_USER_WARNINGS','warnings','acl_a_user'),(123,1,0,'acp_users','acp',13,139,140,'ACP_USER_PROFILE','profile','acl_a_user'),(124,1,0,'acp_users','acp',13,141,142,'ACP_USER_PREFS','prefs','acl_a_user'),(125,1,0,'acp_users','acp',13,143,144,'ACP_USER_AVATAR','avatar','acl_a_user'),(126,1,0,'acp_users','acp',13,145,146,'ACP_USER_RANK','rank','acl_a_user'),(127,1,0,'acp_users','acp',13,147,148,'ACP_USER_SIG','sig','acl_a_user'),(128,1,0,'acp_users','acp',13,149,150,'ACP_USER_GROUPS','groups','acl_a_user && acl_a_group'),(129,1,0,'acp_users','acp',13,151,152,'ACP_USER_PERM','perm','acl_a_user && acl_a_viewauth'),(130,1,0,'acp_users','acp',13,153,154,'ACP_USER_ATTACH','attach','acl_a_user'),(131,1,1,'acp_words','acp',10,103,104,'ACP_WORDS','words','acl_a_words'),(132,1,1,'acp_users','acp',2,5,6,'ACP_MANAGE_USERS','overview','acl_a_user'),(133,1,1,'acp_groups','acp',2,7,8,'ACP_GROUPS_MANAGE','manage','acl_a_group'),(134,1,1,'acp_forums','acp',2,9,10,'ACP_MANAGE_FORUMS','manage','acl_a_forum'),(135,1,1,'acp_logs','acp',2,11,12,'ACP_MOD_LOGS','mod','acl_a_viewlogs'),(136,1,1,'acp_bots','acp',2,13,14,'ACP_BOTS','bots','acl_a_bots'),(137,1,1,'acp_php_info','acp',2,15,16,'ACP_PHP_INFO','info','acl_a_phpinfo'),(138,1,1,'acp_permissions','acp',8,79,80,'ACP_FORUM_PERMISSIONS','setting_forum_local','acl_a_fauth && (acl_a_authusers || acl_a_authgroups)'),(139,1,1,'acp_permissions','acp',8,81,82,'ACP_FORUM_PERMISSIONS_COPY','setting_forum_copy','acl_a_fauth && acl_a_authusers && acl_a_authgroups && acl_a_mauth'),(140,1,1,'acp_permissions','acp',8,83,84,'ACP_FORUM_MODERATORS','setting_mod_local','acl_a_mauth && (acl_a_authusers || acl_a_authgroups)'),(141,1,1,'acp_permissions','acp',8,85,86,'ACP_USERS_FORUM_PERMISSIONS','setting_user_local','acl_a_authusers && (acl_a_mauth || acl_a_fauth)'),(142,1,1,'acp_permissions','acp',8,87,88,'ACP_GROUPS_FORUM_PERMISSIONS','setting_group_local','acl_a_authgroups && (acl_a_mauth || acl_a_fauth)'),(143,1,1,'','mcp',0,1,10,'MCP_MAIN','',''),(144,1,1,'','mcp',0,11,22,'MCP_QUEUE','',''),(145,1,1,'','mcp',0,23,36,'MCP_REPORTS','',''),(146,1,1,'','mcp',0,37,42,'MCP_NOTES','',''),(147,1,1,'','mcp',0,43,52,'MCP_WARN','',''),(148,1,1,'','mcp',0,53,60,'MCP_LOGS','',''),(149,1,1,'','mcp',0,61,68,'MCP_BAN','',''),(150,1,1,'mcp_ban','mcp',149,62,63,'MCP_BAN_USERNAMES','user','acl_m_ban'),(151,1,1,'mcp_ban','mcp',149,64,65,'MCP_BAN_IPS','ip','acl_m_ban'),(152,1,1,'mcp_ban','mcp',149,66,67,'MCP_BAN_EMAILS','email','acl_m_ban'),(153,1,1,'mcp_logs','mcp',148,54,55,'MCP_LOGS_FRONT','front','acl_m_ || aclf_m_'),(154,1,1,'mcp_logs','mcp',148,56,57,'MCP_LOGS_FORUM_VIEW','forum_logs','acl_m_,$id'),(155,1,1,'mcp_logs','mcp',148,58,59,'MCP_LOGS_TOPIC_VIEW','topic_logs','acl_m_,$id'),(156,1,1,'mcp_main','mcp',143,2,3,'MCP_MAIN_FRONT','front',''),(157,1,1,'mcp_main','mcp',143,4,5,'MCP_MAIN_FORUM_VIEW','forum_view','acl_m_,$id'),(158,1,1,'mcp_main','mcp',143,6,7,'MCP_MAIN_TOPIC_VIEW','topic_view','acl_m_,$id'),(159,1,1,'mcp_main','mcp',143,8,9,'MCP_MAIN_POST_DETAILS','post_details','acl_m_,$id || (!$id && aclf_m_)'),(160,1,1,'mcp_notes','mcp',146,38,39,'MCP_NOTES_FRONT','front',''),(161,1,1,'mcp_notes','mcp',146,40,41,'MCP_NOTES_USER','user_notes',''),(162,1,1,'mcp_pm_reports','mcp',145,30,31,'MCP_PM_REPORTS_OPEN','pm_reports','acl_m_pm_report'),(163,1,1,'mcp_pm_reports','mcp',145,32,33,'MCP_PM_REPORTS_CLOSED','pm_reports_closed','acl_m_pm_report'),(164,1,1,'mcp_pm_reports','mcp',145,34,35,'MCP_PM_REPORT_DETAILS','pm_report_details','acl_m_pm_report'),(165,1,1,'mcp_queue','mcp',144,12,13,'MCP_QUEUE_UNAPPROVED_TOPICS','unapproved_topics','aclf_m_approve'),(166,1,1,'mcp_queue','mcp',144,14,15,'MCP_QUEUE_UNAPPROVED_POSTS','unapproved_posts','aclf_m_approve'),(167,1,1,'mcp_queue','mcp',144,16,17,'MCP_QUEUE_DELETED_TOPICS','deleted_topics','aclf_m_approve'),(168,1,1,'mcp_queue','mcp',144,18,19,'MCP_QUEUE_DELETED_POSTS','deleted_posts','aclf_m_approve'),(169,1,1,'mcp_queue','mcp',144,20,21,'MCP_QUEUE_APPROVE_DETAILS','approve_details','acl_m_approve,$id || (!$id && aclf_m_approve)'),(170,1,1,'mcp_reports','mcp',145,24,25,'MCP_REPORTS_OPEN','reports','aclf_m_report'),(171,1,1,'mcp_reports','mcp',145,26,27,'MCP_REPORTS_CLOSED','reports_closed','aclf_m_report'),(172,1,1,'mcp_reports','mcp',145,28,29,'MCP_REPORT_DETAILS','report_details','acl_m_report,$id || (!$id && aclf_m_report)'),(173,1,1,'mcp_warn','mcp',147,44,45,'MCP_WARN_FRONT','front','aclf_m_warn'),(174,1,1,'mcp_warn','mcp',147,46,47,'MCP_WARN_LIST','list','aclf_m_warn'),(175,1,1,'mcp_warn','mcp',147,48,49,'MCP_WARN_USER','warn_user','aclf_m_warn'),(176,1,1,'mcp_warn','mcp',147,50,51,'MCP_WARN_POST','warn_post','acl_m_warn && acl_f_read,$id'),(177,1,1,'','ucp',0,1,14,'UCP_MAIN','',''),(178,1,1,'','ucp',0,15,30,'UCP_PROFILE','',''),(179,1,1,'','ucp',0,31,40,'UCP_PREFS','',''),(180,1,1,'ucp_pm','ucp',0,41,50,'UCP_PM','',''),(181,1,1,'','ucp',0,51,56,'UCP_USERGROUPS','',''),(182,1,1,'','ucp',0,57,62,'UCP_ZEBRA','',''),(183,1,1,'ucp_attachments','ucp',177,10,11,'UCP_MAIN_ATTACHMENTS','attachments','acl_u_attach'),(184,1,1,'ucp_auth_link','ucp',178,26,27,'UCP_AUTH_LINK_MANAGE','auth_link','authmethod_oauth'),(185,1,1,'ucp_groups','ucp',181,52,53,'UCP_USERGROUPS_MEMBER','membership',''),(186,1,1,'ucp_groups','ucp',181,54,55,'UCP_USERGROUPS_MANAGE','manage',''),(187,1,1,'ucp_main','ucp',177,2,3,'UCP_MAIN_FRONT','front',''),(188,1,1,'ucp_main','ucp',177,4,5,'UCP_MAIN_SUBSCRIBED','subscribed',''),(189,1,1,'ucp_main','ucp',177,6,7,'UCP_MAIN_BOOKMARKS','bookmarks','cfg_allow_bookmarks'),(190,1,1,'ucp_main','ucp',177,8,9,'UCP_MAIN_DRAFTS','drafts',''),(191,1,1,'ucp_notifications','ucp',179,38,39,'UCP_NOTIFICATION_OPTIONS','notification_options',''),(192,1,1,'ucp_notifications','ucp',177,12,13,'UCP_NOTIFICATION_LIST','notification_list','cfg_allow_board_notifications'),(193,1,0,'ucp_pm','ucp',180,42,43,'UCP_PM_VIEW','view','cfg_allow_privmsg'),(194,1,1,'ucp_pm','ucp',180,44,45,'UCP_PM_COMPOSE','compose','cfg_allow_privmsg'),(195,1,1,'ucp_pm','ucp',180,46,47,'UCP_PM_DRAFTS','drafts','cfg_allow_privmsg'),(196,1,1,'ucp_pm','ucp',180,48,49,'UCP_PM_OPTIONS','options','cfg_allow_privmsg'),(197,1,1,'ucp_prefs','ucp',179,32,33,'UCP_PREFS_PERSONAL','personal',''),(198,1,1,'ucp_prefs','ucp',179,34,35,'UCP_PREFS_POST','post',''),(199,1,1,'ucp_prefs','ucp',179,36,37,'UCP_PREFS_VIEW','view',''),(200,1,1,'ucp_profile','ucp',178,16,17,'UCP_PROFILE_PROFILE_INFO','profile_info','acl_u_chgprofileinfo'),(201,1,1,'ucp_profile','ucp',178,18,19,'UCP_PROFILE_SIGNATURE','signature','acl_u_sig'),(202,1,1,'ucp_profile','ucp',178,20,21,'UCP_PROFILE_AVATAR','avatar','cfg_allow_avatar'),(203,1,1,'ucp_profile','ucp',178,22,23,'UCP_PROFILE_REG_DETAILS','reg_details',''),(204,1,1,'ucp_profile','ucp',178,24,25,'UCP_PROFILE_AUTOLOGIN_KEYS','autologin_keys',''),(205,1,1,'ucp_zebra','ucp',182,58,59,'UCP_ZEBRA_FRIENDS','friends',''),(206,1,1,'ucp_zebra','ucp',182,60,61,'UCP_ZEBRA_FOES','foes',''),(207,1,1,'\\phpbb\\viglink\\acp\\viglink_module','acp',3,43,44,'ACP_VIGLINK_SETTINGS','settings','ext_phpbb/viglink && acl_a_board'),(208,1,1,'','acp',32,288,293,'ACP_ABBC3_MODULE','',''),(209,1,1,'\\vse\\abbc3\\acp\\abbc3_module','acp',208,289,290,'ACP_ABBC3_SETTINGS','settings','ext_vse/abbc3 && acl_a_board'),(210,1,1,'acp_bbcodes','acp',208,291,292,'ACP_BBCODES','bbcodes','ext_vse/abbc3 && acl_a_bbcode'),(211,1,1,'','acp',32,294,301,'ACP_FLAIR_TITLE','',''),(212,1,1,'\\stevotvr\\flair\\acp\\main_module','acp',211,295,296,'ACP_FLAIR_SETTINGS','settings','ext_stevotvr/flair && acl_a_board'),(213,1,1,'\\stevotvr\\flair\\acp\\main_module','acp',211,297,298,'ACP_FLAIR_MANAGE','manage','ext_stevotvr/flair && acl_a_board'),(215,1,1,'\\stevotvr\\flair\\acp\\main_module','acp',211,299,300,'ACP_FLAIR_IMAGES','images','ext_stevotvr/flair && acl_a_board'),(216,1,1,'','mcp',0,69,74,'MCP_FLAIR','',''),(219,1,1,'\\stevotvr\\flair\\ucp\\flair_module','ucp',178,28,29,'UCP_FLAIR','main','ext_stevotvr/flair && acl_u_flair'),(220,1,1,'\\stevotvr\\flair\\mcp\\user_module','mcp',216,70,71,'MCP_FLAIR_FRONT','front','ext_stevotvr/flair && (acl_m_userflair || acl_a_board)'),(221,1,1,'\\stevotvr\\flair\\mcp\\user_module','mcp',216,72,73,'MCP_FLAIR_USER','user_flair','ext_stevotvr/flair && (acl_m_userflair || acl_a_board)'),(222,1,1,'','acp',32,302,317,'ACP_MAS_TITLE','',''),(223,1,1,'\\dark1\\memberavatarstatus\\acp\\main_module','acp',222,303,304,'ACP_MAS_MODE_MAIN','main','ext_dark1/memberavatarstatus && acl_a_board'),(229,1,1,'\\dark1\\memberavatarstatus\\acp\\general_module','acp',222,305,306,'ACP_MAS_MODE_GENERAL','general','ext_dark1/memberavatarstatus && acl_a_board'),(230,1,1,'\\dark1\\memberavatarstatus\\acp\\memberlist_module','acp',222,307,308,'ACP_MAS_MODE_MEMBERLIST','memberlist','ext_dark1/memberavatarstatus && acl_a_board'),(231,1,1,'\\dark1\\memberavatarstatus\\acp\\viewonline_module','acp',222,309,310,'ACP_MAS_MODE_VIEWONLINE','viewonline','ext_dark1/memberavatarstatus && acl_a_board'),(232,1,1,'\\dark1\\memberavatarstatus\\acp\\viewforum_module','acp',222,311,312,'ACP_MAS_MODE_VIEWFORUM','viewforum','ext_dark1/memberavatarstatus && acl_a_board'),(233,1,1,'\\dark1\\memberavatarstatus\\acp\\search_module','acp',222,313,314,'ACP_MAS_MODE_SEARCH','search','ext_dark1/memberavatarstatus && acl_a_board'),(234,1,1,'\\dark1\\memberavatarstatus\\acp\\review_module','acp',222,315,316,'ACP_MAS_MODE_REVIEW','review','ext_dark1/memberavatarstatus && acl_a_board'),(235,1,1,'','acp',32,318,321,'TOPIC_PREVIEW','',''),(237,1,1,'\\vse\\topicpreview\\acp\\topic_preview_module','acp',235,319,320,'TOPIC_PREVIEW_SETTINGS','settings','ext_vse/topicpreview && acl_a_board'),(238,1,1,'','acp',32,322,325,'ACP_AKISMET_TITLE','',''),(239,1,1,'\\senky\\akismet\\acp\\akismet_module','acp',238,323,324,'ACP_AKISMET_SETTINGS','settings','ext_senky/akismet && acl_a_board'),(240,1,1,'','ucp',0,63,66,'DELETE_MY_ACCOUNT','',''),(241,1,1,'\\brokencrust\\deletemyaccount\\ucp\\main_module','ucp',240,64,65,'DELETE_YOUR_ACCOUNT','settings','ext_brokencrust/deletemyaccount'),(242,1,1,'','acp',32,326,331,'ACP_CAT_MCHAT','',''),(243,1,1,'\\dmzx\\mchat\\acp\\acp_mchat_module','acp',242,327,328,'ACP_MCHAT_GLOBALSETTINGS','globalsettings','ext_dmzx/mchat && acl_a_mchat'),(244,1,1,'\\dmzx\\mchat\\acp\\acp_mchat_module','acp',242,329,330,'ACP_MCHAT_GLOBALUSERSETTINGS','globalusersettings','ext_dmzx/mchat && acl_a_mchat'),(245,1,1,'','ucp',0,67,70,'UCP_MCHAT_CONFIG','',''),(246,1,1,'\\dmzx\\mchat\\ucp\\ucp_mchat_module','ucp',245,68,69,'UCP_MCHAT_CONFIG','configuration','ext_dmzx/mchat && acl_u_mchat_view'),(247,1,1,'\\apwa\\pmwelcome\\acp\\pmwelcome_module','acp',3,45,46,'ACP_PMWELCOME','settings','ext_apwa/pmwelcome && acl_a_board'),(253,1,1,'','ucp',0,71,72,'UCP_SITEMAKER_CONTENT','',''),(254,1,1,'','mcp',0,75,76,'MCP_SITEMAKER_CONTENT','',''),(255,1,1,'','acp',32,332,337,'ACP_SITEMAKER','',''),(256,1,1,'\\blitze\\sitemaker\\acp\\menu_module','acp',255,333,334,'ACP_MENU','menu','ext_blitze/sitemaker && acl_a_sm_manage_menus'),(257,1,1,'\\blitze\\sitemaker\\acp\\settings_module','acp',255,335,336,'ACP_SM_SETTINGS','settings','ext_blitze/sitemaker && acl_a_sm_settings'),(258,1,1,'','acp',32,338,341,'ACP_TOPIC_PREFIXES','',''),(259,1,1,'\\phpbb\\topicprefixes\\acp\\topic_prefixes_module','acp',258,339,340,'ACP_MANAGE_PREFIXES','manage','ext_phpbb/topicprefixes && acl_a_board');
/*!40000 ALTER TABLE `phpbb_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_notification_emails`
--

DROP TABLE IF EXISTS `phpbb_notification_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_notification_emails` (
  `notification_type_id` smallint(4) unsigned NOT NULL DEFAULT 0,
  `item_id` int(10) unsigned NOT NULL DEFAULT 0,
  `item_parent_id` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`notification_type_id`,`item_id`,`item_parent_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_notification_emails`
--

LOCK TABLES `phpbb_notification_emails` WRITE;
/*!40000 ALTER TABLE `phpbb_notification_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_notification_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_notification_types`
--

DROP TABLE IF EXISTS `phpbb_notification_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_notification_types` (
  `notification_type_id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `notification_type_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `notification_type_enabled` tinyint(1) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`notification_type_id`),
  UNIQUE KEY `type` (`notification_type_name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_notification_types`
--

LOCK TABLES `phpbb_notification_types` WRITE;
/*!40000 ALTER TABLE `phpbb_notification_types` DISABLE KEYS */;
INSERT INTO `phpbb_notification_types` VALUES (1,'notification.type.topic',1),(2,'notification.type.approve_topic',1),(3,'notification.type.quote',1),(4,'notification.type.bookmark',1),(5,'notification.type.post',1),(6,'notification.type.approve_post',1),(7,'notification.type.forum',1),(8,'notification.type.admin_activate_user',1),(9,'notification.type.pm',1),(10,'notification.type.topic_in_queue',1),(11,'notification.type.post_in_queue',1),(12,'notification.type.report_post',1),(13,'notification.type.disapprove_topic',1),(14,'topic_in_queue',1),(15,'post_in_queue',1);
/*!40000 ALTER TABLE `phpbb_notification_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_notifications`
--

DROP TABLE IF EXISTS `phpbb_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_notifications` (
  `notification_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notification_type_id` smallint(4) unsigned NOT NULL DEFAULT 0,
  `item_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `item_parent_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `notification_read` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `notification_time` int(11) unsigned NOT NULL DEFAULT 1,
  `notification_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `item_ident` (`notification_type_id`,`item_id`),
  KEY `user` (`user_id`,`notification_read`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_notifications`
--

LOCK TABLES `phpbb_notifications` WRITE;
/*!40000 ALTER TABLE `phpbb_notifications` DISABLE KEYS */;
INSERT INTO `phpbb_notifications` VALUES (1,9,1,0,51,1,1606614108,'a:2:{s:12:\"from_user_id\";s:1:\"2\";s:15:\"message_subject\";s:20:\"Willkommen im Forum.\";}'),(3,13,4,10,2,1,1607737819,'a:5:{s:17:\"disapprove_reason\";s:51:\"Die gemeldete Nachricht betrifft ein anderes Thema.\";s:9:\"poster_id\";s:1:\"2\";s:11:\"topic_title\";s:27:\"[Allgemeine Frage] Hmm test\";s:13:\"post_username\";s:0:\"\";s:10:\"forum_name\";s:5:\"Hilfe\";}');
/*!40000 ALTER TABLE `phpbb_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_oauth_accounts`
--

DROP TABLE IF EXISTS `phpbb_oauth_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_oauth_accounts` (
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `provider` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `oauth_provider_id` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`user_id`,`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_oauth_accounts`
--

LOCK TABLES `phpbb_oauth_accounts` WRITE;
/*!40000 ALTER TABLE `phpbb_oauth_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_oauth_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_oauth_states`
--

DROP TABLE IF EXISTS `phpbb_oauth_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_oauth_states` (
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `session_id` char(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `provider` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `oauth_state` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  KEY `user_id` (`user_id`),
  KEY `provider` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_oauth_states`
--

LOCK TABLES `phpbb_oauth_states` WRITE;
/*!40000 ALTER TABLE `phpbb_oauth_states` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_oauth_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_oauth_tokens`
--

DROP TABLE IF EXISTS `phpbb_oauth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_oauth_tokens` (
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `session_id` char(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `provider` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `oauth_token` mediumtext COLLATE utf8_bin NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `provider` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_oauth_tokens`
--

LOCK TABLES `phpbb_oauth_tokens` WRITE;
/*!40000 ALTER TABLE `phpbb_oauth_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_oauth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_poll_options`
--

DROP TABLE IF EXISTS `phpbb_poll_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_poll_options` (
  `poll_option_id` tinyint(4) NOT NULL DEFAULT 0,
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `poll_option_text` text COLLATE utf8_bin NOT NULL,
  `poll_option_total` mediumint(8) unsigned NOT NULL DEFAULT 0,
  KEY `poll_opt_id` (`poll_option_id`),
  KEY `topic_id` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_poll_options`
--

LOCK TABLES `phpbb_poll_options` WRITE;
/*!40000 ALTER TABLE `phpbb_poll_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_poll_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_poll_votes`
--

DROP TABLE IF EXISTS `phpbb_poll_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_poll_votes` (
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `poll_option_id` tinyint(4) NOT NULL DEFAULT 0,
  `vote_user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `vote_user_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  KEY `topic_id` (`topic_id`),
  KEY `vote_user_id` (`vote_user_id`),
  KEY `vote_user_ip` (`vote_user_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_poll_votes`
--

LOCK TABLES `phpbb_poll_votes` WRITE;
/*!40000 ALTER TABLE `phpbb_poll_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_poll_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_posts`
--

DROP TABLE IF EXISTS `phpbb_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_posts` (
  `post_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `poster_id` int(10) unsigned NOT NULL DEFAULT 0,
  `icon_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `poster_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `post_time` int(11) unsigned NOT NULL DEFAULT 0,
  `post_reported` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `enable_bbcode` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `enable_smilies` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `enable_magic_url` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `enable_sig` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `post_username` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `post_subject` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_text` mediumtext COLLATE utf8_bin NOT NULL,
  `post_checksum` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `post_attachment` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `bbcode_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bbcode_uid` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `post_postcount` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `post_edit_time` int(11) unsigned NOT NULL DEFAULT 0,
  `post_edit_reason` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `post_edit_user` int(10) unsigned NOT NULL DEFAULT 0,
  `post_edit_count` smallint(4) unsigned NOT NULL DEFAULT 0,
  `post_edit_locked` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `post_visibility` tinyint(3) NOT NULL DEFAULT 0,
  `post_delete_time` int(11) unsigned NOT NULL DEFAULT 0,
  `post_delete_reason` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `post_delete_user` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`post_id`),
  KEY `forum_id` (`forum_id`),
  KEY `topic_id` (`topic_id`),
  KEY `poster_ip` (`poster_ip`),
  KEY `poster_id` (`poster_id`),
  KEY `tid_post_time` (`topic_id`,`post_time`),
  KEY `post_username` (`post_username`),
  KEY `post_visibility` (`post_visibility`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_posts`
--

LOCK TABLES `phpbb_posts` WRITE;
/*!40000 ALTER TABLE `phpbb_posts` DISABLE KEYS */;
INSERT INTO `phpbb_posts` VALUES (3,3,6,2,0,'188.97.219.60',1607731182,0,1,1,1,1,'','Unserer Regeln','<r>Das Forum <B><s>[b]</s>IgameRPG<e>[/b]</e></B> begreift sich selbst als Forum für den erfahrenen <B><s>[b]</s>Benutzer<e>[/b]</e></B>. Als solches möchte es keine Konkurrenz zu bestehenden anderen Forensystemen sein, sondern als Ergänzung zu diesen auftreten. Das Forum mit seinen Mitgliedern ist bestrebt zu diesen einen freundschaftlichen Kontakt zu pflegen.<br/>\n<br/>\nDas Forum <B><s>[b]</s>IgameRPG<e>[/b]</e></B> dient dem Zweck, sich mit anderen Benutzern auszutauschen und zu diskutieren. Damit dies friedlich und gesittet abläuft, gelten folgende Regeln für das gesamte Forum. Durch die Annahme unserer Regeln garantierst du, dass du keine Beiträge verfasst, die obszön, vulgär oder sexuell orientiert sind, oder die sonst in irgendeiner Form gegen geltendes Recht verstoßen.<br/>\n<br/>\nUm einen geregelten Ablauf zu garantieren, sind folgende <B><s>[b]</s>Regeln<e>[/b]</e></B> in diesem Forum zu beachten:<br/>\n<br/>\n<SIZE size=\"150\"><s>[size=150]</s>Der Umgang miteinander<e>[/size]</e></SIZE><br/>\n\n    <LIST><s>[list]</s><LI>Beleidigungen, illegale Links und Inhalte sowie sonstige Störungen der Diskussionen sind zu unterlassen und werden von den Moderatoren umgehend entfernt.</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Sollten Probleme oder Unzufriedenheiten mit Team-Mitgliedern auftreten, so benutzt das Kontaktformular, um die Angelegenheit zu klären.</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Nicknames, die beleidigend oder anstößig sind, sind verboten</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Weiterhin verboten sind Beiträge mit extremistischen, rassistischen und pornografischen Inhalten sowie jegliche Inhalte, die gegen geltendes Recht verstoßen.</LI><e>[/list]</e></LIST>\n<LIST><s>[list]</s><LI>Fällt jemand durch wiederholte Störung der allgemeinen Ordnung auf und ändert sein Verhalten auch nach mehrmaligen Hinweisen / Aufforderungen nicht, werden entsprechende Massnahmen getroffen, den Boardfrieden zu wahren bzw. wiederherzustellen.</LI><e>[/list]</e></LIST>\n\n<SIZE size=\"150\"><s>[size=150]</s>Benutzernamen<e>[/size]</e></SIZE><br/>\n\n    <LIST><s>[list]</s><LI>Nicknamen, die gegen die guten Sitten verstoßen, sind nicht erlaubt.</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Eingetragene Warenzeichen oder Namen von Prominenten sind nicht erwünscht.</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Benutzernamen, die Teil einer URL sind, sind erlaubt, aber nur, wenn diese URL nicht zu einer Seite führt, deren Inhalte gegen geltendes Recht verstoßen.</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Doppelnicks sind zu vermeiden. Solltest du das Bedürfnis haben, deinen Nick zu ändern, kannst du uns eine Mail und/oder PN schicken. Solltest du bereits Doppelnicks besitzen, melde sie uns bitte. Denn so können vorhandene Beiträge und Themen in den neuen Account übernommen werden. Bei offensichtlichem Gebrauch von Doppelnicks kann es zu Sanktionen bis hin zu Sperrungen kommen!</LI><e>[/list]</e></LIST>\n\n<SIZE size=\"150\"><s>[size=150]</s>Sprache<e>[/size]</e></SIZE><br/>\nJeder Benutzer sollte sich merkbar bemühen die Regeln der Rechtschreibung zum größten Teil einzuhalten. Tippfehler können durch Nutzung der Vorschau- oder Editierfunktion schnell behoben werden - Korrekturlesen ist in jedem Fall angebracht. Wörter, die falsch geschrieben sind, können andere Benutzer nicht über die Suchfunktion finden und eventuell auch nicht verstehen. Bei vielen Sätzen/großen Texten ist eine Interpunktion (zumin. Satzabschließende Zeichen) und das Setzen von Absätzen unbedingt erforderlich.<br/>\n<br/>\n<SIZE size=\"150\"><s>[size=150]</s>Suchfunktion<e>[/size]</e></SIZE><br/>\nViele Fragen sind auch bereits im Forum erläutert und können sehr schnell über die Suchfunktion abgerufen werden. Auch wenn die Suche aufwendig erscheint, ist sie in den meisten Fällen der schnellste Weg, die gewünschten Lösungen zu bekommen, da man nicht auf Antworten anderer Benutzer warten muss.<br/>\n<br/>\n<SIZE size=\"150\"><s>[size=150]</s>Formulierung einer Anfrage / Richtlinien beim Schreiben eines neuen Themas<e>[/size]</e></SIZE><br/>\nDer Titel eines Themas sollte so aussagekräftig wie möglich gewählt werden. Wörter wie \"Hilfe\" oder \"dringend\" haben im Titel sowie im eigentlichen Beitrag nichts zu suchen. Die eigentliche Anfrage sollte so präzise wie möglich formuliert werden, Rückfragen kosten schließlich Zeit.<br/>\n<br/>\n<B><s>[b]</s>Grundsätzlich gelten die folgenden Richtlinien was den Inhalt betrifft:<e>[/b]</e></B><br/>\n\n    <LIST><s>[list]</s><LI>keine Attacken auf Personen, nur auf Tatsachen</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>keine Links oder Bilder zu rechtsextremen/illegalen/pornographischen Seiten</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>keine unnötigen Schimpfwörter, Flüche etc. die über das erträgliche Maß hinaus gehen</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>keine Emoticon Lawinen</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>keine übertriebenen Spam-Posts (Posts ohne irgendwelchen nützlichen Sinn)</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>keine Verweise / Links auf Auktionen in Internet (ebay u.ä.)</LI><e>[/list]</e></LIST>\n\n<br/>\n<SIZE size=\"150\"><s>[size=150]</s>Bei Fragen oder Beschreibungen solltet Ihr Bitte auf folgendes bei Eurem Beitrag achten<e>[/size]</e></SIZE><br/>\n\n    <LIST><s>[list]</s><LI>verwende klare Titel, die Dein Anliegen schildern z.B. \"Cattleya rex - Bedingungen am Naturstandort\"</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>bevor du schreibst, schaue Bitte erst im Forum mit der Suche, ob die Frage nicht schon gestellt und sogar beantwortet wurde</LI><e>[/list]</e></LIST>\n\n<SIZE size=\"150\"><s>[size=150]</s>Private Nachrichten<e>[/size]</e></SIZE><br/>\nPrivate Nachrichten sind ausschließlich für private bzw. nicht-öffentliche Themen gedacht. Supportanfragen werden nicht in privaten Nachrichten diskutiert (dazu gehören u.a. Aufforderungen bestimmte Anfragen in Themen zu beantworten, oder die Suche nach bestimmten Pflanzen etc.). Das Versenden von Werbung per privater Nachrichten ist unerwünscht<br/>\n<br/>\n<SIZE size=\"150\"><s>[size=150]</s>Signaturen<e>[/size]</e></SIZE><br/>\nJedes Forum Mitglied, wird gebeten höchstens 1 Bild in der Signatur einzufügen! Wenn ein Bild verwendet wird, bitte nicht mehr als 5 Zeilen Text dazu. Bitte verwendet keine Bilder mit pornographischen, illegalen oder rechtsextremen Inhalten, oder sonst irgendwelche anstößige Grafiken die andere attackieren. In der Signatur, wie in den Posts keine Texte mit pornographischen, illegalen oder rechtsextremen Inhalt schreiben oder auf Seiten mit pornographischen, illegalen oder rechtsextremen Inhalt verweisen. Auch keine Attacken auf andere und Texte die sonstwie anstößig sind. Sollte dennoch eine Signatur nicht in der norm sein, werden wir Admins diese Signatur sofort, und ohne Vorankündigung löschen!<br/>\n<br/>\n<SIZE size=\"150\"><s>[size=150]</s>Eigene Homepage im Profil<e>[/size]</e></SIZE><br/>\nWie im Forum auch, darf im Profil keine Homepage eingetragen sein, deren Inhalte in irgendeiner Form rechtswidrig sind.<br/>\n<br/>\n<SIZE size=\"150\"><s>[size=150]</s>Avatar-Richtlinien<e>[/size]</e></SIZE><br/>\nEs dürfen keine Bilder mit pornographischen, illegalen oder rechtsextremen Inhalt oder sonstwie anstößige Bilder verwendet werden. Das Avatarbild darf nicht größer als 25kb und 120x120px sein.<br/>\n<br/>\n<SIZE size=\"150\"><s>[size=150]</s>Werbung<e>[/size]</e></SIZE><br/>\nKommerzielle Werbung ist nicht gestattet und wird umgehend entfernt. Auch das Bewerben nichtkommerzieller Seiten sollte nach Möglichkeit zuvor mit einem Moderator oder Admin abgesprochen werden. Ausnahme ist die Antwort auf eine direkte Frage in einem Thema oder Beitrag danach.<br/>\nWenn Dir das Forum nicht gefällt, brauchst du das nicht ständig verkünden. Wenn Dir ein anderes Forum besser gefällt, dann geh in das andere Forum. Eine Bewerbung für andere Foren mit gleichem Thema wird daher kommentarlos gelöscht.<br/>\n<br/>\n<SIZE size=\"150\"><s>[size=150]</s>Urheberrecht<e>[/size]</e></SIZE><br/>\nBei der Erstellung neuer Themen oder Beiträge haben die Benutzer des Forums darauf zu achten, dass kein urheberrechtlich geschütztes Material ohne Angabe der Quelle veröffentlicht wird. Weiters ist bei der Verwendung von Bildern und Grafiken darauf zu achten, dass immer ein entsprechender Abbildungsnachweis eingefügt oder mit dem Rechteinhaber Kontakt aufgenommen wird.<br/>\n<br/>\n<SIZE size=\"150\"><s>[size=150]</s>Verstöße gegen diese Regeln (Verwarnungen, Sperren, Änderungen, Löschungen und Schliessungen)<e>[/size]</e></SIZE><br/>\n\n<LIST><s>[list]</s><LI>Wer gegen die Regeln verstösst, wird ermahnt.</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Wer trotz Ermahnung fortgesetzt gegen die Regeln verstößt, kann zeitweise oder vollständig von der Teilnahme am Forum ausgeschlossen werden.</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Sollten Beiträge beleidigende ode rechtswidrige Inhalte aufweisen, behält sich die Administration vor, diese zu ändern, zu löschen</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Es gilt: Wer wiederholt mutwillig gegen diese Regeln verstößt, muss damit rechnen zeitweise oder auch auf Lebenszeit aus dem Forum ausgeschlossen zu werden.</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Themen und Beiträge, die gegen diese Regeln verstoßen, werden ggf. kommentarlos gelöscht.</LI><e>[/list]</e></LIST>\n    <LIST><s>[list]</s><LI>Persönliche Differenzen sind ausschließlich per E-Mail Im Chat oder Supportcenter, also außerhalb des Forensystems auszutragen.</LI><e>[/list]</e></LIST></r>','be7c7b565e3e3faa16f9bd706edbd02f',0,'','8v25j',1,0,'',0,0,0,1,0,'',0),(5,5,11,2,0,'188.97.219.60',1607742660,0,1,1,1,1,'','Bewewrbungsvorlage','<r>Wenn du dich hier als Teammitglied bewerben möchtest dann beachte bitte folgende Bewerbungsvorlage:\n<QUOTE><s>[quote]</s>Themenprefix: [Bewerbung von]<br/>\nBetreff: Nick<br/>\n<br/>\nName: MaxMustermann<br/>\nAlter: 26<br/>\nPosition: GM. LokalOp, GlobalOp, ServicesRoot, NetAdmin, Forumadmin, ForumModerator<br/>\nKenntnisse: Bitte führe hier all deinen Kentnisse auf. Solltest du ungelernt sein so gebe Ungelernt an.<br/>\nStärken &amp; Schwächen: Nenne sie uns.<br/>\nÜber dich:<br/>\nErzähl uns etwas über dich warum wir zb dich nehmen sollten nenne uns deine Wünsche oder Anregungen.<e>[/quote]</e></QUOTE>\nDiese Vorlage muss als Beitrag einghalten werden Ebenso das Beitragsprefix.<br/>\nSollte sie nicht so entsprechen wird sie kommentarlos entfernt.<br/>\n <br/>\n </r>','a9f448a8cc6dfed7ce2d46cbc2fff6ab',0,'','ait1s93o',1,0,'',0,0,0,1,1607742691,'',2);
/*!40000 ALTER TABLE `phpbb_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_privmsgs`
--

DROP TABLE IF EXISTS `phpbb_privmsgs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_privmsgs` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `root_level` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `author_id` int(10) unsigned NOT NULL DEFAULT 0,
  `icon_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `author_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `message_time` int(11) unsigned NOT NULL DEFAULT 0,
  `enable_bbcode` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `enable_smilies` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `enable_magic_url` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `enable_sig` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `message_subject` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `message_text` mediumtext COLLATE utf8_bin NOT NULL,
  `message_edit_reason` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `message_edit_user` int(10) unsigned NOT NULL DEFAULT 0,
  `message_attachment` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `bbcode_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bbcode_uid` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `message_edit_time` int(11) unsigned NOT NULL DEFAULT 0,
  `message_edit_count` smallint(4) unsigned NOT NULL DEFAULT 0,
  `to_address` text COLLATE utf8_bin NOT NULL,
  `bcc_address` text COLLATE utf8_bin NOT NULL,
  `message_reported` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`msg_id`),
  KEY `author_ip` (`author_ip`),
  KEY `message_time` (`message_time`),
  KEY `author_id` (`author_id`),
  KEY `root_level` (`root_level`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_privmsgs`
--

LOCK TABLES `phpbb_privmsgs` WRITE;
/*!40000 ALTER TABLE `phpbb_privmsgs` DISABLE KEYS */;
INSERT INTO `phpbb_privmsgs` VALUES (1,0,2,0,'178.4.43.135',1606614108,1,1,1,0,'Willkommen im Forum.','<r>Hallo und Willkommen TestNutzer,<br/>\n<br/>\nIch begrüße dich herzlich hier im Forum...<br/>\n<br/>\nBla bla bla bla<br/>\n<br/>\nText wird noch editiert <E>:D</E><br/>\n<br/>\nTschüss</r>','',0,0,'','',0,0,'u_51','',0);
/*!40000 ALTER TABLE `phpbb_privmsgs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_privmsgs_folder`
--

DROP TABLE IF EXISTS `phpbb_privmsgs_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_privmsgs_folder` (
  `folder_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pm_count` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`folder_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_privmsgs_folder`
--

LOCK TABLES `phpbb_privmsgs_folder` WRITE;
/*!40000 ALTER TABLE `phpbb_privmsgs_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_privmsgs_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_privmsgs_rules`
--

DROP TABLE IF EXISTS `phpbb_privmsgs_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_privmsgs_rules` (
  `rule_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `rule_check` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `rule_connection` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `rule_string` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `rule_user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `rule_group_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `rule_action` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `rule_folder_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`rule_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_privmsgs_rules`
--

LOCK TABLES `phpbb_privmsgs_rules` WRITE;
/*!40000 ALTER TABLE `phpbb_privmsgs_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_privmsgs_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_privmsgs_to`
--

DROP TABLE IF EXISTS `phpbb_privmsgs_to`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_privmsgs_to` (
  `msg_id` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `author_id` int(10) unsigned NOT NULL DEFAULT 0,
  `pm_deleted` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `pm_new` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `pm_unread` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `pm_replied` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `pm_marked` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `pm_forwarded` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `folder_id` int(11) NOT NULL DEFAULT 0,
  KEY `msg_id` (`msg_id`),
  KEY `author_id` (`author_id`),
  KEY `usr_flder_id` (`user_id`,`folder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_privmsgs_to`
--

LOCK TABLES `phpbb_privmsgs_to` WRITE;
/*!40000 ALTER TABLE `phpbb_privmsgs_to` DISABLE KEYS */;
INSERT INTO `phpbb_privmsgs_to` VALUES (1,51,2,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `phpbb_privmsgs_to` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_profile_fields`
--

DROP TABLE IF EXISTS `phpbb_profile_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_profile_fields` (
  `field_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `field_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `field_type` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `field_ident` varchar(20) COLLATE utf8_bin NOT NULL DEFAULT '',
  `field_length` varchar(20) COLLATE utf8_bin NOT NULL DEFAULT '',
  `field_minlen` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `field_maxlen` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `field_novalue` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `field_default_value` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `field_validation` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `field_required` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_show_on_reg` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_hide` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_no_view` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_active` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_order` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `field_show_profile` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_show_on_vt` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_show_novalue` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_show_on_pm` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_show_on_ml` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_is_contact` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `field_contact_desc` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `field_contact_url` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`),
  KEY `fld_type` (`field_type`),
  KEY `fld_ordr` (`field_order`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_profile_fields`
--

LOCK TABLES `phpbb_profile_fields` WRITE;
/*!40000 ALTER TABLE `phpbb_profile_fields` DISABLE KEYS */;
INSERT INTO `phpbb_profile_fields` VALUES (1,'phpbb_location','profilefields.type.string','phpbb_location','20','2','100','','','.*',0,0,0,0,1,1,1,1,0,1,1,0,'',''),(2,'phpbb_website','profilefields.type.url','phpbb_website','40','12','255','','','',0,0,0,0,1,2,1,1,0,1,1,1,'VISIT_WEBSITE','%s'),(3,'phpbb_interests','profilefields.type.text','phpbb_interests','3|30','2','500','','','.*',0,0,0,0,0,3,1,0,0,0,0,0,'',''),(4,'phpbb_occupation','profilefields.type.text','phpbb_occupation','3|30','2','500','','','.*',0,0,0,0,0,4,1,0,0,0,0,0,'',''),(5,'phpbb_icq','profilefields.type.string','phpbb_icq','20','3','15','','','[0-9]+',0,0,0,0,0,6,1,1,0,1,1,1,'SEND_ICQ_MESSAGE','https://www.icq.com/people/%s/'),(6,'phpbb_yahoo','profilefields.type.string','phpbb_yahoo','40','5','255','','','.*',0,0,0,0,0,8,1,1,0,1,1,1,'SEND_YIM_MESSAGE','ymsgr:sendim?%s'),(7,'phpbb_facebook','profilefields.type.string','phpbb_facebook','20','5','50','','','[\\w.]+',0,0,0,0,1,9,1,1,0,1,1,1,'VIEW_FACEBOOK_PROFILE','http://facebook.com/%s/'),(8,'phpbb_twitter','profilefields.type.string','phpbb_twitter','20','1','15','','','[\\w_]+',0,0,0,0,1,10,1,1,0,1,1,1,'VIEW_TWITTER_PROFILE','http://twitter.com/%s'),(9,'phpbb_skype','profilefields.type.string','phpbb_skype','20','6','32','','','[a-zA-Z][\\w\\.,\\-_]+',0,0,0,0,1,11,1,1,0,1,1,1,'VIEW_SKYPE_PROFILE','skype:%s?userinfo'),(10,'phpbb_youtube','profilefields.type.string','phpbb_youtube','20','3','60','','','[a-zA-Z][\\w\\.,\\-_]+',0,0,0,0,1,12,1,1,0,1,1,1,'VIEW_YOUTUBE_CHANNEL','http://youtube.com/user/%s');
/*!40000 ALTER TABLE `phpbb_profile_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_profile_fields_data`
--

DROP TABLE IF EXISTS `phpbb_profile_fields_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_profile_fields_data` (
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `pf_phpbb_interests` mediumtext COLLATE utf8_bin NOT NULL,
  `pf_phpbb_occupation` mediumtext COLLATE utf8_bin NOT NULL,
  `pf_phpbb_location` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pf_phpbb_icq` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pf_phpbb_twitter` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pf_phpbb_skype` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pf_phpbb_youtube` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pf_phpbb_facebook` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pf_phpbb_website` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pf_phpbb_yahoo` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_profile_fields_data`
--

LOCK TABLES `phpbb_profile_fields_data` WRITE;
/*!40000 ALTER TABLE `phpbb_profile_fields_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_profile_fields_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_profile_fields_lang`
--

DROP TABLE IF EXISTS `phpbb_profile_fields_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_profile_fields_lang` (
  `field_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `lang_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `option_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `field_type` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lang_value` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`,`lang_id`,`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_profile_fields_lang`
--

LOCK TABLES `phpbb_profile_fields_lang` WRITE;
/*!40000 ALTER TABLE `phpbb_profile_fields_lang` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_profile_fields_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_profile_lang`
--

DROP TABLE IF EXISTS `phpbb_profile_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_profile_lang` (
  `field_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `lang_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `lang_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `lang_explain` text COLLATE utf8_bin NOT NULL,
  `lang_default_value` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`,`lang_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_profile_lang`
--

LOCK TABLES `phpbb_profile_lang` WRITE;
/*!40000 ALTER TABLE `phpbb_profile_lang` DISABLE KEYS */;
INSERT INTO `phpbb_profile_lang` VALUES (1,1,'LOCATION','',''),(1,2,'LOCATION','',''),(1,3,'LOCATION','',''),(2,1,'WEBSITE','',''),(2,2,'WEBSITE','',''),(2,3,'WEBSITE','',''),(3,1,'INTERESTS','',''),(3,2,'INTERESTS','',''),(3,3,'INTERESTS','',''),(4,1,'OCCUPATION','',''),(4,2,'OCCUPATION','',''),(4,3,'OCCUPATION','',''),(5,1,'ICQ','',''),(5,2,'ICQ','',''),(5,3,'ICQ','',''),(6,1,'YAHOO','',''),(6,2,'YAHOO','',''),(6,3,'YAHOO','',''),(7,1,'FACEBOOK','',''),(7,2,'FACEBOOK','',''),(7,3,'FACEBOOK','',''),(8,1,'TWITTER','',''),(8,2,'TWITTER','',''),(8,3,'TWITTER','',''),(9,1,'SKYPE','',''),(9,2,'SKYPE','',''),(9,3,'SKYPE','',''),(10,1,'YOUTUBE','',''),(10,2,'YOUTUBE','',''),(10,3,'YOUTUBE','','');
/*!40000 ALTER TABLE `phpbb_profile_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_ranks`
--

DROP TABLE IF EXISTS `phpbb_ranks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_ranks` (
  `rank_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `rank_title` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `rank_min` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `rank_special` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `rank_image` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`rank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_ranks`
--

LOCK TABLES `phpbb_ranks` WRITE;
/*!40000 ALTER TABLE `phpbb_ranks` DISABLE KEYS */;
INSERT INTO `phpbb_ranks` VALUES (1,'Administrator',0,1,'');
/*!40000 ALTER TABLE `phpbb_ranks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_reports`
--

DROP TABLE IF EXISTS `phpbb_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_reports` (
  `report_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reason_id` smallint(4) unsigned NOT NULL DEFAULT 0,
  `post_id` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `user_notify` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `report_closed` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `report_time` int(11) unsigned NOT NULL DEFAULT 0,
  `report_text` mediumtext COLLATE utf8_bin NOT NULL,
  `pm_id` int(10) unsigned NOT NULL DEFAULT 0,
  `reported_post_enable_bbcode` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `reported_post_enable_smilies` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `reported_post_enable_magic_url` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `reported_post_text` mediumtext COLLATE utf8_bin NOT NULL,
  `reported_post_uid` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `reported_post_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`report_id`),
  KEY `post_id` (`post_id`),
  KEY `pm_id` (`pm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_reports`
--

LOCK TABLES `phpbb_reports` WRITE;
/*!40000 ALTER TABLE `phpbb_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_reports_reasons`
--

DROP TABLE IF EXISTS `phpbb_reports_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_reports_reasons` (
  `reason_id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `reason_title` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `reason_description` mediumtext COLLATE utf8_bin NOT NULL,
  `reason_order` smallint(4) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`reason_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_reports_reasons`
--

LOCK TABLES `phpbb_reports_reasons` WRITE;
/*!40000 ALTER TABLE `phpbb_reports_reasons` DISABLE KEYS */;
INSERT INTO `phpbb_reports_reasons` VALUES (1,'warez','Der gemeldete Beitrag enthält Links zu illegaler Software oder Raubkopien.',1),(2,'spam','Der gemeldete Beitrag hat nur zum Ziel, für eine Website oder ein anderes Produkt zu werben.',2),(3,'off_topic','Der gemeldete Beitrag betrifft ein anderes Thema.',3),(4,'other','Keine der genannten Kategorien. Bitte benutze „Weitere Informationen“ für deine Meldung.',4);
/*!40000 ALTER TABLE `phpbb_reports_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_search_results`
--

DROP TABLE IF EXISTS `phpbb_search_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_search_results` (
  `search_key` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_time` int(11) unsigned NOT NULL DEFAULT 0,
  `search_keywords` mediumtext COLLATE utf8_bin NOT NULL,
  `search_authors` mediumtext COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`search_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_search_results`
--

LOCK TABLES `phpbb_search_results` WRITE;
/*!40000 ALTER TABLE `phpbb_search_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_search_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_search_wordlist`
--

DROP TABLE IF EXISTS `phpbb_search_wordlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_search_wordlist` (
  `word_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word_text` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `word_common` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `word_count` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`word_id`),
  UNIQUE KEY `wrd_txt` (`word_text`),
  KEY `wrd_cnt` (`word_count`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_search_wordlist`
--

LOCK TABLES `phpbb_search_wordlist` WRITE;
/*!40000 ALTER TABLE `phpbb_search_wordlist` DISABLE KEYS */;
INSERT INTO `phpbb_search_wordlist` VALUES (1,'dies',0,1),(2,'ist',0,1),(3,'ein',0,2),(4,'beispielbeitrag',0,1),(5,'deiner',0,1),(6,'phpbb3',0,2),(7,'installation',0,1),(8,'alles',0,1),(9,'scheint',0,1),(10,'zu',0,1),(11,'funktionieren',0,1),(12,'wenn',0,2),(13,'du',0,1),(14,'moechtest',0,2),(15,'kannst',0,1),(16,'diesen',0,1),(17,'beitrag',0,2),(18,'loeschen',0,1),(19,'und',0,1),(20,'mit',0,1),(21,'der',0,1),(22,'einrichtung',0,1),(23,'deines',0,1),(24,'boards',0,1),(25,'fortfahren',0,1),(26,'waehrend',0,1),(27,'des',0,1),(28,'installationsvorgangs',0,1),(29,'wurden',0,1),(30,'ersten',0,1),(31,'kategorie',0,1),(32,'deinem',0,1),(33,'forum',0,1),(34,'passende',0,1),(35,'berechtigungen',0,1),(36,'fuer',0,2),(37,'die',0,1),(38,'benutzergruppen',0,1),(39,'administratoren',0,1),(40,'bots',0,1),(41,'globale',0,1),(42,'moderatoren',0,1),(43,'gaeste',0,1),(44,'registrierte',0,1),(45,'benutzer',0,1),(46,'coppa',0,1),(47,'zugewiesen',0,1),(48,'dich',0,2),(49,'entscheidest',0,1),(50,'auch',0,1),(51,'deine',0,2),(52,'erste',0,1),(53,'dein',0,1),(54,'erstes',0,1),(55,'darfst',0,1),(56,'nicht',0,2),(57,'vergessen',0,1),(58,'den',0,1),(59,'genannten',0,1),(60,'gruppen',0,1),(61,'entsprechende',0,1),(62,'rechte',0,1),(63,'alle',0,1),(64,'neuen',0,1),(65,'kategorien',0,1),(66,'foren',0,1),(67,'erstellst',0,1),(68,'zuzuweisen',0,1),(69,'es',0,1),(70,'wird',0,2),(71,'jedoch',0,1),(72,'empfohlen',0,1),(73,'umzubenennen',0,1),(74,'deren',0,1),(75,'uebernehmen',0,1),(76,'neue',0,1),(77,'erstellt',0,1),(78,'werden',0,2),(79,'viel',0,1),(80,'spass',0,1),(81,'phpbb',0,1),(82,'willkommen',0,1),(83,'bei',0,1),(84,'was',0,1),(85,'issn',0,1),(86,'das',0,2),(87,'mist',0,1),(88,'zentrierter',0,1),(89,'text',0,1),(90,'align',0,1),(91,'haha',0,1),(92,'test',0,0),(93,'allgemeine',0,0),(94,'frage',0,0),(95,'hmm',0,0),(96,'hier',0,1),(97,'als',0,1),(98,'teammitglied',0,1),(99,'bewerben',0,1),(100,'dann',0,1),(101,'beachte',0,1),(102,'bitte',0,1),(103,'folgende',0,1),(104,'bewerbungsvorlage',0,1),(105,'quote',0,1),(106,'themenprefix',0,1),(107,'bewerbung',0,1),(108,'von',0,1),(109,'betreff',0,1),(110,'nick',0,1),(111,'name',0,1),(112,'maxmustermann',0,1),(113,'alter',0,1),(114,'position',0,1),(115,'lokalop',0,1),(116,'globalop',0,1),(117,'servicesroot',0,1),(118,'netadmin',0,1),(119,'forumadmin',0,1),(120,'forummoderator',0,1),(121,'kenntnisse',0,1),(122,'fuehre',0,1),(123,'all',0,1),(124,'deinen',0,1),(125,'kentnisse',0,1),(126,'auf',0,1),(127,'solltest',0,1),(128,'ungelernt',0,1),(129,'sein',0,1),(130,'gebe',0,1),(131,'staerken',0,1),(132,'schwaechen',0,1),(133,'nenne',0,1),(134,'sie',0,1),(135,'uns',0,1),(136,'über',0,1),(137,'erzaehl',0,1),(138,'etwas',0,1),(139,'ueber',0,1),(140,'warum',0,1),(141,'wir',0,1),(142,'nehmen',0,1),(143,'sollten',0,1),(144,'wuensche',0,1),(145,'oder',0,1),(146,'anregungen',0,1),(147,'diese',0,1),(148,'vorlage',0,1),(149,'muss',0,1),(150,'einghalten',0,1),(151,'ebenso',0,1),(152,'beitragsprefix',0,1),(153,'sollte',0,1),(154,'entsprechen',0,1),(155,'kommentarlos',0,1),(156,'entfernt',0,1),(157,'bewewrbungsvorlage',0,1);
/*!40000 ALTER TABLE `phpbb_search_wordlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_search_wordmatch`
--

DROP TABLE IF EXISTS `phpbb_search_wordmatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_search_wordmatch` (
  `post_id` int(10) unsigned NOT NULL DEFAULT 0,
  `word_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title_match` tinyint(1) unsigned NOT NULL DEFAULT 0,
  UNIQUE KEY `un_mtch` (`word_id`,`post_id`,`title_match`),
  KEY `word_id` (`word_id`),
  KEY `post_id` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_search_wordmatch`
--

LOCK TABLES `phpbb_search_wordmatch` WRITE;
/*!40000 ALTER TABLE `phpbb_search_wordmatch` DISABLE KEYS */;
INSERT INTO `phpbb_search_wordmatch` VALUES (1,1,0),(1,2,0),(1,3,0),(2,3,0),(1,4,0),(1,5,0),(1,6,0),(1,6,1),(1,7,0),(1,8,0),(1,9,0),(1,10,0),(1,11,0),(1,12,0),(5,12,0),(1,13,0),(1,14,0),(5,14,0),(1,15,0),(1,16,0),(1,17,0),(5,17,0),(1,18,0),(1,19,0),(1,20,0),(1,21,0),(1,22,0),(1,23,0),(1,24,0),(1,25,0),(1,26,0),(1,27,0),(1,28,0),(1,29,0),(1,30,0),(1,31,0),(1,32,0),(1,33,0),(1,34,0),(1,35,0),(1,36,0),(2,36,0),(1,37,0),(1,38,0),(1,39,0),(1,40,0),(1,41,0),(1,42,0),(1,43,0),(1,44,0),(1,45,0),(1,46,0),(1,47,0),(1,48,0),(5,48,0),(1,49,0),(1,50,0),(1,51,0),(5,51,0),(1,52,0),(1,53,0),(1,54,0),(1,55,0),(1,56,0),(5,56,0),(1,57,0),(1,58,0),(1,59,0),(1,60,0),(1,61,0),(1,62,0),(1,63,0),(1,64,0),(1,65,0),(1,66,0),(1,67,0),(1,68,0),(1,69,0),(1,70,0),(5,70,0),(1,71,0),(1,72,0),(1,73,0),(1,74,0),(1,75,0),(1,76,0),(1,77,0),(1,78,0),(5,78,0),(1,79,0),(1,80,0),(1,81,0),(1,82,1),(1,83,1),(2,84,0),(2,85,0),(2,86,0),(5,86,0),(2,87,0),(2,88,0),(2,89,0),(2,90,0),(2,91,1),(5,96,0),(5,97,0),(5,98,0),(5,99,0),(5,100,0),(5,101,0),(5,102,0),(5,103,0),(5,104,0),(5,105,0),(5,106,0),(5,107,0),(5,108,0),(5,109,0),(5,110,0),(5,111,0),(5,112,0),(5,113,0),(5,114,0),(5,115,0),(5,116,0),(5,117,0),(5,118,0),(5,119,0),(5,120,0),(5,121,0),(5,122,0),(5,123,0),(5,124,0),(5,125,0),(5,126,0),(5,127,0),(5,128,0),(5,129,0),(5,130,0),(5,131,0),(5,132,0),(5,133,0),(5,134,0),(5,135,0),(5,136,0),(5,137,0),(5,138,0),(5,139,0),(5,140,0),(5,141,0),(5,142,0),(5,143,0),(5,144,0),(5,145,0),(5,146,0),(5,147,0),(5,148,0),(5,149,0),(5,150,0),(5,151,0),(5,152,0),(5,153,0),(5,154,0),(5,155,0),(5,156,0),(5,157,1);
/*!40000 ALTER TABLE `phpbb_search_wordmatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_sessions`
--

DROP TABLE IF EXISTS `phpbb_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_sessions` (
  `session_id` char(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `session_user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `session_last_visit` int(11) unsigned NOT NULL DEFAULT 0,
  `session_start` int(11) unsigned NOT NULL DEFAULT 0,
  `session_time` int(11) unsigned NOT NULL DEFAULT 0,
  `session_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `session_browser` varchar(150) COLLATE utf8_bin NOT NULL DEFAULT '',
  `session_forwarded_for` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `session_page` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `session_viewonline` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `session_autologin` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `session_admin` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `session_forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`session_id`),
  KEY `session_time` (`session_time`),
  KEY `session_user_id` (`session_user_id`),
  KEY `session_fid` (`session_forum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_sessions`
--

LOCK TABLES `phpbb_sessions` WRITE;
/*!40000 ALTER TABLE `phpbb_sessions` DISABLE KEYS */;
INSERT INTO `phpbb_sessions` VALUES ('03912935cacded23b02c43e47679826b',1,1607748042,1607748042,1607748042,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/showthread.php?mode=threaded&pid=58&tid=48',1,0,0,0),('07ababc00934f8a7a44947a75fa37d9e',1,1607748968,1607748968,1607748968,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=addevent&calendar=1&day=28&month=9&year=2020',1,0,0,0),('08016fcd0847b4cf73392a3bd4d6dc8b',1,1607749345,1607749345,1607749345,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=24&order=asc&prefix=0&sortby=lastpost',1,0,0,0),('082e1c6877d4f8bcfefc029fd02114ac',1,1607749137,1607749137,1607749137,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=dayview&calendar=1&day=8&month=9&year=2020',1,0,0,0),('0e3ed2144a72ab6693ff7ea632f6eef3',1,1607750011,1607750011,1607750011,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=6&order=asc&prefix=0&sortby=starter',1,0,0,0),('0faa1c9da1fffc9a4e605ebce1b7ccba',1,1607749811,1607749811,1607749811,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=4&order=desc&prefix=0&sortby=lastpost',1,0,0,0),('109fc363d251540fae5d87ab29b6ee33',1,1607747941,1607747941,1607747941,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/misc.php?action=markread&fid=27',1,0,0,0),('13b13f26e7487ecdb18f6d78ec05f8df',1,1607750025,1607750025,1607750025,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=6&order=desc&prefix=0&sortby=views',1,0,0,0),('164d442864559a9cabaff10c0e540a40',1,1607749760,1607749760,1607749760,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=8&order=desc&prefix=0&sortby=views',1,0,0,0),('1bf694e72254493839a5800a9e07a725',1,1607749576,1607749576,1607749576,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=24&order=desc&prefix=0&sortby=views',1,0,0,0),('1d1d7a82cbe9962425fb71105d24a707',1,1607749780,1607749780,1607749780,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=8&order=desc&prefix=0&sortby=lastpost',1,0,0,0),('206f18adf03501c5896df64a37191725',1,1607749978,1607749978,1607749978,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=4&order=asc&prefix=0&sortby=subject',1,0,0,0),('20e496aad272e036babb4642a6d5eb88',1,1607749317,1607749317,1607749317,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=14&order=asc&prefix=0&sortby=views',1,0,0,0),('23aae78d6d71b6263f15d63f50e2e966',1,1607749562,1607749562,1607749562,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=27&order=desc&prefix=0&sortby=rating',1,0,0,0),('24837a706f61c50fb436f7021b28835f',1,1607749095,1607749095,1607749095,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=dayview&calendar=1&day=9&month=9&year=2020',1,0,0,0),('27744fb5233e4526cd7a93838b4cd5ff',1,1607749234,1607749234,1607749234,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=dayview&calendar=1&day=16&month=10&year=2020',1,0,0,0),('27e8f44f0576c927c003bfab9c5e1b37',1,1607749795,1607749795,1607749795,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=8&order=desc&prefix=0&sortby=rating',1,0,0,0),('2be0a8734d020c07531b3b8e320041d8',1,1607750039,1607750039,1607750039,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=5&order=asc&prefix=0&sortby=subject',1,0,0,0),('310974cc2f0b8168dccdf804b73e278d',1,1607749465,1607749465,1607749465,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=28&order=desc&prefix=0&sortby=lastpost',1,0,0,0),('34ede3c8c3b0df26fcbc6d3ef44cd30d',1,1607749631,1607749631,1607749631,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=29&order=desc&prefix=0&sortby=views',1,0,0,0),('3ab628d50b4b0c76d4bcc61eb1c4c331',1,1607748437,1607748437,1607748437,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/showthread.php?mode=threaded&pid=67&tid=57',1,0,0,0),('3c5f0e24479b8c5c874668d079bf4ca1',1,1607747927,1607747927,1607747927,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/misc.php?action=markread&fid=7',1,0,0,0),('3eb22cf5eff699c2568777e6e77d50d6',1,1607749450,1607749450,1607749450,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=23&order=asc&prefix=0&sortby=lastpost',1,0,0,0),('40f97be484ef7e63f738eae30bdd71d6',1,1607749058,1607749058,1607749058,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=dayview&calendar=1&day=20&month=10&year=2020',1,0,0,0),('45f0b3bf49897782dd987fc086eec43d',1,1607747914,1607747914,1607747914,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/showthread.php?action=newpost&tid=60',1,0,0,0),('47f6b3c79d100e3432ff2db05c6bdcd5',1,1607747884,1607747884,1607747884,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','search.php?search_id=active_topics',1,0,0,0),('4c08c23f02667d63d5dc4c729bf0b757',1,1607748898,1607748898,1607748898,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=weekview&calendar=1&week=1600560000',1,0,0,0),('4c9a4e7d56b875280b000c2339428212',1,1607749487,1607749487,1607749487,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=27&order=asc&prefix=0&sortby=starter',1,0,0,0),('506b9b15e85c136745860bfd544963c1',1,1607749660,1607749660,1607749660,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=29&order=desc&prefix=0&sortby=rating',1,0,0,0),('5483449c7552eabfa7290c4a046742e8',1,1607749502,1607749502,1607749502,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=27&order=desc&prefix=0&sortby=views',1,0,0,0),('5d209d142b0ed3c717b61a3af49e67b1',1,1607749375,1607749375,1607749375,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=17&order=asc&prefix=0&sortby=subject',1,0,0,0),('5d823ff75f6a93d5b872f190d4f80c36',1,1607750083,1607750083,1607750083,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=7&order=asc&prefix=0&sortby=subject',1,0,0,0),('700dcf95d3416efd6cebcd90381e7be9',1,1607748013,1607748013,1607748013,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/showthread.php?mode=linear&pid=56&tid=46',1,0,0,0),('72e586bdf0832bf949bd9b13dd93c3d0',1,1607744759,1607744759,1607744759,'188.97.219.60','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0','','Index.php',1,0,0,0),('7a6f235d74666622cee1518e5af60009',1,1607749993,1607749993,1607749993,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=4&order=desc&prefix=0&sortby=rating',1,0,0,0),('859a99fc1ba3dd05e3cfe75d4c2ca2b4',1,1607750054,1607750054,1607750054,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=7&order=desc&prefix=0&sortby=views',1,0,0,0),('86cf3ffde01fcff12f458c8c1f8e6a66',2,1606876865,1607729046,1607744566,'188.97.219.60','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0','','app.php/styles/ultra_light/theme/de/stylesheet.css?assets_version=32',1,0,1,0),('8b2ea000a09160a7d510298a672c472b',1,1607749688,1607749688,1607749688,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=22&order=asc&prefix=0&sortby=subject',1,0,0,0),('8f4cdff9cf78a0a3268ac3c5e5708a07',1,1607749408,1607749408,1607749408,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=16&order=desc&prefix=0&sortby=lastpost',1,0,0,0),('989a40f4c494d8d0adbe49af063337aa',1,1607749331,1607749331,1607749331,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=10&order=asc&prefix=0&sortby=views',1,0,0,0),('a21bb78bbfb28a7b5d4899e79b383d0e',1,1607748026,1607748026,1607748026,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/showthread.php?mode=linear&pid=59&tid=49',1,0,0,0),('a2fa89a7fed091a8c27767e33de1cb30',1,1607749422,1607749422,1607749422,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=10&order=desc&prefix=0&sortby=rating',1,0,0,0),('a33699e9fd43c5ea87aea31dba96634a',1,1607749191,1607749191,1607749191,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=dayview&calendar=1&day=27&month=9&year=2020',1,0,0,0),('a8890b0411f6e7982a06fa9a7600e542',1,1607749163,1607749163,1607749163,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=dayview&calendar=1&day=12&month=9&year=2020',1,0,0,0),('abd0fc78a170580710bb515c69563df7',1,1607749072,1607749072,1607749072,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=dayview&calendar=1&day=10&month=10&year=2020',1,0,0,0),('af90db5e25da35d68fbfc01ecb3f73e4',1,1607749206,1607749206,1607749206,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=dayview&calendar=1&day=26&month=10&year=2020',1,0,0,0),('b8c873bd2f0295c4c5ff92c776527aca',1,1607749610,1607749610,1607749610,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=24&order=desc&prefix=0&sortby=lastpost',1,0,0,0),('be95cafa8221d88bc6555ad3759803b1',1,1607748514,1607748514,1607748514,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','memberlist.php?order=descending&perpage=20&sort=referrals',1,0,0,0),('c0c721dea9aefc4850981dd9579becee',1,1607749964,1607749964,1607749964,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=4&order=asc&prefix=0&sortby=starter',1,0,0,0),('c4eeb6d01bf1a6c85cc46f5846abfc34',1,1607749220,1607749220,1607749220,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=dayview&calendar=1&day=15&month=10&year=2020',1,0,0,0),('c65cdb47e77bfc8e631eb9e774164a62',1,1607748729,1607748729,1607748729,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','memberlist.php?order=descending&perpage=20&sort=regdate',1,0,0,0),('cca600cc5900d0ec2cff246c00af72a3',1,1607749436,1607749436,1607749436,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=11&order=desc&prefix=0&sortby=views',1,0,0,0),('ccd2ed7cd2e51fe443bee0fa33097d78',1,1607749674,1607749674,1607749674,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=20&order=asc&prefix=0&sortby=starter',1,0,0,0),('cf8d3365d247b6cb87d8f68847f0530c',1,1607748404,1607748404,1607748404,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/showthread.php?mode=linear&pid=69&tid=59',1,0,0,0),('d2d6bb19c27f99a3e6817b23a375b4f7',1,1607749177,1607749177,1607749177,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=dayview&calendar=1&day=16&month=9&year=2020',1,0,0,0),('d86840cde74bbee4289326d868600739',1,1607749360,1607749360,1607749360,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=17&order=asc&prefix=0&sortby=starter',1,0,0,0),('e21221753bb7e57ffaebc19566b8f689',1,1607748742,1607748742,1607748742,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','memberlist.php?order=descending&perpage=20&sort=lastvisit',1,0,0,0),('ebc0e67a4bd747802038863878a82dac',1,1607744760,1607744760,1607744760,'188.97.219.60','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0','','app.php/styles/ultra_light/theme/de/stylesheet.css?assets_version=32',1,0,0,0),('effea92968260a53017f56bbfa4c75c8',1,1607749044,1607749044,1607749044,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/calendar.php?action=addevent&calendar=1&day=30&month=9&year=2020',1,0,0,0),('f24953ea4f4c88db37591c512ba1a6af',1,1607747900,1607747900,1607747900,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','memberlist.php?mode=contactadmin',1,0,0,0),('f84494e662bf84d1b25456bad85468c9',1,1607749745,1607749745,1607749745,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=8&order=asc&prefix=0&sortby=subject',1,0,0,0),('f9217732cedb3ed3c1afc509048d2c7e',1,1607750068,1607750068,1607750068,'62.210.189.2','Mozilla/5.0 (compatible; Barkrowler/0.9; +https://babbar.tech/crawler)','','app.php/forumdisplay.php?datecut=9999&fid=7&order=asc&prefix=0&sortby=starter',1,0,0,0),('ffee562348a4834815be459ae4ad3f34',18,1607750542,1607750542,1607751125,'66.249.76.69','Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','','memberlist.php?mode=contactadmin',1,0,0,0);
/*!40000 ALTER TABLE `phpbb_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_sessions_keys`
--

DROP TABLE IF EXISTS `phpbb_sessions_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_sessions_keys` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`key_id`,`user_id`),
  KEY `last_login` (`last_login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_sessions_keys`
--

LOCK TABLES `phpbb_sessions_keys` WRITE;
/*!40000 ALTER TABLE `phpbb_sessions_keys` DISABLE KEYS */;
INSERT INTO `phpbb_sessions_keys` VALUES ('1c52b0aa96906f5ba87237f4a9281a61',2,'178.4.43.135',1606581518);
/*!40000 ALTER TABLE `phpbb_sessions_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_sitelist`
--

DROP TABLE IF EXISTS `phpbb_sitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_sitelist` (
  `site_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `site_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `site_hostname` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `ip_exclude` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_sitelist`
--

LOCK TABLES `phpbb_sitelist` WRITE;
/*!40000 ALTER TABLE `phpbb_sitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_sitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_sm_block_routes`
--

DROP TABLE IF EXISTS `phpbb_sm_block_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_sm_block_routes` (
  `route_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ext_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `route` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `style` smallint(4) unsigned NOT NULL DEFAULT 0,
  `hide_blocks` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `has_blocks` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `ex_positions` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`route_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_sm_block_routes`
--

LOCK TABLES `phpbb_sm_block_routes` WRITE;
/*!40000 ALTER TABLE `phpbb_sm_block_routes` DISABLE KEYS */;
INSERT INTO `phpbb_sm_block_routes` VALUES (2,'','index.php',4,0,1,'');
/*!40000 ALTER TABLE `phpbb_sm_block_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_sm_blocks`
--

DROP TABLE IF EXISTS `phpbb_sm_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_sm_blocks` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `icon` varchar(55) COLLATE utf8_bin NOT NULL DEFAULT '',
  `name` varchar(55) COLLATE utf8_bin NOT NULL DEFAULT '',
  `title` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `route_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `position` varchar(55) COLLATE utf8_bin NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT 0,
  `style` smallint(4) unsigned NOT NULL DEFAULT 0,
  `permission` varchar(125) COLLATE utf8_bin NOT NULL DEFAULT '',
  `class` varchar(125) COLLATE utf8_bin NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `type` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `hide_title` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `hash` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `settings` mediumtext COLLATE utf8_bin NOT NULL,
  `view` varchar(55) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`bid`),
  KEY `style` (`style`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_sm_blocks`
--

LOCK TABLES `phpbb_sm_blocks` WRITE;
/*!40000 ALTER TABLE `phpbb_sm_blocks` DISABLE KEYS */;
INSERT INTO `phpbb_sm_blocks` VALUES (12,'','blitze.sitemaker.block.menu','',2,'sidebar',0,4,'','',1,0,0,'47acc410105dbd04990e3095d9565178','{\"menu_id\":\"1\",\"expanded\":\"0\",\"max_depth\":\"3\"}','basic'),(17,'','blitze.sitemaker.block.whois','',2,'top',0,4,'','',1,0,0,'','','basic'),(19,'','blitze.sitemaker.block.member_menu','',2,'sidebar',1,4,'','',1,0,0,'','','basic'),(20,'','blitze.sitemaker.block.custom','Informationen',2,'panel',0,4,'','',1,0,0,'4187a41efa34b6ca0efe865acfa12513','{\"source\":\"&lt;!-- pr\\u00e4sentiert von kostenlose-javascripts.de --&gt;\\n&lt;script type=\'text\\/javascript\'&gt;\\n&lt;!--\\n  var cut = 0;\\n  var texte = new Array(\\n\\t\'Wenn du ein Problem hast wende dich an uns!\',\\n\\t\'Du kannst uns auch im WebChat erreichen.\',\\n\\t\'Das SupportSystem ist auch gerne f\\u00fcr dich da.\'\\n  );\\n  var textAktuell = 0;\\n\\n\\tdocument.write(\'&lt;style type=&quot;text\\/css&quot;&gt;\');\\n\\tdocument.write(\'.klammer { color: #EF0000; font-size: 150%; font-weight: bold; }\');\\n\\tdocument.write(\'&lt;\\/style&gt;\');\\n  if (document.getElementById){document.write(\'&lt;div id=&quot;textArea&quot; style=&quot;text-align: center;&quot;&gt;&lt;span class=&quot;klammer&quot;&gt;[ &lt;\\/span&gt;&lt;span class=&quot;klammer&quot;&gt; ]&lt;\\/span&gt;&lt;\\/div&gt;\');}\\n  else  { document.write(\'&lt;layer id=&quot;textArea&quot; style=&quot;text-align: center;&quot;&gt;&lt;span class=&quot;klammer&quot;&gt;[ &lt;\\/span&gt;&lt;span class=&quot;klammer&quot;&gt; ]&lt;\\/span&gt;&lt;\\/layer&gt;\'); }\\n\\n  function write (textAktuell)\\n  {\\n    textAktuell %= texte.length;\\n    text = texte[textAktuell];\\n    document.getElementById(\'textArea\').innerHTML = \'&lt;span class=&quot;klammer&quot;&gt;[ &lt;\\/span&gt;&lt;font size=&quot;16&quot;&gt;\' + text.substring(0, ++cut) + \'&lt;\\/font&gt;&lt;span class=&quot;klammer&quot;&gt; ]&lt;\\/span&gt;\';\\n\\n    if (cut &lt; text.length)  { window.setTimeout(\'write(\' + parseInt(textAktuell) + \')\', 50); }\\n    else  { window.setTimeout(\'rewrite(\' + (parseInt(textAktuell) + 0) + \')\', 2000); }\\n  }\\n\\n  function rewrite (textAktuell)\\n  {\\n    textAktuell %= texte.length;\\n    text = texte[textAktuell];\\n    document.getElementById(\'textArea\').innerHTML = \'&lt;span class=&quot;klammer&quot;&gt;[ &lt;\\/span&gt;&lt;font size=&quot;16&quot;&gt;\' + text.substring(0, --cut) + \'&lt;\\/font&gt;&lt;span class=&quot;klammer&quot;&gt; ]&lt;\\/span&gt;\';\\n\\n    if (cut &gt; 0)  { window.setTimeout(\'rewrite(\' + parseInt(textAktuell) + \')\', 50); }\\n    else  { window.setTimeout(\'write(\' + (parseInt(textAktuell) + 1) + \')\', 2000); }\\n  }\\n\\/\\/--&gt;\\n&lt;\\/script&gt;\\n&lt;script type=&quot;text\\/javascript&quot;&gt;window.setTimeout(\'write(0)\', 2000);&lt;\\/script&gt;\",\"js_scripts\":[\"\"],\"css_scripts\":[\"\"]}','boxed');
/*!40000 ALTER TABLE `phpbb_sm_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_sm_cblocks`
--

DROP TABLE IF EXISTS `phpbb_sm_cblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_sm_cblocks` (
  `block_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `block_content` text COLLATE utf8_bin NOT NULL,
  `bbcode_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bbcode_options` int(11) unsigned NOT NULL DEFAULT 7,
  `bbcode_uid` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`block_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_sm_cblocks`
--

LOCK TABLES `phpbb_sm_cblocks` WRITE;
/*!40000 ALTER TABLE `phpbb_sm_cblocks` DISABLE KEYS */;
INSERT INTO `phpbb_sm_cblocks` VALUES (20,'<t>&lt;p&gt;&lt;marquee direction=\"left\"&gt;Willkommen&lt;/marquee&gt;&lt;/p&gt;</t>','',3,'');
/*!40000 ALTER TABLE `phpbb_sm_cblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_sm_menu_items`
--

DROP TABLE IF EXISTS `phpbb_sm_menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_sm_menu_items` (
  `item_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `item_title` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `item_url` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `item_icon` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `item_target` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `left_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `right_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `depth` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `item_parents` mediumtext COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `menu_id` (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_sm_menu_items`
--

LOCK TABLES `phpbb_sm_menu_items` WRITE;
/*!40000 ALTER TABLE `phpbb_sm_menu_items` DISABLE KEYS */;
INSERT INTO `phpbb_sm_menu_items` VALUES (1,1,0,'Support','https://igamerpg.zammad.com','fa fa-at fa-red pull-left fa-border fa-rotate-90 ',1,3,4,0,''),(3,1,0,'WebChat','https://game.igame-rpg.de:4444','fa fa-weixin fa-lg fa-orange pull-left fa-spin fa-rotate-180 ',1,5,6,0,''),(4,1,0,'Hauptseite','https://www.igame-rpg.de','fa fa-home ',0,1,2,0,''),(5,1,0,'Dokumentation','https://game.igame-rpg.de/docu/','fa fa-book ',1,7,8,0,'');
/*!40000 ALTER TABLE `phpbb_sm_menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_sm_menus`
--

DROP TABLE IF EXISTS `phpbb_sm_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_sm_menus` (
  `menu_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(55) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`menu_id`),
  UNIQUE KEY `menu_name` (`menu_name`),
  KEY `menu_id` (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_sm_menus`
--

LOCK TABLES `phpbb_sm_menus` WRITE;
/*!40000 ALTER TABLE `phpbb_sm_menus` DISABLE KEYS */;
INSERT INTO `phpbb_sm_menus` VALUES (1,'MainMenu');
/*!40000 ALTER TABLE `phpbb_sm_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_smilies`
--

DROP TABLE IF EXISTS `phpbb_smilies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_smilies` (
  `smiley_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `emotion` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `smiley_url` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `smiley_width` smallint(4) unsigned NOT NULL DEFAULT 0,
  `smiley_height` smallint(4) unsigned NOT NULL DEFAULT 0,
  `smiley_order` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `display_on_posting` tinyint(1) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`smiley_id`),
  KEY `display_on_post` (`display_on_posting`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_smilies`
--

LOCK TABLES `phpbb_smilies` WRITE;
/*!40000 ALTER TABLE `phpbb_smilies` DISABLE KEYS */;
INSERT INTO `phpbb_smilies` VALUES (1,':D','Überglücklich','icon_e_biggrin.gif',15,17,1,1),(2,':-D','Überglücklich','icon_e_biggrin.gif',15,17,2,1),(3,':grin:','Überglücklich','icon_e_biggrin.gif',15,17,3,1),(4,':)','Lächeln','icon_e_smile.gif',15,17,4,1),(5,':-)','Lächeln','icon_e_smile.gif',15,17,5,1),(6,':smile:','Lächeln','icon_e_smile.gif',15,17,6,1),(7,';)','Zwinkern','icon_e_wink.gif',15,17,7,1),(8,';-)','Zwinkern','icon_e_wink.gif',15,17,8,1),(9,':wink:','Zwinkern','icon_e_wink.gif',15,17,9,1),(10,':(','Traurig','icon_e_sad.gif',15,17,10,1),(11,':-(','Traurig','icon_e_sad.gif',15,17,11,1),(12,':sad:','Traurig','icon_e_sad.gif',15,17,12,1),(13,':o','Überrascht','icon_e_surprised.gif',15,17,13,1),(14,':-o','Überrascht','icon_e_surprised.gif',15,17,14,1),(15,':eek:','Überrascht','icon_e_surprised.gif',15,17,15,1),(16,':shock:','Erschüttert','icon_eek.gif',15,17,16,1),(17,':?','Verwirrt','icon_e_confused.gif',15,17,17,1),(18,':-?','Verwirrt','icon_e_confused.gif',15,17,18,1),(19,':???:','Verwirrt','icon_e_confused.gif',15,17,19,1),(20,'8-)','Fetzig','icon_cool.gif',15,17,20,1),(21,':cool:','Fetzig','icon_cool.gif',15,17,21,1),(22,':lol:','Lachend','icon_lol.gif',15,17,22,1),(23,':x','Verärgert','icon_mad.gif',15,17,23,1),(24,':-x','Verärgert','icon_mad.gif',15,17,24,1),(25,':mad:','Verärgert','icon_mad.gif',15,17,25,1),(26,':P','Hänseln','icon_razz.gif',15,17,26,1),(27,':-P','Hänseln','icon_razz.gif',15,17,27,1),(28,':razz:','Hänseln','icon_razz.gif',15,17,28,1),(29,':oops:','Verlegen','icon_redface.gif',15,17,29,1),(30,':cry:','Weinend oder sehr traurig','icon_cry.gif',15,17,30,1),(31,':evil:','Böse oder sehr verärgert','icon_evil.gif',15,17,31,1),(32,':twisted:','Verrückter Teufel','icon_twisted.gif',15,17,32,1),(33,':roll:','Augen verdrehen','icon_rolleyes.gif',15,17,33,1),(34,':!:','Ausruf','icon_exclaim.gif',15,17,34,1),(35,':?:','Frage','icon_question.gif',15,17,35,1),(36,':idea:','Idee','icon_idea.gif',15,17,36,1),(37,':arrow:','Pfeil','icon_arrow.gif',15,17,37,1),(38,':|','Neutral','icon_neutral.gif',15,17,38,1),(39,':-|','Neutral','icon_neutral.gif',15,17,39,1),(40,':mrgreen:','Mr. Green','icon_mrgreen.gif',15,17,40,1),(41,':geek:','Computerfreak','icon_e_geek.gif',17,17,41,1),(42,':ugeek:','Extremer Computerfreak','icon_e_ugeek.gif',17,18,42,1);
/*!40000 ALTER TABLE `phpbb_smilies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_styles`
--

DROP TABLE IF EXISTS `phpbb_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_styles` (
  `style_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `style_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `style_copyright` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `style_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `style_path` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bbcode_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'kNg=',
  `style_parent_id` int(4) unsigned NOT NULL DEFAULT 0,
  `style_parent_tree` text COLLATE utf8_bin NOT NULL,
  `topic_preview_theme` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT 'light',
  PRIMARY KEY (`style_id`),
  UNIQUE KEY `style_name` (`style_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_styles`
--

LOCK TABLES `phpbb_styles` WRITE;
/*!40000 ALTER TABLE `phpbb_styles` DISABLE KEYS */;
INSERT INTO `phpbb_styles` VALUES (1,'prosilver','&copy; phpBB Limited',1,'prosilver','//g=',0,'','neon'),(2,'BlackBoard','© FanFanLaTuFlippe',1,'BlackBoard','//g=',1,'prosilver','neon'),(4,'ultra_light','&amp;copy; Style Ultra Light by Nothal, 2013',1,'ultra_light','//g=',1,'prosilver','neon');
/*!40000 ALTER TABLE `phpbb_styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_teampage`
--

DROP TABLE IF EXISTS `phpbb_teampage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_teampage` (
  `teampage_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `teampage_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `teampage_position` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `teampage_parent` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`teampage_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_teampage`
--

LOCK TABLES `phpbb_teampage` WRITE;
/*!40000 ALTER TABLE `phpbb_teampage` DISABLE KEYS */;
INSERT INTO `phpbb_teampage` VALUES (1,5,'',1,0),(2,4,'',2,0);
/*!40000 ALTER TABLE `phpbb_teampage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_topic_prefixes`
--

DROP TABLE IF EXISTS `phpbb_topic_prefixes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_topic_prefixes` (
  `prefix_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `prefix_tag` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `prefix_enabled` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `prefix_parent_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `prefix_left_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `prefix_right_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `prefix_parents` mediumtext COLLATE utf8_bin NOT NULL,
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`prefix_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_topic_prefixes`
--

LOCK TABLES `phpbb_topic_prefixes` WRITE;
/*!40000 ALTER TABLE `phpbb_topic_prefixes` DISABLE KEYS */;
INSERT INTO `phpbb_topic_prefixes` VALUES (1,'[Allgemeine Frage]',1,0,1,2,'',10),(2,'[Bot Frage]',1,0,3,4,'',10),(3,'[ChanServ Frage]',1,0,5,6,'',10),(4,'[NickServ Frage]',1,0,7,8,'',10),(5,'[MemoServ Frage]',1,0,9,10,'',10),(6,'[BotServ Frage]',1,0,11,12,'',10),(7,'[WebChat Frage]',1,0,13,14,'',10),(8,'[Client Frage]',1,0,15,16,'',10),(9,'[Bewerbung von]',1,0,17,18,'',11);
/*!40000 ALTER TABLE `phpbb_topic_prefixes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_topics`
--

DROP TABLE IF EXISTS `phpbb_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_topics` (
  `topic_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `icon_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `topic_attachment` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `topic_reported` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `topic_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `topic_poster` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_time` int(11) unsigned NOT NULL DEFAULT 0,
  `topic_time_limit` int(11) unsigned NOT NULL DEFAULT 0,
  `topic_views` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `topic_status` tinyint(3) NOT NULL DEFAULT 0,
  `topic_type` tinyint(3) NOT NULL DEFAULT 0,
  `topic_first_post_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_first_poster_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `topic_first_poster_colour` varchar(6) COLLATE utf8_bin NOT NULL DEFAULT '',
  `topic_last_post_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_last_poster_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_last_poster_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `topic_last_poster_colour` varchar(6) COLLATE utf8_bin NOT NULL DEFAULT '',
  `topic_last_post_subject` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `topic_last_post_time` int(11) unsigned NOT NULL DEFAULT 0,
  `topic_last_view_time` int(11) unsigned NOT NULL DEFAULT 0,
  `topic_moved_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_bumped` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `topic_bumper` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `poll_title` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `poll_start` int(11) unsigned NOT NULL DEFAULT 0,
  `poll_length` int(11) unsigned NOT NULL DEFAULT 0,
  `poll_max_options` tinyint(4) NOT NULL DEFAULT 1,
  `poll_last_vote` int(11) unsigned NOT NULL DEFAULT 0,
  `poll_vote_change` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `topic_visibility` tinyint(3) NOT NULL DEFAULT 0,
  `topic_delete_time` int(11) unsigned NOT NULL DEFAULT 0,
  `topic_delete_reason` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `topic_delete_user` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_posts_approved` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `topic_posts_unapproved` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `topic_posts_softdeleted` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `topic_first_post_show` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `topic_prefix_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`topic_id`),
  KEY `forum_id` (`forum_id`),
  KEY `forum_id_type` (`forum_id`,`topic_type`),
  KEY `last_post_time` (`topic_last_post_time`),
  KEY `fid_time_moved` (`forum_id`,`topic_last_post_time`,`topic_moved_id`),
  KEY `topic_visibility` (`topic_visibility`),
  KEY `forum_vis_last` (`forum_id`,`topic_visibility`,`topic_last_post_id`),
  KEY `latest_topics` (`forum_id`,`topic_last_post_time`,`topic_last_post_id`,`topic_moved_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_topics`
--

LOCK TABLES `phpbb_topics` WRITE;
/*!40000 ALTER TABLE `phpbb_topics` DISABLE KEYS */;
INSERT INTO `phpbb_topics` VALUES (3,6,0,0,0,'Unserer Regeln',2,1607731182,0,3,1,1,3,'Zenturion','AA0000',3,2,'Zenturion','AA0000','Unserer Regeln',1607731182,1607732589,0,0,0,'',0,0,1,0,0,1,0,'',0,1,0,0,0,0),(5,11,0,0,0,'Bewewrbungsvorlage',2,1607742660,0,2,1,1,5,'Zenturion','AA0000',5,2,'Zenturion','AA0000','Bewewrbungsvorlage',1607742660,1607742885,0,0,0,'',0,0,1,0,0,1,0,'',2,1,0,0,0,0);
/*!40000 ALTER TABLE `phpbb_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_topics_posted`
--

DROP TABLE IF EXISTS `phpbb_topics_posted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_topics_posted` (
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_posted` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_topics_posted`
--

LOCK TABLES `phpbb_topics_posted` WRITE;
/*!40000 ALTER TABLE `phpbb_topics_posted` DISABLE KEYS */;
INSERT INTO `phpbb_topics_posted` VALUES (2,1,1),(2,2,1),(2,3,1),(2,5,1);
/*!40000 ALTER TABLE `phpbb_topics_posted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_topics_track`
--

DROP TABLE IF EXISTS `phpbb_topics_track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_topics_track` (
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `forum_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `mark_time` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`,`topic_id`),
  KEY `forum_id` (`forum_id`),
  KEY `topic_id` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_topics_track`
--

LOCK TABLES `phpbb_topics_track` WRITE;
/*!40000 ALTER TABLE `phpbb_topics_track` DISABLE KEYS */;
INSERT INTO `phpbb_topics_track` VALUES (2,3,6,1607731183);
/*!40000 ALTER TABLE `phpbb_topics_track` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_topics_watch`
--

DROP TABLE IF EXISTS `phpbb_topics_watch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_topics_watch` (
  `topic_id` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `notify_status` tinyint(1) unsigned NOT NULL DEFAULT 0,
  KEY `topic_id` (`topic_id`),
  KEY `user_id` (`user_id`),
  KEY `notify_stat` (`notify_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_topics_watch`
--

LOCK TABLES `phpbb_topics_watch` WRITE;
/*!40000 ALTER TABLE `phpbb_topics_watch` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_topics_watch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_user_group`
--

DROP TABLE IF EXISTS `phpbb_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_user_group` (
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `group_leader` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `user_pending` tinyint(1) unsigned NOT NULL DEFAULT 1,
  KEY `group_id` (`group_id`),
  KEY `user_id` (`user_id`),
  KEY `group_leader` (`group_leader`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_user_group`
--

LOCK TABLES `phpbb_user_group` WRITE;
/*!40000 ALTER TABLE `phpbb_user_group` DISABLE KEYS */;
INSERT INTO `phpbb_user_group` VALUES (1,1,0,0),(2,2,0,0),(4,2,0,0),(5,2,1,0),(6,3,0,0),(6,4,0,0),(6,5,0,0),(6,6,0,0),(6,7,0,0),(6,8,0,0),(6,9,0,0),(6,10,0,0),(6,11,0,0),(6,12,0,0),(6,13,0,0),(6,14,0,0),(6,15,0,0),(6,16,0,0),(6,17,0,0),(6,18,0,0),(6,19,0,0),(6,20,0,0),(6,21,0,0),(6,22,0,0),(6,23,0,0),(6,24,0,0),(6,25,0,0),(6,26,0,0),(6,27,0,0),(6,28,0,0),(6,29,0,0),(6,30,0,0),(6,31,0,0),(6,32,0,0),(6,33,0,0),(6,34,0,0),(6,35,0,0),(6,36,0,0),(6,37,0,0),(6,38,0,0),(6,39,0,0),(6,40,0,0),(6,41,0,0),(6,42,0,0),(6,43,0,0),(6,44,0,0),(6,45,0,0),(6,46,0,0),(6,47,0,0),(6,48,0,0),(2,51,0,0),(7,51,0,0);
/*!40000 ALTER TABLE `phpbb_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_user_notifications`
--

DROP TABLE IF EXISTS `phpbb_user_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_user_notifications` (
  `item_type` varchar(165) COLLATE utf8_bin NOT NULL DEFAULT '',
  `item_id` int(10) unsigned NOT NULL DEFAULT 0,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `method` varchar(165) COLLATE utf8_bin NOT NULL DEFAULT '',
  `notify` tinyint(1) unsigned NOT NULL DEFAULT 1,
  UNIQUE KEY `itm_usr_mthd` (`item_type`,`item_id`,`user_id`,`method`),
  KEY `user_id` (`user_id`),
  KEY `uid_itm_id` (`user_id`,`item_id`),
  KEY `usr_itm_tpe` (`user_id`,`item_type`,`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_user_notifications`
--

LOCK TABLES `phpbb_user_notifications` WRITE;
/*!40000 ALTER TABLE `phpbb_user_notifications` DISABLE KEYS */;
INSERT INTO `phpbb_user_notifications` VALUES ('notification.type.forum',0,2,'notification.method.board',1),('notification.type.forum',0,2,'notification.method.email',1),('notification.type.post',0,2,'notification.method.board',1),('notification.type.post',0,2,'notification.method.email',1),('notification.type.post',0,3,'notification.method.email',1),('notification.type.post',0,4,'notification.method.email',1),('notification.type.post',0,5,'notification.method.email',1),('notification.type.post',0,6,'notification.method.email',1),('notification.type.post',0,7,'notification.method.email',1),('notification.type.post',0,8,'notification.method.email',1),('notification.type.post',0,9,'notification.method.email',1),('notification.type.post',0,10,'notification.method.email',1),('notification.type.post',0,11,'notification.method.email',1),('notification.type.post',0,12,'notification.method.email',1),('notification.type.post',0,13,'notification.method.email',1),('notification.type.post',0,14,'notification.method.email',1),('notification.type.post',0,15,'notification.method.email',1),('notification.type.post',0,16,'notification.method.email',1),('notification.type.post',0,17,'notification.method.email',1),('notification.type.post',0,18,'notification.method.email',1),('notification.type.post',0,19,'notification.method.email',1),('notification.type.post',0,20,'notification.method.email',1),('notification.type.post',0,21,'notification.method.email',1),('notification.type.post',0,22,'notification.method.email',1),('notification.type.post',0,23,'notification.method.email',1),('notification.type.post',0,24,'notification.method.email',1),('notification.type.post',0,25,'notification.method.email',1),('notification.type.post',0,26,'notification.method.email',1),('notification.type.post',0,27,'notification.method.email',1),('notification.type.post',0,28,'notification.method.email',1),('notification.type.post',0,29,'notification.method.email',1),('notification.type.post',0,30,'notification.method.email',1),('notification.type.post',0,31,'notification.method.email',1),('notification.type.post',0,32,'notification.method.email',1),('notification.type.post',0,33,'notification.method.email',1),('notification.type.post',0,34,'notification.method.email',1),('notification.type.post',0,35,'notification.method.email',1),('notification.type.post',0,36,'notification.method.email',1),('notification.type.post',0,37,'notification.method.email',1),('notification.type.post',0,38,'notification.method.email',1),('notification.type.post',0,39,'notification.method.email',1),('notification.type.post',0,40,'notification.method.email',1),('notification.type.post',0,41,'notification.method.email',1),('notification.type.post',0,42,'notification.method.email',1),('notification.type.post',0,43,'notification.method.email',1),('notification.type.post',0,44,'notification.method.email',1),('notification.type.post',0,45,'notification.method.email',1),('notification.type.post',0,46,'notification.method.email',1),('notification.type.post',0,47,'notification.method.email',1),('notification.type.post',0,48,'notification.method.email',1),('notification.type.post',0,51,'notification.method.email',1),('notification.type.topic',0,2,'notification.method.board',1),('notification.type.topic',0,2,'notification.method.email',1),('notification.type.topic',0,3,'notification.method.email',1),('notification.type.topic',0,4,'notification.method.email',1),('notification.type.topic',0,5,'notification.method.email',1),('notification.type.topic',0,6,'notification.method.email',1),('notification.type.topic',0,7,'notification.method.email',1),('notification.type.topic',0,8,'notification.method.email',1),('notification.type.topic',0,9,'notification.method.email',1),('notification.type.topic',0,10,'notification.method.email',1),('notification.type.topic',0,11,'notification.method.email',1),('notification.type.topic',0,12,'notification.method.email',1),('notification.type.topic',0,13,'notification.method.email',1),('notification.type.topic',0,14,'notification.method.email',1),('notification.type.topic',0,15,'notification.method.email',1),('notification.type.topic',0,16,'notification.method.email',1),('notification.type.topic',0,17,'notification.method.email',1),('notification.type.topic',0,18,'notification.method.email',1),('notification.type.topic',0,19,'notification.method.email',1),('notification.type.topic',0,20,'notification.method.email',1),('notification.type.topic',0,21,'notification.method.email',1),('notification.type.topic',0,22,'notification.method.email',1),('notification.type.topic',0,23,'notification.method.email',1),('notification.type.topic',0,24,'notification.method.email',1),('notification.type.topic',0,25,'notification.method.email',1),('notification.type.topic',0,26,'notification.method.email',1),('notification.type.topic',0,27,'notification.method.email',1),('notification.type.topic',0,28,'notification.method.email',1),('notification.type.topic',0,29,'notification.method.email',1),('notification.type.topic',0,30,'notification.method.email',1),('notification.type.topic',0,31,'notification.method.email',1),('notification.type.topic',0,32,'notification.method.email',1),('notification.type.topic',0,33,'notification.method.email',1),('notification.type.topic',0,34,'notification.method.email',1),('notification.type.topic',0,35,'notification.method.email',1),('notification.type.topic',0,36,'notification.method.email',1),('notification.type.topic',0,37,'notification.method.email',1),('notification.type.topic',0,38,'notification.method.email',1),('notification.type.topic',0,39,'notification.method.email',1),('notification.type.topic',0,40,'notification.method.email',1),('notification.type.topic',0,41,'notification.method.email',1),('notification.type.topic',0,42,'notification.method.email',1),('notification.type.topic',0,43,'notification.method.email',1),('notification.type.topic',0,44,'notification.method.email',1),('notification.type.topic',0,45,'notification.method.email',1),('notification.type.topic',0,46,'notification.method.email',1),('notification.type.topic',0,47,'notification.method.email',1),('notification.type.topic',0,48,'notification.method.email',1),('notification.type.topic',0,51,'notification.method.email',1);
/*!40000 ALTER TABLE `phpbb_user_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_users`
--

DROP TABLE IF EXISTS `phpbb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(2) NOT NULL DEFAULT 0,
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT 3,
  `user_permissions` mediumtext COLLATE utf8_bin NOT NULL,
  `user_perm_from` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_ip` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_regdate` int(11) unsigned NOT NULL DEFAULT 0,
  `username` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `username_clean` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_password` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_passchg` int(11) unsigned NOT NULL DEFAULT 0,
  `user_email` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_birthday` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_lastvisit` int(11) unsigned NOT NULL DEFAULT 0,
  `user_lastmark` int(11) unsigned NOT NULL DEFAULT 0,
  `user_lastpost_time` int(11) unsigned NOT NULL DEFAULT 0,
  `user_lastpage` varchar(200) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_last_confirm_key` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_last_search` int(11) unsigned NOT NULL DEFAULT 0,
  `user_warnings` tinyint(4) NOT NULL DEFAULT 0,
  `user_last_warning` int(11) unsigned NOT NULL DEFAULT 0,
  `user_login_attempts` tinyint(4) NOT NULL DEFAULT 0,
  `user_inactive_reason` tinyint(2) NOT NULL DEFAULT 0,
  `user_inactive_time` int(11) unsigned NOT NULL DEFAULT 0,
  `user_posts` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_lang` varchar(30) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_timezone` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_dateformat` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT 'd M Y H:i',
  `user_style` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_rank` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_colour` varchar(6) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_new_privmsg` int(4) NOT NULL DEFAULT 0,
  `user_unread_privmsg` int(4) NOT NULL DEFAULT 0,
  `user_last_privmsg` int(11) unsigned NOT NULL DEFAULT 0,
  `user_message_rules` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `user_full_folder` int(11) NOT NULL DEFAULT -3,
  `user_emailtime` int(11) unsigned NOT NULL DEFAULT 0,
  `user_topic_show_days` smallint(4) unsigned NOT NULL DEFAULT 0,
  `user_topic_sortby_type` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 't',
  `user_topic_sortby_dir` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'd',
  `user_post_show_days` smallint(4) unsigned NOT NULL DEFAULT 0,
  `user_post_sortby_type` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 't',
  `user_post_sortby_dir` varchar(1) COLLATE utf8_bin NOT NULL DEFAULT 'a',
  `user_notify` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `user_notify_pm` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_notify_type` tinyint(4) NOT NULL DEFAULT 0,
  `user_allow_pm` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_allow_viewonline` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_allow_viewemail` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_allow_massemail` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_options` int(11) unsigned NOT NULL DEFAULT 230271,
  `user_avatar` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_avatar_type` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_avatar_width` smallint(4) unsigned NOT NULL DEFAULT 0,
  `user_avatar_height` smallint(4) unsigned NOT NULL DEFAULT 0,
  `user_sig` mediumtext COLLATE utf8_bin NOT NULL,
  `user_sig_bbcode_uid` varchar(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_sig_bbcode_bitfield` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_jabber` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_actkey` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `reset_token` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `reset_token_expiration` int(11) unsigned NOT NULL DEFAULT 0,
  `user_newpasswd` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_form_salt` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_new` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_reminded` tinyint(4) NOT NULL DEFAULT 0,
  `user_reminded_time` int(11) unsigned NOT NULL DEFAULT 0,
  `user_topic_preview` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_gender` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `user_font` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `user_font_size` mediumint(8) unsigned NOT NULL DEFAULT 104,
  `user_font_bold` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `user_mobile_font` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `user_mobile_font_size` mediumint(8) unsigned NOT NULL DEFAULT 104,
  `user_mchat_avatars` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_mchat_capital_letter` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_mchat_character_count` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_mchat_date` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT 'D M d, Y g:i a',
  `user_mchat_index` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_mchat_location` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_mchat_message_top` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_mchat_posts` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_mchat_relative_time` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_mchat_sound` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_mchat_stats_index` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `user_mchat_whois_index` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `user_pm_welcome` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username_clean` (`username_clean`),
  KEY `user_birthday` (`user_birthday`),
  KEY `user_type` (`user_type`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_users`
--

LOCK TABLES `phpbb_users` WRITE;
/*!40000 ALTER TABLE `phpbb_users` DISABLE KEYS */;
INSERT INTO `phpbb_users` VALUES (1,2,1,'00000000000g13ydmo000000000000\n\n\n\n\nhwby9w000000\nhwby9w000000\nhwby9w000000\nhwby9w000000\nhwby9w000000\nhwby9w000000\nhwby9w000000',0,'',1606579381,'Anonymous','anonymous','',0,'','',0,0,0,'','JWS4UZXHXY',1607721393,0,0,0,0,0,0,'en','','d M Y H:i',4,0,'',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,1,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','49nxfi08kyg4dvwl',1,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(2,3,5,'zik0zjzik0zjzik0zjqmwxjdxan9xc\n\n\n\n\nzik0zjqmx0qo\nzik0zjqmx0qo\nzik0zjqmx0qo\nzik0zjqmx0qo\nzik0zjqmx0qo\nzijocfqmx0qo\nzijocfqmx0qo',0,'178.4.43.135',1606579381,'Zenturion','zenturion','$argon2id$v=19$m=65536,t=4,p=2$bmk5NmtBSmV5Y2FqV3Q5Lg$UfaXebjoGTrGEzohUAqRIqziBQf3hD9JGLjQ4zS6iGc',1606581463,'admin@igame-rpg.de','',1606876865,0,1607742660,'app.php/styles/ultra_light/theme/de/stylesheet.css?assets_version=27','',0,0,0,0,0,0,2,'de','','D j. M Y, H:i',1,1,'AA0000',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,1,1,1,1,230271,'2_1606597351.jpg','avatar.driver.upload',90,90,'<t></t>','','','','','',0,'','70i1mcje6w2cxwp2',1,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(3,2,6,'',0,'',1606579385,'AdsBot [Google]','adsbot [google]','',1606579385,'','',0,1606579385,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','4h9x1v89698jeyxw',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(4,2,6,'',0,'',1606579385,'Alexa [Bot]','alexa [bot]','',1606579385,'','',0,1606579385,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','ird8sfoiqzjkdmp1',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(5,2,6,'',0,'',1606579386,'Alta Vista [Bot]','alta vista [bot]','',1606579386,'','',0,1606579386,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','vsre07950ff9lpfy',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(6,2,6,'',0,'',1606579386,'Ask Jeeves [Bot]','ask jeeves [bot]','',1606579386,'','',0,1606579386,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','3ylurytpmnkn2qph',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(7,2,6,'',0,'',1606579387,'Baidu [Spider]','baidu [spider]','',1606579387,'','',0,1606579387,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','6hg54o3m8e0sz3by',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(8,2,6,'',0,'',1606579388,'Bing [Bot]','bing [bot]','',1606579388,'','',1607706659,1606579388,0,'app.php/showthread.php?action=lastpost&tid=48','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','a06htxtcf1q05tp7',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(9,2,6,'',0,'',1606579389,'DuckDuckGo [Bot]','duckduckgo [bot]','',1606579389,'','',0,1606579389,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','f1k92jskbvmjnaje',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(10,2,6,'',0,'',1606579389,'Exabot [Bot]','exabot [bot]','',1606579389,'','',0,1606579389,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','z7x78bvav0lg7sce',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(11,2,6,'',0,'',1606579390,'FAST Enterprise [Crawler]','fast enterprise [crawler]','',1606579390,'','',0,1606579390,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','6xf0fqheajfcudw4',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(12,2,6,'',0,'',1606579391,'FAST WebCrawler [Crawler]','fast webcrawler [crawler]','',1606579391,'','',0,1606579391,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','eht4c807gqbcymc8',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(13,2,6,'',0,'',1606579392,'Francis [Bot]','francis [bot]','',1606579392,'','',0,1606579392,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','0n0mccgtqhf4ku82',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(14,2,6,'',0,'',1606579394,'Gigabot [Bot]','gigabot [bot]','',1606579394,'','',0,1606579394,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','8xk2g5mrw98yp6pn',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(15,2,6,'',0,'',1606579395,'Google Adsense [Bot]','google adsense [bot]','',1606579395,'','',0,1606579395,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','6if8a8a8sfysp72l',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(16,2,6,'',0,'',1606579396,'Google Desktop','google desktop','',1606579396,'','',0,1606579396,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','ymhai6ioi33rxszf',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(17,2,6,'',0,'',1606579397,'Google Feedfetcher','google feedfetcher','',1606579397,'','',0,1606579397,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','gnz20jdxr5gk6vip',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(18,2,6,'',0,'',1606579397,'Google [Bot]','google [bot]','',1606579397,'','',1607750896,1606579397,0,'Index.php','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','qv3xbkgkgnj8pu37',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(19,2,6,'',0,'',1606579398,'Heise IT-Markt [Crawler]','heise it-markt [crawler]','',1606579398,'','',0,1606579398,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','maqmoh2hl9eh6fad',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(20,2,6,'',0,'',1606579398,'Heritrix [Crawler]','heritrix [crawler]','',1606579398,'','',0,1606579398,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','jk6j9v9xx1kd0l4s',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(21,2,6,'',0,'',1606579398,'IBM Research [Bot]','ibm research [bot]','',1606579398,'','',0,1606579398,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','1fn6s116hhe21gwc',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(22,2,6,'',0,'',1606579399,'ICCrawler - ICjobs','iccrawler - icjobs','',1606579399,'','',0,1606579399,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','442oh4qh6xo828ys',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(23,2,6,'',0,'',1606579399,'ichiro [Crawler]','ichiro [crawler]','',1606579399,'','',0,1606579399,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','6lt0s1lezr7bbu28',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(24,2,6,'',0,'',1606579399,'Majestic-12 [Bot]','majestic-12 [bot]','',1606579399,'','',0,1606579399,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','ywx0lj3hnlcicafi',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(25,2,6,'',0,'',1606579400,'Metager [Bot]','metager [bot]','',1606579400,'','',0,1606579400,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','nindcl47q6f70a1f',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(26,2,6,'',0,'',1606579401,'MSN NewsBlogs','msn newsblogs','',1606579401,'','',0,1606579401,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','7c72f0565svvde1g',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(27,2,6,'',0,'',1606579401,'MSN [Bot]','msn [bot]','',1606579401,'','',0,1606579401,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','i8l4c6yzzkt6zs12',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(28,2,6,'',0,'',1606579402,'MSNbot Media','msnbot media','',1606579402,'','',0,1606579402,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','vl1nobsc269g7z25',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(29,2,6,'',0,'',1606579402,'Nutch [Bot]','nutch [bot]','',1606579402,'','',0,1606579402,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','p3z0zk0m7x21o3zq',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(30,2,6,'',0,'',1606579402,'Online link [Validator]','online link [validator]','',1606579402,'','',0,1606579402,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','jywclmpg131462r7',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(31,2,6,'',0,'',1606579403,'psbot [Picsearch]','psbot [picsearch]','',1606579403,'','',0,1606579403,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','eqlcq5gnroyy9uiy',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(32,2,6,'',0,'',1606579404,'Sensis [Crawler]','sensis [crawler]','',1606579404,'','',0,1606579404,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','b0rq49w0eflksn3s',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(33,2,6,'',0,'',1606579405,'SEO Crawler','seo crawler','',1606579405,'','',0,1606579405,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','cogkj2fj9zj5x31g',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(34,2,6,'',0,'',1606579406,'Seoma [Crawler]','seoma [crawler]','',1606579406,'','',0,1606579406,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','uaettjzy3j0481i8',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(35,2,6,'',0,'',1606579406,'SEOSearch [Crawler]','seosearch [crawler]','',1606579406,'','',0,1606579406,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','mvgcdu1txnmdlurn',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(36,2,6,'',0,'',1606579407,'Snappy [Bot]','snappy [bot]','',1606579407,'','',0,1606579407,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','arocs25a4jpqyz57',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(37,2,6,'',0,'',1606579407,'Steeler [Crawler]','steeler [crawler]','',1606579407,'','',0,1606579407,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','7l7k8hn6rudsik5d',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(38,2,6,'',0,'',1606579410,'Telekom [Bot]','telekom [bot]','',1606579410,'','',0,1606579410,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','bgage5rtlo2ty5nn',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(39,2,6,'',0,'',1606579410,'TurnitinBot [Bot]','turnitinbot [bot]','',1606579410,'','',0,1606579410,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','mj27uo1f6rm6dntc',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(40,2,6,'',0,'',1606579411,'Voyager [Bot]','voyager [bot]','',1606579411,'','',0,1606579411,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','sgv1prmjff24011k',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(41,2,6,'',0,'',1606579411,'W3 [Sitesearch]','w3 [sitesearch]','',1606579411,'','',0,1606579411,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','6zruitnioes8st2y',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(42,2,6,'',0,'',1606579411,'W3C [Linkcheck]','w3c [linkcheck]','',1606579411,'','',0,1606579411,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','bossh0vfu4dtsp5a',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(43,2,6,'',0,'',1606579412,'W3C [Validator]','w3c [validator]','',1606579412,'','',0,1606579412,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','4j7arfhxwbu8f38h',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(44,2,6,'',0,'',1606579412,'YaCy [Bot]','yacy [bot]','',1606579412,'','',0,1606579412,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','7ppns4htqkv1dj1v',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(45,2,6,'',0,'',1606579413,'Yahoo MMCrawler [Bot]','yahoo mmcrawler [bot]','',1606579413,'','',0,1606579413,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','74u3dmjz7y3j6y14',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(46,2,6,'',0,'',1606579413,'Yahoo Slurp [Bot]','yahoo slurp [bot]','',1606579413,'','',0,1606579413,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','wrp5r43alot8r966',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(47,2,6,'',0,'',1606579414,'Yahoo [Bot]','yahoo [bot]','',1606579414,'','',0,1606579414,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','q3ylftb4plhlfuvt',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(48,2,6,'',0,'',1606579414,'YahooSeeker [Bot]','yahooseeker [bot]','',1606579414,'','',0,1606579414,0,'','',0,0,0,0,0,0,0,'de','UTC','D j. M Y, H:i',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'<t></t>','','','','','',0,'','whit2hndiwavjei7',0,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(49,1,5,'',0,'',0,'Admin1','admin1','$argon2id$v=19$m=65536,t=4,p=2$bVFyWEhGYTNnWVFEbkh1TA$TdAHAe8G1I2iymPOihpnz/SPC19oNtvDj9hlC+UOF80',0,'admin@example.com','',1606609017,0,0,'index.php','',0,0,0,0,3,1606609020,1,'en','','d M Y H:i',1,1,'AA0000',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,1,1,1,1,230271,'','',0,0,'','','','','','',0,'','gt4lhf7m9wi9plmg',1,0,0,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1),(51,0,2,'',0,'178.4.43.135',1606610814,'TestNutzer','testnutzer','$argon2id$v=19$m=65536,t=4,p=2$eEVDRWVEWFRGL0UuWXY1TA$fI2nvW6JHGANRtqA+8Ch9OZ5jCYITizBEE71z+Ju50M',1606610814,'svdermant@gmail.com','',1606614366,1606610814,0,'app.php/styles/ultra_light/theme/de/stylesheet.css?assets_version=27','',0,0,0,0,0,0,0,'de','Africa/Algiers','D j. M Y, H:i',4,0,'',0,0,1606614108,0,-3,0,0,'t','d',0,'t','a',0,1,0,1,1,1,1,230271,'','',0,0,'','','','','','',0,'','s5vc2dumy7a36rs9',1,1,1606614068,1,0,0,104,0,0,104,1,1,1,'D M d, Y g:i a',1,1,1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `phpbb_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_warnings`
--

DROP TABLE IF EXISTS `phpbb_warnings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_warnings` (
  `warning_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `post_id` int(10) unsigned NOT NULL DEFAULT 0,
  `log_id` int(10) unsigned NOT NULL DEFAULT 0,
  `warning_time` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`warning_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_warnings`
--

LOCK TABLES `phpbb_warnings` WRITE;
/*!40000 ALTER TABLE `phpbb_warnings` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_warnings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_words`
--

DROP TABLE IF EXISTS `phpbb_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_words` (
  `word_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `replacement` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`word_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_words`
--

LOCK TABLES `phpbb_words` WRITE;
/*!40000 ALTER TABLE `phpbb_words` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpbb_zebra`
--

DROP TABLE IF EXISTS `phpbb_zebra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phpbb_zebra` (
  `user_id` int(10) unsigned NOT NULL DEFAULT 0,
  `zebra_id` int(10) unsigned NOT NULL DEFAULT 0,
  `friend` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `foe` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`,`zebra_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_zebra`
--

LOCK TABLES `phpbb_zebra` WRITE;
/*!40000 ALTER TABLE `phpbb_zebra` DISABLE KEYS */;
/*!40000 ALTER TABLE `phpbb_zebra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'phpBB'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-12  6:34:52
